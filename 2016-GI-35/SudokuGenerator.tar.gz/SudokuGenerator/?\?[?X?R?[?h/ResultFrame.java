import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.io.*;
import java.util.Calendar;

public class ResultFrame extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	SudokuPanel Panel[][] = null;
	JLabel HintLabel=null;
	SudokuFrame ParentFrame = null;
	JButton ModeChangeButton,OutputButton,CloseButton;
	JCheckBox AnswerPrintCheck;
	static int ProblemNumber=1;
	
	public ResultFrame(String Title,SudokuFrame Parent){
		ParentFrame = Parent;
		ProblemNumber++;
		setTitle(Title);
		setLayout(null);
		setBounds(0,0,450,328);
		
		AnswerPrintCheck=new JCheckBox("�𓚕\��");		
		AnswerPrintCheck.setBounds(310,140,105,30);
		add(AnswerPrintCheck);
		AnswerPrintCheck.addActionListener(this);
		
		CloseButton=new JButton("�߂�");		
		CloseButton.setBounds(310,220,105,30);
		add(CloseButton);
		CloseButton.addActionListener(this);
		
		HintLabel=new JLabel("�����z�u�̐�:"+ParentFrame.HintNumber);
		HintLabel.setBounds(320,110,100,30);
		add(HintLabel);

		JPanel Outer = new JPanel();
		Outer.setLayout(null);
		Outer.setLocation(0,0);
		Outer.setPreferredSize(new Dimension(291,291));
		Outer.setSize(Outer.getPreferredSize());
		Outer.setBackground(Color.BLACK);
		Outer.setOpaque(true);
		Outer.setVisible(true);
		add(Outer);
		Panel = new SudokuPanel[9][9];
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				Panel[i][j] = new SudokuPanel(i,j,Parent.Places[i][j],Parent.Creator.Answer[i][j]);
				Outer.add(Panel[i][j]);
			}
		}
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			// �E�B���h�E������Ƃ��ɌĂ΂��
			@Override
			public void windowClosing(WindowEvent e) {
				ParentFrame.setVisible(true);
				dispose();
			}
		});
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == AnswerPrintCheck){
			for(int i=0;i<9;i++){
				for(int j=0;j<9;j++){
					Panel[i][j].changeVisible();
				}
			}			
		}else if(arg0.getSource() == CloseButton){
			if(ParentFrame != null) ParentFrame.setVisible(true);
			dispose();
		}
	}


}
