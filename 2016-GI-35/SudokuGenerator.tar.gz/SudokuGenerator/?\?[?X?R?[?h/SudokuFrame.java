import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SudokuFrame extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	SudokuPanel Panels[][] = null;
	SudokuAlert Alert; 
	JLabel HintLabel=null;
	JButton OK,Clear;
	JCheckBox AllowBackTrack;
	JPanel Outer;
	Creator Creator;
	int HintNumber = 0;
	boolean Places[][]=new boolean[9][9];
	
	public SudokuFrame(boolean isDemo){
		setTitle("SudokuGenerator");
		setLayout(null);
		setBounds(0,0,450,328);
		if(isDemo) HintNumber = 24;
		
		OK=new JButton("OK");	
		OK.setBounds(335,140,60,30);
		add(OK);
		OK.addActionListener(this);
		Clear=new JButton("�N���A");	
		Clear.setBounds(325,180,80,30);
		add(Clear);
		Clear.addActionListener(this);
		
		HintLabel=new JLabel("�����z�u�̐�:"+HintNumber);
		HintLabel.setBounds(320,110,100,30);
		add(HintLabel);
		
		AllowBackTrack = new JCheckBox("���u���g�p",false);
		AllowBackTrack.setBounds(315, 70, 200, 30);
		add(AllowBackTrack);
		
		Outer = new JPanel();
		Outer.setLayout(null);
		Outer.setLocation(0,0);
		Outer.setPreferredSize(new Dimension(291,291));
		Outer.setSize(Outer.getPreferredSize());
		Outer.setBackground(Color.BLACK);
		Outer.setOpaque(true);
		Outer.setVisible(true);
		add(Outer);
		
		Panels = new SudokuPanel[9][9];
		for(int i = 0; i < Panels.length; i++){
			for(int j = 0 ; j < Panels[i].length; j++){
				Panels[i][j] = new SudokuPanel(i,j,this,isDemo);
				Outer.add(Panels[i][j]);
			}
		}
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == OK){
			if(HintNumber == 0){
				Alert = new SudokuAlert(this);
				return;
			}
			for(int i=0;i<9;i++)
				for(int j=0;j<9;j++)
					Places[i][j]=Panels[i][j].getIsClicked();
			setVisible(false);
			Creator=new Creator(Places,AllowBackTrack.isSelected());
			if(Creator.Creating()){
				new ResultFrame("��������",this);
			}else setVisible(true);
		}else{
			ResetPanels();
		}
	}
	
	public void RewriteHintNumber(int Number){
		HintLabel.setText("�����z�u�̐�:"+Integer.toString(Number));
		HintNumber = Number;
		repaint();
	}
	
	public void ResetPanels(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Panels[i][j].resetNumber();
		RewriteHintNumber(0);
	}
}

class SudokuAlert extends JDialog implements ActionListener{
	private static final long serialVersionUID = 1L;
	JFrame Parent;
	SudokuFrame SudokuParent;
	JLabel AlertLabel;
	JButton AlertOK;
	
	SudokuAlert(JFrame Owner){
		super(Owner,"�����z�u���G���[",true);
		setLayout(null);
		setSize(270,130);
		setLocationRelativeTo(null);
		
		Parent = Owner;
		if(Parent.getClass().getSimpleName() == "SudokuFrame") AlertLabel = new JLabel("�����z�u������܂���");
		AlertLabel.setBounds(70,10,160,30);
		add(AlertLabel);
		AlertOK = new JButton("OK");
		AlertOK.setBounds(100,50,60,30);
		add(AlertOK);
		AlertOK.addActionListener(this);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent arg0){
		dispose();
	}
}