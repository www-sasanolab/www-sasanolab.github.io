import java.io.*;

public class SudokuGenerator {

	public static void main(String[] args) {
		new SudokuFrame(false);
		
	}
}