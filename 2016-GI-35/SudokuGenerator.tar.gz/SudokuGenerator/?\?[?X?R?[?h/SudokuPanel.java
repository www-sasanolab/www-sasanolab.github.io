import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SudokuPanel extends JPanel implements MouseListener {
	private static final long serialVersionUID = 1L;
	private JLabel Value = null;
	private boolean isClicked = false;
	private int Number = 0;
	private boolean Blank=false;
	private boolean Visible=true;
	private static int Hint=0;
	private static Dimension PANELSIZE = new Dimension(32, 32);
	private SudokuFrame ParentFrame;
	private boolean CreatingMode = false,SolvingMode = false;
	
	public SudokuPanel(int i,int j,SudokuFrame Parent,boolean isDemo) {
		setPreferredSize(PANELSIZE);
		setSize(getPreferredSize());
		CreatingMode=true;
		
		if(i<3){
			if(j<3){
				setLocation(j*32, i*32);
			} else if(5<j) {
				setLocation(j*32+2, i*32);
			} else {
				setLocation(j*32+1, i*32);
			}
		} else if(5<i){
			if(j<3){
				setLocation(j*32, i*32+2);
			} else if(5<j) {
				setLocation(j*32+2, i*32+2);
			} else {
				setLocation(j*32+1, i*32+2);
			}
		} else {
			if(j<3){
				setLocation(j*32, i*32+1);
			} else if(5<j) {
				setLocation(j*32+2, i*32+1);
			} else {
				setLocation(j*32+1, i*32+1);
			}
		}
		
		setOpaque(true);
		setBackground(Color.WHITE);

		
		Value=new JLabel("�~");
		Value.setVisible(true);
		add(Value);
		addMouseListener(this);
		this.ParentFrame = Parent;
		setVisible(true);
		
		
		//	�������\�f���p
		if(isDemo){
			if((i==0 && j==5) || (i==0 && j==6) || (i==1 && j==1) || (i==1 && j==7) || 
				(i==2 && j==0) || (i==2 && j==3) || (i==2 && j==4) || (i==3 && j==0) || 
				(i==3 && j==3) || (i==3 && j==5) || (i==3 && j==6) || (i==4 && j==2) || 
		   		(i==4 && j==6) || (i==5 && j==2) || (i==5 && j==3) || (i==5 && j==5) || 
		   		(i==5 && j==8) || (i==6 && j==4) || (i==6 && j==5) || (i==6 && j==8) ||
		   		(i==7 && j==1) || (i==7 && j==7) || (i==8 && j==2) || (i==8 && j==3)){
				isClicked = true;
				Value.setText("��");
				setBackground(Color.LIGHT_GRAY);
				Hint++;
				ParentFrame.RewriteHintNumber(Hint);
			}
		}
		
		
		
	}
	
	//ResultFrame�p
	public SudokuPanel(int i, int j, boolean isInitial,int Initial) {
		setPreferredSize(PANELSIZE);
		setSize(getPreferredSize());
		
		if(i<3){
			if(j<3){
				setLocation(j*32, i*32);
			} else if(5<j) {
				setLocation(j*32+2, i*32);
			} else {
				setLocation(j*32+1, i*32);
			}
		} else if(5<i){
			if(j<3){
				setLocation(j*32, i*32+2);
			} else if(5<j) {
				setLocation(j*32+2, i*32+2);
			} else {
				setLocation(j*32+1, i*32+2);
			}
		} else {
			if(j<3){
				setLocation(j*32, i*32+1);
			} else if(5<j) {
				setLocation(j*32+2, i*32+1);
			} else {
				setLocation(j*32+1, i*32+1);
			}
		}
		
		setOpaque(true);
		setBackground(Color.WHITE);

		Number=Initial;
		Blank=!isInitial;
		Visible=!Blank;
		if(Visible) Value=new JLabel(Number+"");
		else Value=new JLabel(" ");
		if(Blank) Value.setForeground(Color.RED);
		Value.setVisible(true);
		add(Value);
		addMouseListener(this);
		setVisible(true);
	}
	
	public boolean getIsClicked(){
		return this.isClicked;
	}
	public int getNumber(){
		return this.Number;
	}
	
	public void resetNumber(){
		if(SolvingMode){
			Number=0;
			Hint=0;
			Value.setText(" ");
			setBackground(Color.WHITE);
		}else{
			isClicked = false;
			Hint = 0;
			Value.setText("�~");
			setBackground(Color.WHITE);
		}
	}
	
	public boolean getBlank(){
		return Blank;
	}
	
	public void changeVisible(){
		if(Blank){
			if(Visible)	Value.setText(" ");
			else Value.setText(Number+"");
			Visible=!Visible;
		}
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		//g.setColor(Color.WHITE);
		//g.fillRect(0, 0, 31, 31);
		g.setColor(Color.BLACK);
		g.drawRect(0, 0, 31, 31);
	}

	public void mouseClicked(MouseEvent e) {
		if(CreatingMode){
		isClicked = !isClicked;
			if(isClicked){
				//Value.setVisible(false);
				Value.setText("��");	
				setBackground(Color.LIGHT_GRAY);
				Hint++;
				ParentFrame.RewriteHintNumber(Hint);
				ParentFrame.HintNumber = Hint;
			}else{
				//Value.setVisible(true);
				Value.setText("�~");
				setBackground(Color.WHITE);
				Hint--;
				ParentFrame.RewriteHintNumber(Hint);
				ParentFrame.HintNumber = Hint;
			}
		}
		repaint();
	}

	public void mousePressed(MouseEvent e) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	public void mouseReleased(MouseEvent e) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	public void mouseEntered(MouseEvent e) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}

	public void mouseExited(MouseEvent e) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		
	}
	
}