import java.util.*;

public class Creator {
	Board Board;
	Solver Solver;
	boolean Places[][],AllowBackTrack;
	ArrayList<Board> History = new ArrayList<Board>();
	int Duplicated = 0;
	int Problem[][] = new int[9][9];
	int Answer[][] = new int[9][9];
	long PlacingTime = 0,SolvingTime = 0;
	
	Creator(boolean Places[][]){
		this.Places=Places;
	}
	
	Creator(boolean Places[][],boolean State){
		this.Places = Places;
		AllowBackTrack = State;
	}
	
	boolean Creating(){
	
		for(int i=0;i<10000;i++){
			System.out.print("�z�u "+(i+1)+"���:");
			Board = new Board(Places);
			if(Placing()){
				if(IsDuplicate()){
					System.out.println("�d��");
					Duplicated++;
					continue;
				}else System.out.println("����");
			}else{
				System.out.println("���s");
				continue;
			}
			DisplayBoard();
			Solver = new Solver(Board,AllowBackTrack);
			if(Solver.Solving()){
				DisplayResult(true);
				Problem = History.get(History.size()-1).OutputArray();
				Answer = Board.OutputArray();
				return true;
			}else{
				System.out.println("��T�����s");
			}
		}
		DisplayResult(false);
		return false;
	}
	
	boolean Placing(){
		Cell Initials[] = new Cell[Board.HintNumber];
		ArrayList<Cell> MinCells;
		ArrayList<Integer> MinAnswers;
		Board Copy;
		Random Rand = new Random();
		int Num = 0;
		int TempCandidates;
		int Row,Column;
		int MinCandidates = 9*9*9;
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Places[i][j]){
					Initials[Num] = Board.Cells[i][j];
					Num++;
				}
			}
		}
		for(int i=0;i<Board.HintNumber;i++){
			MinCells = new ArrayList<Cell>();
			MinAnswers = new ArrayList<Integer>();
			for(int j=0;j<Board.HintNumber;j++){
				if(Initials[j].Answer != 0) continue;
				Row = Initials[j].RowIndex;
				Column = Initials[j].ColumnIndex;
				for(int k=0;k<9;k++){
					if(!Initials[j].Candidate[k]) continue;
					Copy = Board.CopyBoard();
					Copy.Cells[Row][Column].SetAnswer(k+1);
					TempCandidates = Copy.GetCandidates();
					if(TempCandidates <= MinCandidates){
						if(TempCandidates < MinCandidates){
							MinCandidates = TempCandidates;
							MinCells = new ArrayList<Cell>();
							MinAnswers = new ArrayList<Integer>();
						}
						MinCells.add(Initials[j]);
						MinAnswers.add(k+1);
					}
				}
			}
			if(MinCells.size() < 1) return false;
			Num = Rand.nextInt(MinCells.size());
			MinCells.get(Num).SetAnswer(MinAnswers.get(Num));
			
		}
		
		return true;
	}
	
	boolean IsDuplicate(){
		for(int i=0;i<History.size();i++)
			if(IsEqual(History.get(i))) return true;
		History.add(Board.CopyBoard());
		return false;
	}
	
	boolean IsEqual(Board Histories){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				if(Board.Cells[i][j].Answer != Histories.Cells[i][j].Answer) return false;
		return true;
	}
	
	void DisplayBoard(){
		for(int i=0;i<9;i++){
			if(i==3||i==6) System.out.println("-----------");
			for(int j=0;j<9;j++){
				if(j==3||j==6) System.out.print("|");
				if(Board.Cells[i][j].Answer == 0) System.out.print("0");
				else System.out.print(Board.Cells[i][j].Answer);
			}
			System.out.println();
		}
	}
	
	void DisplayResult(boolean Result){
		if(Result){
			System.out.println("��T������");
			if(Board.IsBackTracked) System.out.println("�o�b�N�g���b�N�g�p");
			//Board.PrintArchives(true);
		}else System.out.println("���̃p�^�[���ł̖�萶���Ɏ��s���܂����B");
		System.out.println("�����z�u��:"+Board.HintNumber);
		System.out.println("�����p�^�[����:"+History.size());
		System.out.println("�d���p�^�[����:"+Duplicated);
	}
}
