import java.util.*;

public class Solver {
	Board Board,Temp;
	boolean AllowBackTrack;
	
	Solver(Board Board){
		this.Board = Board;
		this.Board.Narrowing();
	}
	
	Solver(Board Board,boolean State){
		this.Board = Board;
		this.Board.Narrowing();
		AllowBackTrack = State;
	}
	
	boolean Solving(){
		while(true){
			//Board.AddArchive();
			if(Rule1(Board)) continue;
			if(Rule2(Board)) continue;
			if(Rule3_4(Board)) continue;
			if(Rule5_6(Board)) continue;
			if(Rule7_8(Board)) continue;
			if(FishMethod(Board)) continue;
			if(HamadaLogic(Board)) continue;
			if(AllowBackTrack & !Board.IsBackTracked)
				if(BackTrack(Board)) continue;
			return Result(Board);
		}
	}
	
	boolean Rule1(Board Board){
		boolean Decide;
		int Answer;
		
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				Decide = false;
				Answer = 0;
				for(int k=0;k<9;k++){
					if(Board.Cells[i][j].Candidate[k]){
						if(!Decide){
							Decide = true;
							Answer = k+1;
						}else{
							Decide = false;
							break;
						}
					}
				}
				if(Decide){
					Board.Cells[i][j].SetAnswer(Answer);
					//Board.CurrentRecord.MethodName = "���_�K��1";
					Board.Archives.add(new Record(Board,1));
					return true;
				}
			}
		}
		return false;
	}
	
	boolean Rule2(Board Board){
		int Count[] = new int[9];

		
		for(int i=0;i<9;i++){
			Count = new int[] {0,0,0,0,0,0,0,0,0};
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Row[i][j].Candidate[k]) Count[k]++;
				}
			}
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Row[i][j].Candidate[k] && Count[k] == 1){
						Board.Row[i][j].SetAnswer(k+1);
						//Board.CurrentRecord.MethodName = "���_�K��2";
						Board.Archives.add(new Record(Board,2));
						return true;
					}
				}
			}
		}
		
		for(int i=0;i<9;i++){
			Count = new int[] {0,0,0,0,0,0,0,0,0};
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Column[i][j].Candidate[k]) Count[k]++;
				}
			}
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Column[i][j].Candidate[k] && Count[k] == 1){
						Board.Column[i][j].SetAnswer(k+1);
						//Board.CurrentRecord.MethodName = "���_�K��2";
						Board.Archives.add(new Record(Board,2));
						return true;
					}
				}
			}
		}
		
		for(int i=0;i<9;i++){
			Count = new int[] {0,0,0,0,0,0,0,0,0};
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Brock[i][j].Candidate[k]) Count[k]++;
				}
			}
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Brock[i][j].Candidate[k] && Count[k] == 1){
						Board.Brock[i][j].SetAnswer(k+1);
						//Board.CurrentRecord.MethodName = "���_�K��2";
						Board.Archives.add(new Record(Board,2));
						return true;
					}
				}
			}
		}
		return false;
	}

	boolean Rule3_4(Board Board){
		boolean Decide;
		boolean IsUpdated = false;
		Cell Current[]; //���ڃu���b�N
		Cell Target[];	//��␔���i�荞�ݑΏۃG���A
		
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Brock[i][j].Candidate[k]){
						Current = Board.Brock[i];
						//�K��3
						Decide = true;
						for(int l=0;l<9;l++){
							if(Current[j].ParentRow == Current[l].ParentRow) continue;
							if(Current[l].Candidate[k]){
								Decide = false;
								break;
							}
						}
						if(Decide){
							Target = Current[j].ParentRow;
							for(int l=0;l<9;l++){
								if(Target[l].ParentBrock == Current) continue;
								if(Target[l].Candidate[k]){
									Target[l].Candidate[k] = false;
									IsUpdated = true;
								}
							}
							if(IsUpdated){
								//Board.CurrentRecord.MethodName = "���_�K��3";
								Board.Archives.add(new Record(Board,3));
								return true;
							}
						}
						//�K��4
						Decide = true;
						for(int l=0;l<9;l++){
							if(Current[j].ParentColumn == Current[l].ParentColumn) continue;
							if(Current[l].Candidate[k]){
								Decide = false;
								break;
							}
						}
						if(Decide){
							Target = Current[j].ParentColumn;
							for(int l=0;l<9;l++){
								if(Target[l].ParentBrock == Current) continue;
								if(Target[l].Candidate[k]){
									Target[l].Candidate[k] = false;
									IsUpdated = true;
								}
							}
							if(IsUpdated){
								//Board.CurrentRecord.MethodName = "���_�K��4";
								Board.Archives.add(new Record(Board,4));
								return true;
							}
						}
					}
				}
				
			}
		}
		return false;
	}

	boolean Rule5_6(Board Board){
		boolean IsUpdated = false;
		Cell Current[];
		Cell Target[];
		
		//�s(�K��5)
		for(int i=0;i<9;i++){
			Current = Board.Row[i];
			//����
			for(int j=0;j<9;j++){
				//�}�X
				Target = null;
				for(int k=0;k<9;k++){
					if(k<4 & Current[k].Candidate[j]) Target = Current[k].ParentBrock;
					if((k>3 & k<7) & Current[k].Candidate[j]){
						if(Target != null){
							Target = null;
							break;
						}
						else Target = Current[k].ParentBrock;
					}
					if(k<6 & Current[k].Candidate[j]){
						if(Target != null){
							Target = null;
							break;
						}
						else Target = Current[k].ParentBrock;
					}
				}
				if(Target != null){
					for(int k=0;k<9;k++){
						if(Target[k].ParentRow == Current) continue;
						if(Target[k].Candidate[j]){
							Target[k].Candidate[j] = false;
							IsUpdated = true;
						}
					}
					if(IsUpdated){
						//Board.CurrentRecord.MethodName = "���_�K��5";
						Board.Archives.add(new Record(Board,5));
						return true;
					}
				}
			}
		}
		
		//��(�K��6)
				for(int i=0;i<9;i++){
					Current = Board.Column[i];
					//����
					for(int j=0;j<9;j++){
						//�}�X
						Target = null;
						for(int k=0;k<9;k++){
							if(k<4 & Current[k].Candidate[j]) Target = Current[k].ParentBrock;
							if((k>3 & k<7) & Current[k].Candidate[j]){
								if(Target != null){
									Target = null;
									break;
								}
								else Target = Current[k].ParentBrock;
							}
							if(k<6 & Current[k].Candidate[j]){
								if(Target != null){
									Target = null;
									break;
								}
								else Target = Current[k].ParentBrock;
							}
						}
						if(Target != null){
							for(int k=0;k<9;k++){
								if(Target[k].ParentColumn == Current) continue;
								if(Target[k].Candidate[j]){
									Target[k].Candidate[j] = false;
									IsUpdated = true;
								}
							}
							if(IsUpdated){
								//Board.CurrentRecord.MethodName = "���_�K��6";
								Board.Archives.add(new Record(Board,6));
								return true;
							}
						}
					}
				}
	
		return false;
	}
	
	boolean Rule7_8(Board Board){
		int Empty;
		int Applied;
		Cell Current[];
		
		//�s
		for(int i=0;i<9;i++){
			Current = Board.Row[i];
			Empty = 0;
			for(int j=0;j<9;j++)
				if(Current[j].Answer == 0) Empty++;
			if(Empty < 4) continue;
			if((Applied = Branch7_8(Current,Empty)) > 0){
				//Board.CurrentRecord.MethodName += "(�s)";
				Board.Archives.add(new Record(Board,Applied));
				return true;
			}
		}
		
		//��
		for(int i=0;i<9;i++){
			Current = Board.Column[i];
			Empty = 0;
			for(int j=0;j<9;j++)
				if(Current[j].Answer == 0) Empty++;
			if(Empty < 4) continue;
			if((Applied = Branch7_8(Current,Empty)) > 0){
				//Board.CurrentRecord.MethodName += "(��)";
				Board.Archives.add(new Record(Board,Applied));
				return true;
			}
		}
		
		//�u���b�N
		for(int i=0;i<9;i++){
			Current = Board.Brock[i];
			Empty = 0;
			for(int j=0;j<9;j++)
				if(Current[j].Answer == 0) Empty++;
			if(Empty < 4) continue;
			if((Applied = Branch7_8(Current,Empty)) > 0){
				//Board.CurrentRecord.MethodName += "(�u���b�N)";
				Board.Archives.add(new Record(Board,Applied));
				return true;
			}
		}
		return false;
	}
	
	int Branch7_8(Cell Target[],int Empty){
		boolean Applied7 = false;
		boolean Applied8 = false;
		
		for(int i=2;i<Empty-1;i++){
			if(i <= Empty/2){
				switch(i){
				case 2: Applied7 = Apply7_2(Target);break;
				case 3: Applied7 = Apply7_3(Target);break;
				case 4: Applied7 = Apply7_4(Target);break;
				}
			}else{
				switch(Empty-i){
				case 2: Applied8 = Apply8_2(Target);break;
				case 3: Applied8 = Apply8_3(Target);break;
				case 4: Applied8 = Apply8_4(Target);break;
				}
			}
			if(Applied7) return 7;
			if(Applied8) return 8;
		}
		return -1;
	}
	
	boolean Apply7_2(Cell Target[]){
		boolean IsUpdated = false;
		boolean ORCheck[] = new boolean[9];
		int Number;
		
		for(int i=0;i<8;i++){
			if(Target[i].Answer != 0 | Target[i].CandidateCheck() > 2) continue;
			for(int j=i+1;j<9;j++){
				if(Target[j].Answer != 0 | Target[j].CandidateCheck() > 2) continue;
				Number = 0;
				for(int k=0;k<9;k++){
					ORCheck[k] = Target[i].Candidate[k] | Target[j].Candidate[k];
					if(ORCheck[k]) Number++; 
				}
				if(Number == 2){
					for(int k=0;k<9;k++){
						if(k == i | k == j) continue;
						for(int l=0;l<9;l++){
							if(Target[k].Candidate[l] & ORCheck[l]){
								IsUpdated = true;
								Target[k].Candidate[l] = false;
							}
						}							
					}
					if(IsUpdated){
						//Board.CurrentRecord.MethodName = "���_�K��7-2";
						return true;
					}
				}
			}
		}
		return false;
	}
	
	boolean Apply7_3(Cell Target[]){
		boolean IsUpdated = false;
		boolean ORCheck[] = new boolean[9];
		int Number;
		
		for(int i=0;i<7;i++){
			if(Target[i].Answer != 0 | Target[i].CandidateCheck() > 3) continue;
			for(int j=i+1;j<8;j++){
				if(Target[j].Answer != 0 | Target[j].CandidateCheck() > 3) continue;
				for(int k=j+1;k<9;k++){
					if(Target[k].Answer != 0 | Target[k].CandidateCheck() > 3) continue;
					Number = 0;
					for(int l=0;l<9;l++){
						ORCheck[l] = Target[i].Candidate[l] | Target[j].Candidate[l] | Target[k].Candidate[l];
						if(ORCheck[l]) Number++; 
					}
					if(Number == 3){
						for(int l=0;l<9;l++){
							if(l == i | l == j | l == k) continue;
							for(int m=0;m<9;m++){
								if(Target[l].Candidate[m] & ORCheck[m]){
									IsUpdated = true;
									Target[l].Candidate[m] = false;
								}
							}							
						}
						if(IsUpdated){
							//Board.CurrentRecord.MethodName = "���_�K��7-3";
							return true;
						}
					}else continue;
				}
			}
		}
		return false;
	}
	
	boolean Apply7_4(Cell Target[]){
		boolean IsUpdated = false;
		boolean ORCheck[] = new boolean[9];
		int Number;
		
		for(int i=0;i<6;i++){
			if(Target[i].Answer != 0 | Target[i].CandidateCheck() > 4) continue;
			for(int j=i+1;j<7;j++){
				if(Target[j].Answer != 0 | Target[j].CandidateCheck() > 4) continue;
				for(int k=j+1;k<8;k++){
					if(Target[k].Answer != 0 | Target[k].CandidateCheck() > 4) continue;
					for(int l=k+1;l<9;l++){
						if(Target[l].Answer != 0 | Target[l].CandidateCheck() > 4) continue;
						Number = 0;
						for(int m=0;m<9;m++){
							ORCheck[m] = Target[i].Candidate[m] | Target[j].Candidate[m] | Target[k].Candidate[m] | Target[l].Candidate[m];
							if(ORCheck[l]) Number++; 
						}
						if(Number == 4){
							for(int m=0;m<9;m++){
								if(m == i | m == j | m == k | m == l) continue;
								for(int n=0;n<9;n++){
									if(Target[m].Candidate[n] & ORCheck[n]){
										IsUpdated = true;
										Target[m].Candidate[n] = false;
									}
								}							
							}
							if(IsUpdated){
								//Board.CurrentRecord.MethodName = "���_�K��7-4";
								return true;
							}
						}else continue;
					}
				}
			}
		}
		return false;
	}
	
	boolean Apply8_2(Cell Target[]){
		boolean IsUpdated = false;
		int Number;
		boolean Eraser[];
		
		for(int i=0;i<8;i++){
			for(int j=i+1;j<9;j++){
				Number = 0;
				Eraser = new boolean[9];
				for(int k=0;k<9;k++){
					Eraser[i] |= Target[k].Candidate[i];
					Eraser[j] |= Target[k].Candidate[j];
					if(Target[k].Candidate[i] | Target[k].Candidate[j]) Number++;
				}
				if(!Eraser[i] | !Eraser[j]) continue;
				if(Number == 2){
					for(int k=0;k<9;k++){
						if(!Target[k].Candidate[i] & !Target[k].Candidate[j]) continue;
						for(int l=0;l<9;l++){
							if(Target[k].Candidate[l] & !Eraser[l]) IsUpdated = true;
							Target[k].Candidate[l] &= Eraser[l];
						}
					}
					if(IsUpdated){
						//Board.CurrentRecord.MethodName = "���_�K��8-2";
						return true;
					}
				}
			}
		}
		return false;
	}
	
	boolean Apply8_3(Cell Target[]){
		boolean IsUpdated = false;
		int Number;
		boolean Eraser[];
		
		for(int i=0;i<7;i++){
			for(int j=i+1;j<8;j++){
				for(int k=j+1;k<9;k++){
					Number = 0;
					Eraser = new boolean[9];
					for(int l=0;l<9;l++){
						Eraser[i] |= Target[l].Candidate[i];
						Eraser[j] |= Target[l].Candidate[j];
						Eraser[k] |= Target[l].Candidate[k];
						if(Target[l].Candidate[i] | Target[l].Candidate[j] | Target[l].Candidate[k]) Number++;
					}
					if(!Eraser[i] | !Eraser[j] | !Eraser[k]) continue;
					if(Number == 3){
						for(int l=0;l<9;l++){
							if(!Target[l].Candidate[i] & !Target[l].Candidate[j] & !Target[l].Candidate[k]) continue;
							for(int m=0;m<9;m++){
								if(Target[l].Candidate[m] & !Eraser[m]) IsUpdated = true;
								Target[l].Candidate[m] &= Eraser[m];
							}
						}
						if(IsUpdated){
							//Board.CurrentRecord.MethodName = "���_�K��8-3";
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	boolean Apply8_4(Cell Target[]){
		boolean IsUpdated = false;
		int Number;
		boolean Eraser[];
		
		for(int i=0;i<7;i++){
			for(int j=i+1;j<8;j++){
				for(int k=j+1;k<9;k++){
					for(int l=k+1;l<9;l++){
						Number = 0;
						Eraser = new boolean[9];
						for(int m=0;m<9;m++){
							Eraser[i] |= Target[m].Candidate[i];
							Eraser[j] |= Target[m].Candidate[j];
							Eraser[k] |= Target[m].Candidate[k];
							Eraser[l] |= Target[m].Candidate[l];
							if(Target[m].Candidate[i] | Target[m].Candidate[j] | Target[m].Candidate[k] | Target[m].Candidate[l])
								Number++;
						}
						if(!Eraser[i] | !Eraser[j] | !Eraser[k] | !Eraser[l]) continue;
						if(Number == 4){
							for(int m=0;m<9;m++){
								if(!Target[m].Candidate[i] & !Target[m].Candidate[j] & !Target[m].Candidate[k] & !Target[m].Candidate[l])
									continue;
								for(int n=0;n<9;n++){
									if(Target[m].Candidate[n] & !Eraser[n]) IsUpdated = true;
									Target[m].Candidate[n] &= Eraser[n];
								}
							}
							if(IsUpdated){
								//Board.CurrentRecord.MethodName = "���_�K��8-4";
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	
	boolean FishMethod(Board Board){
		Cell Fish[] = new Cell[9];
		boolean IsUpdated = false;
		
		//�s
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++) Fish[j] = new Cell(1);
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Row[j][k].Candidate[i]){
						Fish[j].Candidate[k] = true;
						Fish[j].Answer = 0;
					}
				}
			}
			if(Branch7_8(Fish,9) > 0){
				IsUpdated = false;
				for(int j=0;j<9;j++){
					for(int k=0;k<9;k++){
						if(Board.Row[j][k].Candidate[i] & !Fish[j].Candidate[k]){
							IsUpdated = true;
							Board.Row[j][k].Candidate[i] = false;
						}
					}
				}
				if(IsUpdated){
					//Board.CurrentRecord.MethodName = "Fish��@";
					Board.Archives.add(new Record(Board,9));
					return true;
				}
			}
		}
		
		//��
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++) Fish[j] = new Cell(1);
			for(int j=0;j<9;j++){
				for(int k=0;k<9;k++){
					if(Board.Column[j][k].Candidate[i]){
						Fish[j].Candidate[k] = true;
						Fish[j].Answer = 0;
					}
				}
			}
			if(Branch7_8(Fish,9) > 0){
				IsUpdated = false;
				for(int j=0;j<9;j++){
					for(int k=0;k<9;k++){
						if(Board.Column[j][k].Candidate[i] & !Fish[j].Candidate[k]){
							IsUpdated = true;
							Board.Column[j][k].Candidate[i] = false;
						}
					}
				}
				if(IsUpdated){
					//Board.CurrentRecord.MethodName = "Fish��@";
					Board.Archives.add(new Record(Board,9));
					return true;
				}
			}
		}
		
		return false;
	}
	
	boolean HamadaLogic(Board Board){
		int X,Y;
		Cell Head;
		boolean Mask[] = new boolean[9];
		boolean EvenRows[];
		boolean OddRows[];
		boolean EvenColumns[];
		boolean OddColumns[];
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				X = -1;
				Y = -1;
				Head = Board.Cells[i][j];
				if(Head.CandidateCheck() == 2 & Head.Chain == null){
					EvenRows = new boolean[9];
					EvenColumns = new boolean[9];
					OddRows = new boolean[9];
					OddColumns = new boolean[9];
					for(int k=0;k<9;k++){
						Mask[k] = Head.Candidate[k];
						if(Mask[k]){
							if(X < 0) X = k;
							else Y = k;
						}
					}
					SameArea(Head);
					if(Head.Chain.size() == 0) continue;
					GetChain(Head,EvenRows,EvenColumns,OddRows,OddColumns,true);
					//�����E�s
					if(CheckChain(Head,Board.Row,X,Y,EvenRows,EvenColumns,true)){
						Board.ResetChain();
						//Board.CurrentRecord.MethodName = "�l�c���W�b�N";
						Board.Archives.add(new Record(Board,10));
						return true;
					}
					//�����E��
					if(CheckChain(Head,Board.Column,X,Y,EvenColumns,EvenRows,true)){
						Board.ResetChain();
						//Board.CurrentRecord.MethodName = "�l�c���W�b�N";
						Board.Archives.add(new Record(Board,10));
						return true;
					}
					//��E�s
					if(CheckChain(Head,Board.Row,X,Y,OddRows,OddColumns,false)){
						Board.ResetChain();
						//Board.CurrentRecord.MethodName = "�l�c���W�b�N";
						Board.Archives.add(new Record(Board,10));
						return true;
					}
					//��E��
					if(CheckChain(Head,Board.Column,X,Y,EvenColumns,EvenRows,false)){
						Board.ResetChain();
						//Board.CurrentRecord.MethodName = "�l�c���W�b�N";
						Board.Archives.add(new Record(Board,10));
						return true;
					}
				}
			}
		}
		Board.ResetChain();
		return false;
	}

	void SameArea(Cell Current){
		Cell Target[];
		
		if(Current.Chain == null) Current.Chain = new ArrayList<Cell>();
		Target = Current.ParentRow;
		for(int i=0;i<9;i++){
			if(Target[i].Chain != null) continue;
			if(Target[i].CandidateCheck() != 2) continue;
			if(Arrays.equals(Target[i].Candidate,Current.Candidate)){
				Current.Chain.add(Target[i]);
				SameArea(Target[i]);
			}
		}
		Target = Current.ParentColumn;
		for(int i=0;i<9;i++){
			if(Target[i].Chain != null) continue;
			if(Target[i].CandidateCheck() != 2) continue;
			if(Arrays.equals(Target[i].Candidate,Current.Candidate)){
				Current.Chain.add(Target[i]);
				SameArea(Target[i]);
			}
		}
		Target = Current.ParentBrock;
		for(int i=0;i<9;i++){
			if(Target[i].Chain != null) continue;
			if(Target[i].CandidateCheck() != 2) continue;
			if(Arrays.equals(Target[i].Candidate,Current.Candidate)){
				Current.Chain.add(Target[i]);
				SameArea(Target[i]);
			}
		}
		return;
	}
	
	boolean CheckChain(Cell Head,Cell Target[][],int X,int Y,boolean Mask1[],boolean Mask2[],boolean IsEven){
		//Mask1 : �Ώۗ̈�Ɠ�������
		//Mask2 : �Ώۗ̈�ƈقȂ鑮��
		//Example �Ώ�:�s �� Mask1:Chain�}�X�ܗL�s,Mask2:Chain�}�X�ܗL��
		boolean IsApply;
		
		for(int i=0;i<9;i++){
			if(Mask1[i]) continue;
			IsApply = false;
			for(int j=0;j<9;j++){
				if(Target[i][j].Candidate[X]){
					if(Mask2[j]) IsApply = true;
					else{
						IsApply = false;
						break;
					}
				}
			}
			if(IsApply){
				DecideChain(Head,X,Y,IsEven);
				return true;
			}
			IsApply = false;
			for(int j=0;j<9;j++){
				if(Target[i][j].Candidate[Y]){
					if(Mask2[j]) IsApply = true;
					else{
						IsApply = false;
						break;
					}
				}
			}
			if(IsApply){
				DecideChain(Head,Y,X,IsEven);
				return true;
			}
		}
		
		return false;
	}
	
	void GetChain(Cell Current,boolean EvenRows[],boolean EvenColumns[],
			boolean OddRows[],boolean OddColumns[],boolean IsEven){
		if(IsEven){
			EvenRows[Current.RowIndex] = true;
			EvenColumns[Current.ColumnIndex] = true;
		}else{
			OddRows[Current.RowIndex] = true;
			OddColumns[Current.ColumnIndex] = true;
		}
		if(Current.Chain.size() == 0) return;
		for(int i=0;i<Current.Chain.size();i++)
			GetChain(Current.Chain.get(i),EvenRows,EvenColumns,OddRows,OddColumns,!IsEven);
		return;
	}
	
	void DecideChain(Cell Current,int X,int Y,boolean IsEven){
		if(IsEven) Current.Candidate[X] = false;
		else Current.Candidate[Y] = false;
		if(Current.Chain == null) return;
		for(int i=0;i<Current.Chain.size();i++)
			DecideChain(Current.Chain.get(i),X,Y,!IsEven);
		return;
	}
	
	boolean BackTrack(Board Board){
		int X,Y;
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Board.Cells[i][j].CandidateCheck() == 2){
					X = 0;
					Y = 0;
					for(int k=0;k<9;k++){
						if(Board.Cells[i][j].Candidate[k]){
							if(X == 0) X = k+1;
							else Y = k+1;
						}
					}
					Board.Tracking();
					Board.Cells[i][j].SetAnswer(X);
					//Board.CurrentRecord.MethodName = "�o�b�N�g���b�N";
					while(true){
						if(Rule1(Board)) break;
						if(Rule2(Board)) break;
						if(Rule3_4(Board)) break;
						if(Rule5_6(Board)) break;
						if(Rule7_8(Board)) break;
						if(FishMethod(Board)) break;
						if(HamadaLogic(Board)) break;
						break;
					}
					if(!IsValid(Board)){
						Board.Restoring();
						Board.Cells[i][j].Candidate[X-1] = false;
						Board.IsBackTracked = true;
						return true;
					}else{
						Board.Restoring();
						Board.Cells[i][j].SetAnswer(Y);
						while(true){
							if(Rule1(Board)) break;
							if(Rule2(Board)) break;
							if(Rule3_4(Board)) break;
							if(Rule5_6(Board)) break;
							if(Rule7_8(Board)) break;
							if(FishMethod(Board)) break;
							if(HamadaLogic(Board)) break;
							break;
						}
						if(!IsValid(Board)){
							Board.Restoring();
							Board.Cells[i][j].Candidate[Y-1] = false;
							Board.IsBackTracked = true;
							return true;
						}else Board.Restoring();
					}
					
				}
			}
		}
		
		return false;
	}
	
	boolean IsValid(Board Board){
		boolean Check;
		
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Board.Cells[i][j].Answer != 0) continue;
				Check = false;
				for(int k=0;k<9;k++)
					Check |= Board.Cells[i][j].Candidate[k];
				if(!Check) return false;
			}
		}
		
		return true;
			
	}
	
	boolean Result(Board Board){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				if(Board.Cells[i][j].Answer == 0) return false;
		return true;
	}
}