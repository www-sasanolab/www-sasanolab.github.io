import java.util.*;
import java.io.*;

public class Board {
	Cell Cells[][] = new Cell[9][9];
	Cell Row[][] = new Cell[9][9];
	Cell Column[][] = new Cell[9][9];
	Cell Brock[][] = new Cell[9][9];
	Cell Track[][] = new Cell[9][9];
	int CandidateNumber = 0;
	int HintNumber = 0;
	boolean IsBackTracked = false;
	ArrayList<Record> Archives = new ArrayList<Record>();
	Record CurrentRecord;
	
	//��T���p�R���X�g���N�^
	Board(int Initials[][]){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Cells[i][j] = new Cell(this);
		SetParents();
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Initials[i][j] != 0){
					Cells[i][j].SetAnswer(Initials[i][j]);
					HintNumber++;
				}
			}
		}
	}
	//��萶���p�R���X�g���N�^
	Board(boolean Praces[][]){
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Praces[i][j]) HintNumber++;
				Cells[i][j] = new Cell(this);
			}
		}
		SetParents();
	}
	
	//�s�E��E�u���b�N�֌W�ݒ�
	void SetParents(){
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				Row[i][j] = Cells[i][j];
				Column[i][j] = Cells[j][i];
				Brock[i][j] = Cells[3*(i/3)+j/3][3*(i%3)+j%3];
				Cells[i][j].RowIndex = i;
				Cells[i][j].ColumnIndex = j;
				Cells[i][j].BrockIndex = 3*(i/3)+j/3;
				Cells[i][j].ParentRow = Row[i];
				Cells[i][j].ParentColumn = Column[j];
				Cells[i][j].ParentBrock = Brock[3*(i/3)+j/3];
			}
		}
	}
	
	//��␔�����v�l�̎Z�o
	int GetCandidates(){
		int Number = 0;
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Number += Cells[i][j].CandidateCheck();
		return Number;
	}
	
	//��␔���̍i����
	void Narrowing(){
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				if(Cells[i][j].Answer!=0){
					for(int k=0;k<9;k++) Cells[k][j].Candidate[Cells[i][j].Answer-1] = false;
					for(int k=0;k<9;k++) Cells[i][k].Candidate[Cells[i][j].Answer-1] = false;
					for(int k=0;k<9;k++) Brock[3*(i/3)+j/3][k].Candidate[Cells[i][j].Answer-1] = false;
				}
			}
		}
	}
	
	//���֌W�̃��Z�b�g
	void ResetChain(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Cells[i][j].Chain = null;
	}
	
	//���̃R�s�[(�o�b�N�g���b�N�p)
	Board CopyBoard(){
		return new Board(OutputArray());
	}
	
	//�Ֆʏ󋵂̕ۑ�
	void Tracking(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Track[i][j] = Cells[i][j].Tracking();
	}
	
	//�Ֆʏ󋵂̕���
	void Restoring(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Cells[i][j].Restoring(Track[i][j]);
	}
	
	//�s�E��E�u���b�N���̐����̏d���`�F�b�N
	boolean IsDuplicate(){
		boolean Numbers[];
		
		for(int i=0;i<9;i++){
			Numbers = new boolean[9];
			for(int j=0;j<9;j++){
				if(Row[i][j].Answer == 0) continue;
				if(Numbers[Row[i][j].Answer-1]) return false;
				else Numbers[Row[i][j].Answer-1] = true;
			}
		}
		for(int i=0;i<9;i++){
			Numbers = new boolean[9];
			for(int j=0;j<9;j++){
				if(Column[i][j].Answer == 0) continue;
				if(Numbers[Column[i][j].Answer-1]) return false;
				else Numbers[Column[i][j].Answer-1] = true;
			}
		}for(int i=0;i<9;i++){
			Numbers = new boolean[9];
			for(int j=0;j<9;j++){
				if(Brock[i][j].Answer == 0) continue;
				if(Numbers[Brock[i][j].Answer-1]) return false;
				else Numbers[Brock[i][j].Answer-1] = true;
			}
		}
		
		return true;
	}
	
	//�󔒂̗L�����`�F�b�N
	boolean IsCompleted(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				if(Cells[i][j].Answer == 0) return false;
		return true;
	}
	
	//����int�^�z��ŏo��
	int[][] OutputArray(){
		int Problem[][] = new int[9][9];
		
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				Problem[i][j] = Cells[i][j].Answer;
		
		return Problem;
	}
	
	//�Ֆʂ̃}�X�̏󋵂�\��
	void PrintBoard(){
		for(int i=0;i<9;i++){
			for(int j=0;j<9;j++){
				System.out.print(Cells[i][j].Answer);
				if(j == 8) System.out.println();
				else System.out.print(",");
			}
		}
	}
	
	//�K�p��@�̗����ƓK�p�񐔂�\��
	void PrintArchives(boolean isSolved){
		int Count[] = new int[11];
		int Method;
		Record Current;
		for(int i=0;i<Archives.size();i++){
			Current = Archives.get(i);
			Method = Current.ApplyedMethod;
			Count[Method - 1]++;
			System.out.print((i+1)+":");
			if(Method < 9) System.out.println("���_�K��"+Method);
			if(Method == 9) System.out.println("Fish��@");
			if(Method == 10) System.out.println("�l�c���W�b�N");
			if(Method == 11) System.out.println("�o�b�N�g���b�N,�Ώۃ}�X("+Current.AssumedRow+","+Current.AssumedColumn+"),�m�萔��("+Current.AssumedNumber+")");
			
		}
		if(isSolved){
			for(int i=0;i<10;i++){
				if(i < 8) System.out.print("���_�K��"+(i+1)+":");
				if(i == 8) System.out.print("Fish��@:");
				if(i == 9) System.out.print("�l�c���W�b�N:");
				System.out.println(Count[i]+"��");
			}
			if(Count[10] != 0) System.out.println("�o�b�N�g���b�N�g�p");
		}
	}
	
	void AddArchive(){
		CurrentRecord = new Record(this);
		Archives.add(CurrentRecord);
	}
}

class Cell {
	Board ParentBoard;
	Cell ParentRow[];
	Cell ParentColumn[];
	Cell ParentBrock[];
	int Answer,RowIndex,ColumnIndex,BrockIndex;
	boolean Candidate[] = new boolean[9];
	ArrayList<Cell> Chain;
	
	Cell(Board Board){
		ParentBoard = Board;
		Answer = 0;
		for(int i=0;i<9;i++)
			Candidate[i] = true;
	}
	Cell(int Number){
		Answer = Number;
	}
	
	int CandidateCheck(){
		int Number = 0;
		for(int i=0;i<9;i++)
			if(Candidate[i]) Number++;
		return Number;
	}
	
	void SetAnswer(int Number){
		Answer = Number;
		ParentBoard.Narrowing();
		for(int i=0;i<9;i++)
			Candidate[i] = false;
		//ParentBoard.CurrentRecord.Status += "["+(RowIndex+1)+","+(ColumnIndex+1)+","+Number+"]";
		//Narrowing(Number);
	}
	
	void Erasing(int Number){
		if(Candidate[Number-1]){
			Candidate[Number-1] = false;
			ParentBoard.CurrentRecord.Status += "<"+(RowIndex+1)+","+(ColumnIndex+1)+","+Number+">";
		}
	}
	
	void Narrowing(int Number){
		for(int i=0;i<9;i++){
			ParentRow[i].Erasing(Number);
			ParentColumn[i].Erasing(Number);
			ParentBrock[i].Erasing(Number);
		}
	}
	
	Cell Tracking(){
		Cell Track = new Cell(Answer);
		for(int i=0;i<9;i++) Track.Candidate[i] = Candidate[i];
		return Track;		
	}
	
	void Restoring(Cell Track){
		Answer = Track.Answer;
		for(int i=0;i<9;i++) Candidate[i] = Track.Candidate[i];
	}
	
}

class Record{
	Board ParentBoard;
	int State[][] = new int[9][9];
	int Candidetes;
	int ApplyedMethod;
	int AssumedRow,AssumedColumn,AssumedNumber;
	String MethodName,Status;
	int Diminution;
	
	Record(Board Board){
		ParentBoard = Board;
		GetBoardState();
	}
	
	Record(Board Board,int Method){
		ParentBoard = Board;
		ApplyedMethod = Method;
		GetBoardState();
	}
	
	Record(Board Board,int Number,int Row,int Column){
		ParentBoard = Board;
		ApplyedMethod = 11;
		AssumedNumber = Number;
		AssumedRow = Row;
		AssumedColumn = Column;
		GetBoardState();
	}
	
	void GetBoardState(){
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++)
				State[i][j] = ParentBoard.Cells[i][j].Answer;
		Candidetes = ParentBoard.GetCandidates();
	}
	
}
