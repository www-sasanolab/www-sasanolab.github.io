[Organization of files]
  readme.txt: This file
  clonedetect.patch: A patch file
  data/: A directory which contains the results of applying the tool
         to SML# compiler source code

[How to compile the tool]
1. Download SML# compiler version 2.0.0 from the following URL.
     http://www.pllab.riec.tohoku.ac.jp/smlsharp/?Download
2. Configure, make and make install SML# compiler version 2.0.0
   following the instruction of the SML# compiler
3. The directory smlsharp-2.0.0/ is the top directory of the SML# compiler.
   In its parent directory execute the following command.
     patch -p0 < clonedetect.patch
4. Make again SML# compiler.

[How to use the tool]
In the directory smlsharp-2.0.0/, which is the top directory of SML# compiler,
execute the following command.
   src/compiler/smlsharp <directory_name>
Here <directory_name> is the path to the directory containing the source code
written in Standard ML which you would like to detect clones for.
When executing the above command, you will be asked to input two thresholds.
One is th_size, which is the threshold of the size of the clones.
The other is th_para, which is the threshold of the number of
parameters of functions to be extracted.  
For example, you can input as follows.

input th_size: 10
input th_para: 0.1

We have checked the tool on Ubuntu 14 32bit with gcc 
(Ubuntu 4.8.4-2ubuntu1~14.04) 4.8.4, llvm 3.4.

Note that currently there is a bug in the extraction of functions,
so wrong functions are generated and presented. 

[How to read the results]
The director data/ includes the detected clones for each threshold
in the SML# compiler source code for those who would like to see
just the results. 
For example, the directory data/10-0.1 contains the results
for th_size=10 and th_para=0.1.
The files output_....txt contain the detected clones 
from the directory src/compiler/ in the SML# compiler
in the following form.

n
fileName1 (with the path to the file)
begin, end = (a, b), (c, d)
fileName2 (with the path to the file)
begin, end = (x, y), (z, w)

This indicates the the n-th detected pair of clones. 
One is from a-th row and b-th column to c-th row and d-th column
in the file fileName1.
The other is from x-th row and y-th column to z-th row and w-th column
in the file fileName2.
