import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SudokuPanel extends JPanel implements MouseListener {
	private static final long serialVersionUID = 1L;
	private JLabel value = null;
	private boolean isClicked = false;
	private boolean isPlace = false;
	private boolean isVisible = false;
	private int number = 0;
	private boolean blank=false;
	private static int hint=0;
	private static Dimension PANELSIZE = new Dimension(32, 32);
	private SudokuFrame parent;
	
	public SudokuPanel(SudokuFrame frame){
		setPreferredSize(PANELSIZE);
		setSize(getPreferredSize());
		setOpaque(true);
		this.parent = frame;
	}
	
	public void createInit(){
		setBackground(Color.WHITE);
		value=new JLabel("×");
		value.setVisible(true);
		add(value);
		addMouseListener(this);
	}
	
	public void solveInit(){
		setBackground(Color.WHITE);
		value=new JLabel(" ");
		value.setVisible(true);
		add(value);
		addMouseListener(this);
		number = 0;
	}
	
	public void resultInit(int num,boolean isPlace){
		number = num;
		this.isPlace = isPlace;
		this.isVisible = isPlace;
		setBackground(Color.WHITE);
		value=new JLabel();
		if(!isPlace)	value.setForeground(Color.RED);
		value.setText(""+number);
		value.setVisible(isVisible);
		add(value);
		addMouseListener(this);
	}
	
//	public SudokuPanel(int i,int j,SudokuFrame parent,boolean isDemo) {
//		setPreferredSize(PANELSIZE);
//		setSize(getPreferredSize());
//		creatingMode=true;
//		
//		if(i<3){
//			if(j<3){
//				setLocation(j*32, i*32);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32);
//			} else {
//				setLocation(j*32+1, i*32);
//			}
//		} else if(5<i){
//			if(j<3){
//				setLocation(j*32, i*32+2);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+2);
//			} else {
//				setLocation(j*32+1, i*32+2);
//			}
//		} else {
//			if(j<3){
//				setLocation(j*32, i*32+1);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+1);
//			} else {
//				setLocation(j*32+1, i*32+1);
//			}
//		}
//		
//		setOpaque(true);
//		setBackground(Color.WHITE);
//
//		
//		value=new JLabel("×");
//		value.setVisible(true);
//		add(value);
//		addMouseListener(this);
//		this.parentFrame = parent;
//		setVisible(true);
//		
//		
//		//	卒研発表デモ用
//		if(isDemo){
//			if((i==0 && j==5) || (i==0 && j==6) || (i==1 && j==1) || (i==1 && j==7) || 
//				(i==2 && j==0) || (i==2 && j==3) || (i==2 && j==4) || (i==3 && j==0) || 
//				(i==3 && j==3) || (i==3 && j==5) || (i==3 && j==6) || (i==4 && j==2) || 
//		   		(i==4 && j==6) || (i==5 && j==2) || (i==5 && j==3) || (i==5 && j==5) || 
//		   		(i==5 && j==8) || (i==6 && j==4) || (i==6 && j==5) || (i==6 && j==8) ||
//		   		(i==7 && j==1) || (i==7 && j==7) || (i==8 && j==2) || (i==8 && j==3)){
//				isClicked = true;
//				value.setText("○");
//				setBackground(Color.LIGHT_GRAY);
//				hint++;
//				//parentFrame.rewriteHintNumber(hint);
//			}
//		}
//		
//		
//		
//	}
//	
//	//SolvingFrame用
//	public SudokuPanel(int i,int j,SolvingFrame parent) {
//		setPreferredSize(PANELSIZE);
//		setSize(getPreferredSize());
//		solveFrame = parent;
//		solvingMode=true;
//		
//		if(i<3){
//			if(j<3){
//				setLocation(j*32, i*32);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32);
//			} else {
//				setLocation(j*32+1, i*32);
//			}
//		} else if(5<i){
//			if(j<3){
//				setLocation(j*32, i*32+2);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+2);
//			} else {
//				setLocation(j*32+1, i*32+2);
//			}
//		} else {
//			if(j<3){
//				setLocation(j*32, i*32+1);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+1);
//			} else {
//				setLocation(j*32+1, i*32+1);
//			}
//		}
//		
//		setOpaque(true);
//		setBackground(Color.WHITE);
//
//		
//		value=new JLabel(" ");
//		value.setVisible(true);
//		add(value);
//		addMouseListener(this);
//		setVisible(true);
//	}
//	
//	//ResultFrame用
//	public SudokuPanel(int i, int j, boolean isInitial,int initial) {
//		setPreferredSize(PANELSIZE);
//		setSize(getPreferredSize());
//		
//		if(i<3){
//			if(j<3){
//				setLocation(j*32, i*32);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32);
//			} else {
//				setLocation(j*32+1, i*32);
//			}
//		} else if(5<i){
//			if(j<3){
//				setLocation(j*32, i*32+2);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+2);
//			} else {
//				setLocation(j*32+1, i*32+2);
//			}
//		} else {
//			if(j<3){
//				setLocation(j*32, i*32+1);
//			} else if(5<j) {
//				setLocation(j*32+2, i*32+1);
//			} else {
//				setLocation(j*32+1, i*32+1);
//			}
//		}
//		
//		setOpaque(true);
//		setBackground(Color.WHITE);
//
//		number=initial;
//		blank=!isInitial;
//		visible=!blank;
//		if(visible) value=new JLabel(number+"");
//		else value=new JLabel(" ");
//		if(blank) value.setForeground(Color.RED);
//		value.setVisible(true);
//		add(value);
//		addMouseListener(this);
//		setVisible(true);
//	}
	
	public boolean getIsClicked(){
		return this.isClicked;
	}
	public int getNumber(){
		return this.number;
	}
	public int getHint(){
		int num = hint;
		return num;
	}
	
	public void resetNumber(){
		switch(parent.getClass().getSimpleName()){
		case "CreatingFrame":
		case "TestingFrame":
			isClicked = false;
			hint = 0;
			value.setText("×");
			setBackground(Color.WHITE);
			break;
		case "SolvingFrame":
			number = 0;
			hint = 0;
			value.setText(" ");
			setBackground(Color.WHITE);
			break;
		}
	}
	
	public boolean getBlank(){
		return blank;
	}
	
	public void changeVisible(){
		if(!isPlace){
			isVisible = !isVisible;
			value.setVisible(isVisible);
		}
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		//g.setColor(Color.WHITE);
		//g.fillRect(0, 0, 31, 31);
		g.setColor(Color.BLACK);
		g.drawRect(0, 0, 31, 31);
	}
	
	public void changeInit(){
		isClicked = !isClicked;
		if(isClicked){
			value.setText("○");
			setBackground(Color.LIGHT_GRAY);
			hint++;
			parent.rewriteHintNumber(hint);
		}else{
			value.setText("×");
			setBackground(Color.WHITE);
			hint--;
			parent.rewriteHintNumber(hint);
		}
	}

	public void mouseClicked(MouseEvent e) {
		switch(parent.getClass().getSimpleName()){
		case "CreatingFrame" :
		case "TestingFrame":
			isClicked = !isClicked;
			if(isClicked){
				value.setText("○");
				setBackground(Color.LIGHT_GRAY);
				hint++;
				parent.rewriteHintNumber(hint);
			}else{
				value.setText("×");
				setBackground(Color.WHITE);
				hint--;
				parent.rewriteHintNumber(hint);
			}
			break;
		case "SolvingFrame":
			int preNumber = number;
			int button = e.getButton();
			if(button == MouseEvent.BUTTON1) number = (number+1)%10;
			else if(button == MouseEvent.BUTTON3){
				number = (number+9)%10;
			}else if(button == MouseEvent.BUTTON2) number = 0;
			if(number==0){
				value.setText(" ");
				setBackground(Color.WHITE);
				hint--;
				parent.rewriteHintNumber(hint);
			}else{
				value.setText(""+number);
				setBackground(Color.LIGHT_GRAY);
				if(preNumber==0) hint++;
				parent.rewriteHintNumber(hint);
			}
		}
		repaint();
		
//		if(creatingMode){
//			isClicked = !isClicked;
//			if(isClicked){
//				//Value.setVisible(false);
//				value.setText("○");	
//				setBackground(Color.LIGHT_GRAY);
//				hint++;
//				parentFrame.rewriteHintNumber(hint);
//				parentFrame.hintNumber = hint;
//			}else{
//				//Value.setVisible(true);
//				value.setText("×");
//				setBackground(Color.WHITE);
//				hint--;
//				parentFrame.rewriteHintNumber(hint);
//				parentFrame.hintNumber = hint;
//			}
//		}else if(solvingMode){
//			int preNumber=number;
//			if(e.getButton()==MouseEvent.BUTTON1) number=(number+1)%10;
//			else if(e.getButton()==MouseEvent.BUTTON3){
//				number=(number+9)%10;
//			}else if(e.getButton()==MouseEvent.BUTTON2) number=0;
//			if(number==0){
//				value.setText(" ");
//				setBackground(Color.WHITE);
//				hint--;
//				solveFrame.hintNumber = hint;
//				solveFrame.rewriteHintNumber(hint);
//			}else{
//				value.setText(""+number);
//				setBackground(Color.LIGHT_GRAY);
//				if(preNumber==0) hint++;
//				solveFrame.hintNumber = hint;
//				solveFrame.rewriteHintNumber(hint);
//			}
//		}

	}

	public void mousePressed(MouseEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public void mouseReleased(MouseEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public void mouseEntered(MouseEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public void mouseExited(MouseEvent e) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
	
}
