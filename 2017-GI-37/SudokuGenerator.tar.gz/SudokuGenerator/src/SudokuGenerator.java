
public class SudokuGenerator {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		//new SolvingFrame();
		new CreatingFrame(true);
		//new TestingFrame(true);
	}
}
