import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ResultFrame extends SudokuFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	int hint;
	JLabel hintLabel=null;
	SudokuFrame parent = null;
	JButton outputButton,closeButton;
	JCheckBox answerCheck;
	static int problemNumber=1;
	
	public ResultFrame(SudokuFrame frame,Creator creator){
		int[] answer;
		parent = frame;
		problemNumber++;
		setTitle("実行結果");
		setLayout(null);
		setBounds(0,0,450,328);
		
		answerCheck=new JCheckBox("解答表示");		
		answerCheck.setBounds(310,140,105,30);
		add(answerCheck);
		answerCheck.addActionListener(this);
		
//		OutputButton=new JButton("問題出力");		
//		OutputButton.setBounds(310,180,105,30);
//		add(OutputButton);
//		OutputButton.addActionListener(this);
		
		closeButton=new JButton("戻る");		
		closeButton.setBounds(310,220,105,30);
		add(closeButton);
		closeButton.addActionListener(this);
		
		hintLabel=new JLabel("初期配置の数:"+creator.hint);
		hintLabel.setBounds(320,110,100,30);
		add(hintLabel);

		JPanel outer = new JPanel();
		outer.setLayout(null);
		outer.setLocation(0,0);
		outer.setPreferredSize(new Dimension(291,291));
		outer.setSize(outer.getPreferredSize());
		outer.setBackground(Color.BLACK);
		outer.setOpaque(true);
		outer.setVisible(true);
		add(outer);
		answer = creator.board.getArrayA();
		
		panel = new SudokuPanel[81];
		for(int i = 0; i < panel.length; i++){
				panel[i] = new SudokuPanel(this);
				panel[i].setLocation((i%9)*32+(i%9)/3,(i/9)*32+(i/9)/3);
				panel[i].setVisible(true);
				panel[i].resultInit(answer[i],creator.init[i]);
				outer.add(panel[i]);
		}
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			// ウィンドウが閉じるときに呼ばれる
			@Override
			public void windowClosing(WindowEvent e) {
				parent.setVisible(true);
				dispose();
			}
		});
		setVisible(true);
	}
	
	public ResultFrame(SudokuFrame frame,int hint,int[] answer,boolean[] init){
		parent = frame;
		problemNumber++;
		setTitle("実行結果");
		setLayout(null);
		setBounds(0,0,450,328);
		
		answerCheck=new JCheckBox("解答表示");		
		answerCheck.setBounds(310,140,105,30);
		add(answerCheck);
		answerCheck.addActionListener(this);
		
//		OutputButton=new JButton("問題出力");		
//		OutputButton.setBounds(310,180,105,30);
//		add(OutputButton);
//		OutputButton.addActionListener(this);
		
		closeButton=new JButton("戻る");		
		closeButton.setBounds(310,220,105,30);
		add(closeButton);
		closeButton.addActionListener(this);
		
		hintLabel=new JLabel("初期配置の数:"+hint);
		hintLabel.setBounds(320,110,100,30);
		add(hintLabel);

		JPanel outer = new JPanel();
		outer.setLayout(null);
		outer.setLocation(0,0);
		outer.setPreferredSize(new Dimension(291,291));
		outer.setSize(outer.getPreferredSize());
		outer.setBackground(Color.BLACK);
		outer.setOpaque(true);
		outer.setVisible(true);
		add(outer);
		
		panel = new SudokuPanel[81];
		for(int i = 0; i < panel.length; i++){
				panel[i] = new SudokuPanel(this);
				panel[i].setLocation((i%9)*32+(i%9)/3,(i/9)*32+(i/9)/3);
				panel[i].setVisible(true);
				panel[i].resultInit(answer[i],init[i]);
				outer.add(panel[i]);
		}
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			// ウィンドウが閉じるときに呼ばれる
			@Override
			public void windowClosing(WindowEvent e) {
				parent.setVisible(true);
				dispose();
			}
		});
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == answerCheck){
			for(SudokuPanel p:panel) p.changeVisible();
		}else if(arg0.getSource() == outputButton){
//			int a[][] = new int[9][9];
//			for(int i=0;i<9;i++){
//				for(int j=0;j<9;j++){
//					a[i][j]=panels[i][j].getNumber();
//				}
//			}
//			try{
//				Calendar Cal = Calendar.getInstance();
//				int Year = Cal.get(Calendar.YEAR);
//			    int Month = Cal.get(Calendar.MONTH) + 1;
//			    int Day = Cal.get(Calendar.DATE);
//				File File=new File("C:\\Users\\al11051\\Desktop\\Output\\"
//						+ "Output"+problemNumber+"("+parentFrame.hintNumber+"-"+Year+","+Month+","+Day+").csv");
//				PrintWriter Pw=new PrintWriter(new BufferedWriter(new FileWriter(File)));
//				Pw.println("問題"+problemNumber);
//				for(int i=0;i<9;i++){
//					for(int j=0;j<9;j++){
//						if(panels[i][j].getBlank()) Pw.print("");
//						else Pw.print(a[i][j]);
//						if(j==8) Pw.print("\n");
//						else Pw.print(",");
//					}
//				}
//				Pw.println("解答");
//				for(int i=0;i<9;i++){
//					for(int j=0;j<9;j++){
//						Pw.print(a[i][j]);
//						if(j==8) Pw.print("\n");
//						else Pw.print(",");
//					}
//				}
//				Pw.close();
//			}catch(IOException e){
//				System.out.println(e);
//			}
		}else if(arg0.getSource() == closeButton){
			//parent.creating.setVisible(false);
			if(parent != null) parent.setVisible(true);
			dispose();
		}
	}


}
