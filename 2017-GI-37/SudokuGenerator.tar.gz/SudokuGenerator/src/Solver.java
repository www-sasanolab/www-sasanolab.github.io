import java.util.*;

public class Solver {
	static Board board;
	static boolean mode,isAssumed = false;
	static int[] countRule;
	static int difficulty;
	static int lastAppliedMethod;
	
	//解法の使用可否判定
	//true → 使用,false → 不使用
	//[0] 推論規則2
	//[1] 推論規則3・4
	//[2] 推論規則5・6
	//[3] 推論規則7・8
	//[4] BasicFish
	//[5] 浜田ロジック
	static boolean useMethod[] ={
		true,true,true,true,true,true	
	};
	
	static void setBoard(Board board){
		Solver.board = board;
	}
	
	static boolean solvingRecordLog(){
		int method;
		BoardLog log;
		
		log = board.makeBoardLog();
		log.methodDifficulty = 0;
		board.logs.add(log);
		while((method = applyMethod()) > 0){
			log = board.makeBoardLog();
			log.methodDifficulty = method;
			board.logs.add(log);
		}
		LogReader.setChangedCell(board.logs);
		return result();
	}
	
	static boolean solvingDetail(){
		ArrayList<BoardState> solveLog = new ArrayList<BoardState>();
		ArrayList<Cell> focusList = new ArrayList<Cell>();
		BoardState log;
		String method;
		
		log = board.getBoardState();
		//log = new BoardState(board.cell);
		log.method = "start";
		solveLog.add(log);
		while(true){
			focusList.clear();
			if(checkCellUnique(focusList)) method = "CellUnique";
			else if(checkAreaUnique(focusList)) method = "AreaUnique";
			else if(checkLocalization(focusList)) method = "Localization";
			else if(checkNakedCandidates(focusList)) method = "NakedCandidates";
			else if(checkBasicFish(focusList)) method = "BasicFish";
			else if(checkHamadaLogic(focusList)) method = "HamadaLogic";
			else break;
			//System.out.println("Apply -> "+method);
			log = board.getBoardState();
			//log = new BoardState(board.cell);
			log.method = method;
			log.setFocusedCell(focusList);
			solveLog.add(log);
		}
		LogReader.setStatesChangedCell(solveLog);
		board.stateLog = solveLog;
		return result();
	}
	
	static boolean solving(){
		difficulty = 1;
		
		while((lastAppliedMethod = applyMethod()) > 0)	
			if(lastAppliedMethod > difficulty) difficulty = lastAppliedMethod;
		return result();
	}
	
	static int applyMethod(){
		if(rule1()) return 1;
		if(useMethod[0]) if(rule2()) return 2;
		if(useMethod[1]) if(rule3_4()) return 3;
		if(useMethod[2]) if(rule5_6()) return 4;
		if(useMethod[3]) if(rule7_8()) return 5;
		if(useMethod[4]) if(basicFish()) return 6;
		if(useMethod[5]) if(hamadaLogic()) return 7;
		return -1;
	}
	
	static int getDifficulty(){
		return difficulty;
	}
	
//	static boolean solvingDetail(){
//		BoardLog log;
//		
//		while(true){
//			log = new BoardLog(board.cellTrack());
//			
//			if(applyMethod(log)){
//				log.next = board.cellTrack();
//				log.setLog();
//				board.logs.add(log);
//				//System.out.println(log.method+"-"+log.log);
//			}
//			else return result();
//		}
//	}
//	
//	static boolean applyMethod(BoardLog log){
//		if(rule1()){
//			log.method = "rule1";
//			return true;
//		}
//		if(rule2()){
//			log.method = "rule2";
//			return true;
//		}
//		if(rule3_4()){
//			log.method = "rule3_4";
//			return true;
//		}
//		if(rule5_6()){
//			log.method = "rule5_6";
//			return true;
//		}
//		if(rule7_8()){
//			log.method = "rule7_8";
//			return true;
//		}
//		if(basicFish()){
//			log.method = "BasicFish";
//			return true;
//		}
//		if(hamadaLogic()){
//			log.method = "HamadaLogic";
//			return true;
//		}
//		return false;
//	}
	
	static boolean rule1(){
		
		for(Cell target:board.cell){
			if(target.candidate.size() == 1){
				target.setAnswer(target.candidate.get(0));
				return true;
			}
		}		
		return false;
	}
	
	static boolean checkCellUnique(ArrayList<Cell> focus){
		
		for(Cell c:board.cell){
			if(cellUnique(c)){
				focus.add(c);
				return true;
			}
		}
		return false;
	}
	
	static boolean cellUnique(Cell c){
		
		if(c.candidate.size() == 1){
			c.setAnswer(c.candidate.get(0));
			return true;
		}
		return false;
	}
	
	static boolean rule2(){
		
		if(rule2_areasCheck(board.row)) return true;
		if(rule2_areasCheck(board.column)) return true;
		if(rule2_areasCheck(board.brock)) return true;
		return false;
	}
	
	static boolean rule2_areasCheck(Cell[][] areas){
		Cell target;
		
		for(Cell[] area:areas){
			for(Integer i=1;i<10;i++){
				target = rule2_uniqueCheck(area,i);
				if(target != null){
					target.candidate.clear();
					target.candidate.add(i);
					//if(board.current != null) board.current.focusedCell.addAll(Arrays.asList(area));
					return true;
				}
			}
		}
		return false;
	}
	
	static Cell rule2_uniqueCheck(Cell[] area,Integer num){
		Cell target = null;
		
		for(Cell c:area){
			if(c.candidate.contains(num)){
				if(target == null) target = c;
				else return null;
			}
		}
		return target;
	}
	
	static boolean checkAreaUnique(ArrayList<Cell> focus){
		
		for(Cell[] area:board.row){
			if(areaUnique(area)){
				focus.addAll(Arrays.asList(area));
				return true;
			}
		}
		for(Cell[] area:board.column){
			if(areaUnique(area)){
				focus.addAll(Arrays.asList(area));
				return true;
			}
		}
		for(Cell[] area:board.brock){
			if(areaUnique(area)){
				focus.addAll(Arrays.asList(area));
				return true;
			}
		}
		return false;
	}
	
	static boolean areaUnique(Cell[] area){
		Cell target;
		
		for(int i=1;i<10;i++){
			target = null;
			for(Cell c:area){
				if(c.candidate.contains(i)){
					if(target == null) target = c;
					else{
						target = null;
						break;
					}
				}
			}
			if(target != null){
				target.candidate.clear();
				target.candidate.add(i);
				return true;
			}
		}
		return false;
	}
	
	static boolean rule3_4(){
	
		for(Cell[] row:board.row)
			if(rule3_4_areaCheck(row)) return true;
		for(Cell[] column:board.column)
			if(rule3_4_areaCheck(column)) return true;		
		return false;
	}
	
	static boolean rule3_4_areaCheck(Cell[] area){
		boolean isUnique;
		boolean isUpdated;
		
		for(Cell target:area){
			for(Integer num:target.candidate){
				isUnique = true;
				for(Cell b_cell:target.parentBrock){
					if(Arrays.asList(area).contains(b_cell)) continue;
					if(b_cell.candidate.contains(num)){
						isUnique = false;
						break;
					}
				}
				if(isUnique){
					isUpdated = false;
					for(Cell a_cell:area){
						if(a_cell.parentBrock == target.parentBrock) continue;
						if(a_cell.candidate.contains(num)){
							isUpdated = true;
							a_cell.candidate.remove(num);
						}
					}
					if(isUpdated) return true;
				}
			}
		}
		return false;
		
	}
	
	static boolean rule5_6(){
		
		for(Cell[] brock:board.brock){
			for(Cell target:brock){
				if(rule5_6_parentCheck(target,target.parentRow)) return true;
				if(rule5_6_parentCheck(target,target.parentColumn)) return true;
			}
		}
		return false;		
	}
	
	static boolean rule5_6_parentCheck(Cell target,Cell[] parentArea){
		boolean isUnique;
		boolean isUpdated;

		for(Integer num:target.candidate){
			isUnique = true;
			for(Cell p_cell:parentArea){
				if(p_cell.parentBrock == target.parentBrock) continue;
				if(p_cell.candidate.contains(num)){
					isUnique = false;
					break;
				}
			}
			if(isUnique){
				isUpdated = false;
				for(Cell b_cell:target.parentBrock){
					if(Arrays.asList(parentArea).contains(b_cell)) continue;
					if(b_cell.candidate.contains(num)){
						b_cell.candidate.remove(num);
						isUpdated = true;
					}
				}
				if(isUpdated) return true;
			}
		}
		return false;	
	}
	
	static boolean checkLocalization(ArrayList<Cell> focus){
		
		for(int i=0;i<9;i++){
			for(int j=0;j<3;j++){
				if(localization(board.row[i],board.brock[i/3+j])){
					focus.addAll(Arrays.asList(board.row[i]));
					focus.addAll(Arrays.asList(board.brock[i/3+j]));
					return true;
				}
				if(localization(board.brock[i/3+j],board.row[i])){
					focus.addAll(Arrays.asList(board.row[i]));
					focus.addAll(Arrays.asList(board.brock[i/3+j]));
					return true;
				}
				if(localization(board.column[i],board.brock[i/3+j*3])){
					focus.addAll(Arrays.asList(board.column[i]));
					focus.addAll(Arrays.asList(board.brock[i/3+j*3]));
					return true;
				}
				if(localization(board.brock[i/3+j*3],board.column[i])){
					focus.addAll(Arrays.asList(board.column[i]));
					focus.addAll(Arrays.asList(board.brock[i/3+j*3]));
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean localization(Cell[] area1,Cell[] area2){
		boolean isUpdate = false;
		ArrayList<Integer> tempCand;
		ArrayList<Integer> intersectCand = new ArrayList<Integer>();
		ArrayList<Integer> uniqueCand = new ArrayList<Integer>();
		
		for(Cell c:area1){
			if(Arrays.asList(area2).contains(c)) intersectCand.addAll(c.candidate);
			else uniqueCand.addAll(c.candidate);
		}
		intersectCand.removeAll(uniqueCand);
		if(intersectCand.isEmpty()) return false;
		for(Cell c:area2){
			if(Arrays.asList(area1).contains(c) | c.candidate.isEmpty()) continue;
			tempCand = new ArrayList<Integer>(c.candidate);
			c.candidate.removeAll(intersectCand);
			if(!c.candidate.equals(tempCand)) isUpdate = true;
		}
		return isUpdate;
	}

	static boolean rule7_8(){
		
		for(Cell[] row:board.row)
			if(rule7_areaCheck(row)) return true;
		for(Cell[] column:board.column)
			if(rule7_areaCheck(column)) return true;
		for(Cell[] brock:board.brock)
			if(rule7_areaCheck(brock)) return true;
		return false;
	}
	
	static boolean rule7_areaCheck(Cell[] area){
		int empty = 0;
		
		for(Cell c:area)
			if(c.answer == 0) empty++;
		if(empty > 3){
			for(int i=2;i<empty-1;i++){
				if(rule7_apply(area,new ArrayList<Integer>(),0,i,0)) return true;
			}
		}
		return false;
	}
	
	static boolean rule7_apply(Cell[] target,ArrayList<Integer> OR,int index,int cellNum,int depth){
		ArrayList<Integer> tempOR,tempCand;
		boolean isUpdated;
		
		for(int i=index;i<10-(cellNum-depth);i++){
			if(target[i].answer != 0 | target[i].candidate.size() > cellNum) continue;
			tempOR = arrayOR(OR,target[i].candidate);
			if(depth != cellNum-1){		
				if(tempOR.size() <= cellNum){
					if(rule7_apply(target,tempOR,i+1,cellNum,depth+1)) return true;					
				}else continue;
			}else{
				if(tempOR.size() == cellNum){
					isUpdated = false;
					for(Cell c:target){
						tempCand = new ArrayList<Integer>(c.candidate);
						if(tempCand.retainAll(tempOR) & tempCand.size() != 0){
							c.candidate.removeAll(tempOR);
							isUpdated = true;
						}
					}
					return isUpdated;
				}else continue;
			}
			
		}
		return false;
		
	}
	
	static boolean checkNakedCandidates(ArrayList<Cell> focus){
		
		for(int i=0;i<9;i++){
			if(nakedCandidates(board.row[i])){
				focus.addAll(Arrays.asList(board.row[i]));
				return true;
			}
			if(nakedCandidates(board.column[i])){
				focus.addAll(Arrays.asList(board.column[i]));
				return true;
			}
			if(nakedCandidates(board.brock[i])){
				focus.addAll(Arrays.asList(board.brock[i]));
				return true;
			}
		}
		return false;
	}
	
	static boolean nakedCandidates(Cell[] area){
		int empty =0;
		boolean isUpdate = false;
		ArrayList<Integer> idList,nakedCand;
		
		for(Cell c:area)
			if(c.answer == 0) empty++;
		if(empty > 3){
			for(int num=2;num<empty-1;num++){
				if((idList = nakedSearch(area,new ArrayList<Integer>(),0,num,0)) != null){
					nakedCand = new ArrayList<Integer>();
					for(int id:idList)
						nakedCand = arrayOR(nakedCand,area[id].candidate);
					for(int i=0;i<9;i++){
						if(area[i].answer != 0 | idList.contains(i)) continue;
						if(area[i].candidate.removeAll(nakedCand)) isUpdate = true;
					}
					if(isUpdate) return true;
				}
			}
		}
		return false;
	}
	
	static ArrayList<Integer> nakedSearch(Cell[] target,ArrayList<Integer> OR,int index,int cellNum,int depth){
		ArrayList<Integer> tempOR,idList;
		
		for(int i=index;i<10-(cellNum-depth);i++){
			if(target[i].answer != 0 | target[i].candidate.size() > cellNum) continue;
			tempOR = arrayOR(OR,target[i].candidate);
			if(depth != cellNum-1){		
				if(tempOR.size() <= cellNum){
					idList = nakedSearch(target,tempOR,i+1,cellNum,depth+1);
					if(idList != null){
						if(idList.size() != 0){
							idList.add(i);
							return idList;					
						}
					}
				}else continue;
			}else{
				if(tempOR.size() == cellNum){
					idList = new ArrayList<Integer>();
					idList.add(i);
					return idList;
				}else continue;
			}
			
		}
		return null;
	}
	
	static ArrayList<Integer> arrayOR(ArrayList<Integer> A,ArrayList<Integer> B){
		ArrayList<Integer> OR = new ArrayList<Integer>(A);
		ArrayList<Integer> inter = new ArrayList<Integer>(A);
		
		inter.retainAll(B);
		OR.addAll(B);
		for(Integer num:inter) OR.remove(num);
		return OR;
	}
	
	static ArrayList<Integer> arrayAND(ArrayList<Integer> A,ArrayList<Integer> B){
		ArrayList<Integer> AND = new ArrayList<Integer>(A);
		
		AND.retainAll(B);
		return AND;
	}
	
	static boolean basicFish(){
		
		for(Integer i=1;i<10;i++){
			if(basicFish_apply(i,board.row)) return true;
			if(basicFish_apply(i,board.column)) return true;			
		}
		return false;
	}
	
//*******BackUp**************************************
	static boolean basicFish_apply(Integer num,Cell[][] areas){
		Cell[] fish = new Cell[9];
		boolean isUpdated = false;
		
		for(int i=0;i<9;i++){
			fish[i] = new Cell();
			for(int j=0;j<9;j++)
				if(areas[i][j].candidate.contains(num)) fish[i].candidate.add((Integer)(j+1));
			if(fish[i].candidate.isEmpty())	fish[i].answer = -1;
		}
		if(rule7_areaCheck(fish)){
			for(int i=0;i<9;i++){
				for(int j=0;j<9;j++){
					if(areas[i][j].candidate.contains(num) & !fish[i].candidate.contains((Integer)(j+1))){
						isUpdated = true;
						areas[i][j].candidate.remove(num);						
					}
				}
			}
		}
		return isUpdated;
	}
//*******BackUp**************************************

	static boolean checkBasicFish(ArrayList<Cell> focus){
		
		for(int l=2;l<5;l++){
			if(basicFish(l,board.row,board.column,focus)) return true;
			if(basicFish(l,board.column,board.row,focus)) return true;
		}
		return false;
	}
	
	static boolean basicFish(int level,Cell[][] area1,Cell[][] area2,ArrayList<Cell> focus){
		Cell[] fish = new Cell[9];
		boolean isUpdate = false;
		ArrayList<Integer> idList1,idList2;
		
		for(int n=1;n<10;n++){
			for(int i=0;i<9;i++){
				fish[i] = new Cell();
				for(int j=0;j<9;j++)
					if(area1[i][j].candidate.contains(n)) fish[i].candidate.add((Integer)(j+1));
				if(fish[i].candidate.isEmpty())	fish[i].answer = -1;
			}
			if((idList1 = nakedSearch(fish,new ArrayList<Integer>(),0,level,0)) != null){
				idList2 = new ArrayList<Integer>();
				for(int id:idList1)
					idList2 = arrayOR(idList2,fish[id].candidate);
				for(int id:idList2){
					for(int i=0;i<9;i++){
						if(idList1.contains(i) | !area2[id-1][i].candidate.contains((Integer)n)) continue;
						area2[id-1][i].candidate.remove((Integer)n);
						isUpdate = true;
					}
				}
				if(isUpdate){
					for(int id:idList1)
						focus.addAll(Arrays.asList(area1[id]));
					for(int id:idList2)
						focus.addAll(Arrays.asList(area2[id-1]));
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean hamadaLogic(){
		Integer X,Y;
		ArrayList<Cell> evenChain,oddChain;
		
		for(Cell head:board.cell){
			if(head.candidate.size() == 2 & head.chain == null){
				X = head.candidate.get(0);
				Y = head.candidate.get(1);
				evenChain = new ArrayList<Cell>();
				oddChain = new ArrayList<Cell>();
				setChain(head,evenChain,oddChain);
				if(evenChain.size() > 1){
					if(hamada_chainCheck(board.row,board.column,evenChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
					if(hamada_chainCheck(board.column,board.row,evenChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
				}
				if(oddChain.size() > 1){
					if(hamada_chainCheck(board.row,board.column,oddChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
					if(hamada_chainCheck(board.column,board.row,oddChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
				}				
			}
		}
		resetChain(board.cell);
		return false;
	}
	
	static boolean checkHamadaLogic(ArrayList<Cell> focus){
		Integer X,Y;
		ArrayList<Cell> evenChain,oddChain;
		
		for(Cell head:board.cell){
			if(head.candidate.size() == 2 & head.chain == null){
				focus.clear();
				X = head.candidate.get(0);
				Y = head.candidate.get(1);
				evenChain = new ArrayList<Cell>();
				oddChain = new ArrayList<Cell>();
				setChain(head,evenChain,oddChain,focus);
				if(evenChain.size() > 1){
					if(hamada_chainCheck(board.row,board.column,evenChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
					if(hamada_chainCheck(board.column,board.row,evenChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
				}
				if(oddChain.size() > 1){
					if(hamada_chainCheck(board.row,board.column,oddChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
					if(hamada_chainCheck(board.column,board.row,oddChain,X,Y)){
						resetChain(board.cell);
						return true;
					}
				}				
			}
		}
		resetChain(board.cell);
		return false;
	}
	
//	static boolean XYChain(ArrayList<Cell> focus){
//		boolean isUpdate = false;
//		ArrayList<Cell> headList;
//		ArrayList<Cell> intersect;
//		ArrayList<Integer> commonCand;
//		
//		for(Cell c:board.cell){
//			if(c.candidate.size() == 2 & c.chain == null){
//				headList = new ArrayList<Cell>();
//				setXYChain(c,headList);
//				if(c.chain.size() != 0){
//					if(c.chain.size() == 1) headList.add(c);
//					for(int i=0;i<headList.size()-1;i++){
//						for(int j=i+1;j<headList.size();j++){
//							commonCand = new ArrayList<Integer>(headList.get(i).candidate);
//							if(commonCand.retainAll(headList.get(j).candidate)){
//								intersect = getCellsIntersection(headList.get(i),headList.get(j));
//								for(Cell inter:intersect)
//									if(!inter.candidate.isEmpty() & inter.candidate.retainAll(commonCand)) isUpdate = true;
//							}
//						}
//					}
//				}
//			}
//		}
//		return false;
//	}
	
	static void setChain(Cell target,ArrayList<Cell> chain1,ArrayList<Cell> chain2){
		
		chain1.add(target);
		if(target.chain == null) target.chain = new ArrayList<Cell>();
		for(Cell next:target.parentRow){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				setChain(next,chain2,chain1);
			}
		}
		for(Cell next:target.parentColumn){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				setChain(next,chain2,chain1);
			}
		}
		for(Cell next:target.parentBrock){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				setChain(next,chain2,chain1);
			}
		}
	}
	
	static void setChain(Cell target,ArrayList<Cell> chain1,ArrayList<Cell> chain2,ArrayList<Cell> focus){
		
		chain1.add(target);
		if(target.chain == null) target.chain = new ArrayList<Cell>();
		for(Cell next:target.parentRow){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				focus.addAll(Arrays.asList(target.parentRow));
				setChain(next,chain2,chain1);
			}
		}
		for(Cell next:target.parentColumn){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				focus.addAll(Arrays.asList(target.parentColumn));
				setChain(next,chain2,chain1);
			}
		}
		for(Cell next:target.parentBrock){
			if(next.chain == null & next.candidate.equals(target.candidate)){
				target.chain.add(next);
				focus.addAll(Arrays.asList(target.parentBrock));
				setChain(next,chain2,chain1);
			}
		}
	}
	
	static void setXYChain(Cell current,ArrayList<Cell> headList){
		int X,Y;
		
		X = current.candidate.get(0);
		Y = current.candidate.get(1);
		current.chain = new ArrayList<Cell>();
		for(Cell next:current.parentRow){
			if(next.chain == null & next.candidate.size() == 2){
				if(next.candidate.contains(X) | next.candidate.contains(Y)){
					current.chain.add(next);
					setXYChain(next,headList);
				}
			}
		}
		for(Cell next:current.parentColumn){
			if(next.chain == null & next.candidate.size() == 2){
				if(next.candidate.contains(X) | next.candidate.contains(Y)){
					current.chain.add(next);
					setXYChain(next,headList);
				}
			}
		}
		for(Cell next:current.parentBrock){
			if(next.chain == null & next.candidate.size() == 2){
				if(next.candidate.contains(X) | next.candidate.contains(Y)){
					current.chain.add(next);
					setXYChain(next,headList);
				}
			}
		}
		if(current.chain.isEmpty()) headList.add(current);
		return;
	}
	
	static boolean hamada_chainCheck(Cell[][] areas1,Cell[][] areas2,ArrayList<Cell> chain,Integer X,Integer Y){
		boolean isChained;
		ArrayList<Integer> Xindex = new ArrayList<Integer>();
		ArrayList<Integer> Yindex = new ArrayList<Integer>();
		
		for(Cell[] area:areas1){
			Xindex.clear();
			Yindex.clear();
			isChained = false;
			for(int i=0;i<9;i++){
				if(chain.contains(area[i])){
					isChained = true;
					break;
				}
				if(area[i].candidate.contains(X)) Xindex.add(i);
				if(area[i].candidate.contains(Y)) Yindex.add(i);
			}
			if(isChained) continue;
			if(Xindex.size() > 0){
				if(hamada_intersectCheck(areas2,chain,Xindex)){
					for(Cell c:chain) c.candidate.remove(X);
					return true;
				}
			}
			if(Yindex.size() > 0){
				if(hamada_intersectCheck(areas2,chain,Yindex)){
					for(Cell c:chain) c.candidate.remove(Y);
					return true;
				}
			}
		}
		return false;
	}
	
	static boolean hamada_intersectCheck(Cell[][] areas,ArrayList<Cell> chain,ArrayList<Integer> index){
		boolean isIntersect = false;
		
		for(int i:index){
			isIntersect = false;
			for(Cell c:areas[i]){
				if(chain.contains(c)){
					isIntersect = true;
					break;
				}
			}
			if(!isIntersect) return false;			
		}
		return true;
	}
	
	static ArrayList<Cell> getCellsIntersection(Cell A,Cell B){
		ArrayList<Cell> intersect = new ArrayList<Cell>();
		
		intersect.addAll(getAreaIntersection(A.parentRow,B.parentColumn));
		intersect.addAll(getAreaIntersection(A.parentRow,B.parentBrock));
		intersect.addAll(getAreaIntersection(A.parentColumn,B.parentRow));
		intersect.addAll(getAreaIntersection(A.parentColumn,B.parentBrock));
		intersect.addAll(getAreaIntersection(A.parentBrock,B.parentRow));
		intersect.addAll(getAreaIntersection(A.parentBrock,B.parentColumn));
		intersect.remove(A);
		intersect.remove(B);
		return intersect;
	}
	
	static ArrayList<Cell> getAreaIntersection(Cell[] A,Cell[] B){
		ArrayList<Cell> areaA = new ArrayList<Cell>(Arrays.asList(A));
		
		areaA.retainAll(Arrays.asList(B));
		return areaA;
	}
	
	static void resetChain(Cell[] cells){
		for(Cell c:cells) c.chain = null;
	}
	
//	boolean BackTrack(Board Board){
//		int X,Y;
//		
//		for(int i=0;i<9;i++){
//			for(int j=0;j<9;j++){
//				if(Board.Cells[i][j].CandidateCheck() == 2){
//					X = 0;
//					Y = 0;
//					for(int k=0;k<9;k++){
//						if(Board.Cells[i][j].Candidate[k]){
//							if(X == 0) X = k+1;
//							else Y = k+1;
//						}
//					}
//					Board.Tracking();
//					IsAssuming = true;
//					Board.Cells[i][j].SetAnswer(X);
//					Narrowing(Board.Cells[i][j]);
//					while(true){
//						if(Rule1(Board)) break;
//						if(Rule2(Board)) break;
//						if(Rule3_4(Board)) break;
//						if(Rule5_6(Board)) break;
//						if(Rule7_8(Board)) break;
//						if(FishMethod(Board)) break;
//						if(HamadaLogic(Board)) break;
//						break;
//					}
//					IsAssuming = false;
//					if(!IsValid(Board)){
//						Board.Restoring();
//						Board.Cells[i][j].Candidate[X-1] = false;
//						Board.Archives.add(new Record(Board,"仮置き推論"));
//						Board.IsBackTracked = true;
//						return true;
//					}else{
//						Board.Restoring();
//						IsAssuming = true;
//						Board.Cells[i][j].SetAnswer(Y);
//						Narrowing(Board.Cells[i][j]);
//						while(true){
//							if(Rule1(Board)) break;
//							if(Rule2(Board)) break;
//							if(Rule3_4(Board)) break;
//							if(Rule5_6(Board)) break;
//							if(Rule7_8(Board)) break;
//							if(FishMethod(Board)) break;
//							if(HamadaLogic(Board)) break;
//							break;
//						}
//						IsAssuming = false;
//						if(!IsValid(Board)){
//							Board.Restoring();
//							Board.Cells[i][j].Candidate[Y-1] = false;
//							Board.Archives.add(new Record(Board,"仮置き推論"));
//							Board.IsBackTracked = true;
//							return true;
//						}else Board.Restoring();
//					}
//					
//				}
//			}
//		}
//		
//		return false;
//	}
//	
//	boolean IsValid(Board Board){
//		boolean Check;
//		
//		for(int i=0;i<9;i++){
//			for(int j=0;j<9;j++){
//				if(Board.Cells[i][j].Answer != 0) continue;
//				Check = false;
//				for(int k=0;k<9;k++)
//					Check |= Board.Cells[i][j].Candidate[k];
//				if(!Check) return false;
//			}
//		}
//		
//		return true;
//			
//	}
	
	static boolean result(){
		for(Cell target:board.cell)
			if(target.answer == 0) return false;
		return true;
	}
	
}
