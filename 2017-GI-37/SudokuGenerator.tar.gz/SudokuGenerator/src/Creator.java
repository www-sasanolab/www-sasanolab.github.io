import java.util.*;

class Creator {
	Board board;
	int[][] answer = new int[9][9];
	boolean[] init = new boolean[81];
	int hint;
	int border;
	int changes;
	double perc;
	ArrayList<Cell[]> archive = new ArrayList<Cell[]>();
	
	String makeMode = "NARROW";
	String replaceMode = "EMPTY";
	
//	Creator(boolean[][] place,boolean state,int hint){
//		for(int i=0;i<81;i++) init[i] = place[i/9][i%9];
//		this.hint = hint;
//		board = new Board();
//		solver = new Solver(board,state);
//	}
	
	Creator(boolean[][] place,int hint){
		for(int i=0;i<81;i++) init[i] = place[i/9][i%9];
		init(hint);
	}
	
	Creator(boolean[] place,int hint){
		for(int i=0;i<81;i++) init[i] = place[i];
		init(hint);
	}
	
	Creator(boolean[] place){
		int h = 0;
		
		for(int i=0;i<81;i++){
			init[i] = place[i];
			if(init[i]) h++;
		}
		init(h);
	}
	
	void init(int hint){
		this.hint = hint;
		board = new Board(init);
		Solver.setBoard(board);
	}
	
	boolean creating(){
		int times = 100;
		ArrayList<Cell> initList = board.getInitList();
		
		for(int i=0;i<times;i++){
			//System.out.println("試行"+(i+1)); //test
			if(create(initList,makeMode,replaceMode)) return true;
		}
		return false;
	}
	
	boolean create(ArrayList<Cell> initList,String makeMode,String replaceMode){
		boolean isSuccess = false;
		
		changes = 0;
		switch(makeMode){
		case "RANDOM": makeRandom(initList);break;
		case "ERASE": makeErase();break;
		case "NARROW": makeNarrow(initList);break;
		case "SOFT": makeNarrowSoft(initList);break;
		case "HARDER": makeHarder(initList);break;
		}
		//System.out.println("試行"); //test
		if(Solver.solving()) return true;
		while(true){
			switch(replaceMode){
			case "EMPTY":isSuccess = replaceLesserEmpty(initList);break;
			case "EMPTY_L":isSuccess = replaceLeastEmpty(initList);break;
			case "EMPTY_H":isSuccess = replaceLesserEmptyHarder(initList);break;
			case "EMPTY_L_H":isSuccess = replaceLeastEmptyHarder(initList);break;
			case "CAND":isSuccess = replaceLesserCandSum(initList);break;
			case "CAND_L":isSuccess = replaceLeastCandSum(initList);break;
			case "CAND_H":isSuccess = replaceLesserCandSumHarder(initList);break;
			case "CAND_L_H":isSuccess = replaceLeastCandSumHarder(initList);break;
			}
			if(isSuccess){
				//System.out.println("変更"); //test
				if(!board.isEmpty()) return true;
			}else return false;
		}
	}
		
	//履歴との重複チェック
	//重複アリ→true,ナシ→false
	boolean isDuplicate(){

		ARCHIVELOOP:for(Cell[] target:archive){
			for(int i=0;i<81;i++)
				if(board.cell[i].answer != target[i].answer) continue ARCHIVELOOP;
			return true;
		}
		return false;
	}
	
	//answer配列出力
	//board.cellのanswerをint[][]型配列として出力
	void outputArray(){
		for(int i=0;i<81;i++) answer[i/9][i%9] = board.cell[i].answer;
	}
	
	int[] getAnswerArray(){
		int answer[] = new int[81];
		for(int i=0;i<81;i++) answer[i] = board.cell[i].answer;
		return answer;
	}
	
	void printBoard(){

		for(int i=0;i<81;i++){
			System.out.print(board.cell[i].answer);
			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
			if((i%9) == 8) System.out.println();
			if(i == 26 | i == 53) System.out.println("-----------");
		}	
	}
	
	void makeRandom(ArrayList<Cell> initList){
		int num;
		boolean reset = false;
		Cell tempState[];
		Cell target;
		ArrayList<Cell> placeList = new ArrayList<Cell>(initList);
		
		board.cellReset();
		while(placeList.size() > 0){
			if(reset){
				board.cellReset();
				placeList = new ArrayList<Cell>(initList);
				reset = false;
			}
			tempState = board.cellTrack();
			target = placeRandom(placeList);
			if(board.candCheck()) placeList.remove(target);
			else{
				num = target.answer;
				board.cellRestore(tempState);
				if(target.candidate.size() == 1) reset = true;
				else target.candidate.remove((Integer)num);
			}
		}
		return;
	}
	
	//全て埋めてから指定マス以外を空白にする
	void makeErase(){
		Random rand = new Random();
		int num,cand;
		boolean reset = false;
		Cell tempState[];
		Cell target;
		ArrayList<Cell> emptyList = new ArrayList<Cell>();
		ArrayList<Cell> minList = new ArrayList<Cell>();
		
		board.cellReset();
		for(int i=0;i<81;i++) emptyList.add(board.cell[i]);
		while(emptyList.size() > 0){
			if(reset){
				board.cellReset();
				emptyList.clear();
				for(int i=0;i<81;i++) emptyList.add(board.cell[i]);
				reset = false;
			}
			tempState = board.cellTrack();
			minList.clear();
			cand = 9;
			for(Cell c:emptyList){
				if(c.candidate.size() < cand){
					cand = c.candidate.size();
					minList.clear();
					minList.add(c);
				}else if(c.candidate.size() == cand) minList.add(c);				
			}
			target = minList.get(rand.nextInt(minList.size()));
			num = target.candidate.get(rand.nextInt(target.candidate.size()));
			target.setAnswer(num);
			if(board.candCheck()) emptyList.remove(target);
			else{
				board.cellRestore(tempState);
				if(target.candidate.size() == 1) reset = true;
				else target.candidate.remove((Integer)num);
			}
		}
		board.problemReset();
		return;
	}

//指定位置に候補数字の平方和が小さくなるように数字配置
	void makeNarrow(ArrayList<Cell> initList){
		int num;
		boolean reset = false;
		Cell tempState[];
		Cell target;
		ArrayList<Cell> placeList = new ArrayList<Cell>(initList);
		
		board.cellReset();
		while(placeList.size() > 0){
			//System.out.println("残り"+initList.size());
			if(reset){
				board.cellReset();
				placeList = new ArrayList<Cell>(initList);
				reset = false;
			}
			tempState = board.cellTrack();
			target = placeLesserCandSum(placeList);
			if(board.candCheck()) placeList.remove(target);
			else{
				num = target.answer;
				board.cellRestore(tempState);
				if(target.candidate.size() == 1) reset = true;
				else target.candidate.remove((Integer)num);
			}
		}
		return;
	}
	
//	void makeNarrowHalf(){
//		Random rand = new Random();
//		int num,cand,tempCand,index,half;
//		boolean reset = false;
//		Cell tempState[];
//		Cell target;
//		ArrayList<Cell> initList = new ArrayList<Cell>();
//		ArrayList<Cell> minList = new ArrayList<Cell>();
//		ArrayList<Integer> minNums = new ArrayList<Integer>();
//		ArrayList<Integer> tempCandList = new ArrayList<Integer>();
//		
//		board.init();
//		for(int i=0;i<81;i++)
//			if(init[i])	initList.add(board.cell[i]);
//		half = initList.size()/2;
//		while(initList.size() > 0){
//			//System.out.println("残り"+initList.size());
//			if(reset){
//				board.init();
//				initList.clear();
//				for(int i=0;i<81;i++)
//					if(init[i])	initList.add(board.cell[i]);
//				reset = false;
//			}
//			tempState = board.cellTrack();
//			if(initList.size() > half){
//				target = initList.get(rand.nextInt(initList.size()));
//				num = target.candidate.get(rand.nextInt(target.candidate.size()));
//			}else{
//				cand = board.candCountSquare();
//				minList.clear();
//				minNums.clear();
//				for(Cell c:initList){
//					tempCandList = new ArrayList<Integer>(c.candidate);
//					for(int can:tempCandList){
//						c.setAnswer(can);
//						tempCand = board.candCountSquare();
//						if(tempCand < cand){
//							cand = tempCand;
//							minList.clear();
//							minNums.clear();
//							minList.add(c);
//							minNums.add(can);
//						}else if(tempCand == cand){
//							minList.add(c);
//							minNums.add(can);
//						}
//						board.cellRestore(tempState);
//					}				
//				}
//				index = rand.nextInt(minList.size());
//				target = minList.get(index);
//				num = minNums.get(index);
//			}
//			target.setAnswer(num);
//			if(board.candCheck()) initList.remove(target);
//			else{
//				board.cellRestore(tempState);
//				if(target.candidate.size() == 1) reset = true;
//				else target.candidate.remove((Integer)num);
//			}
//		}
//		return;
//	}
	
	void makeNarrowSoft(ArrayList<Cell> initList){
		int num;
		boolean reset = false;
		Cell tempState[];
		Cell target;
		ArrayList<Cell> placeList = new ArrayList<Cell>(initList);
		border = (int)(hint*perc);
		
		board.cellReset();
		while(placeList.size() > 0){
			if(reset){
				board.cellReset();
				placeList = new ArrayList<Cell>(initList);
				reset = false;
			}
			tempState = board.cellTrack();
			if(placeList.size() > border) target = placeRandom(placeList);
			else target = placeLesserCandSum(placeList);
			if(board.candCheck()) placeList.remove(target);
			else{
				num = target.answer;
				board.cellRestore(tempState);
				if(target.candidate.size() == 1) reset = true;
				else target.candidate.remove((Integer)num);
			}
		}
		return;
	}
	
	void makeHarder(ArrayList<Cell> initList){
		int num;
		boolean reset = false;
		Cell tempState[];
		Cell target;
		ArrayList<Cell> placeList = new ArrayList<Cell>(initList);
		
		board.cellReset();
		while(placeList.size() > 0){
			//System.out.println("残り"+initList.size());
			if(reset){
				board.cellReset();
				placeList = new ArrayList<Cell>(initList);
				reset = false;
			}
			tempState = board.cellTrack();
			target = placeHarderMethod(placeList);
			if(board.candCheck()) placeList.remove(target);
			else{
				num = target.answer;
				board.cellRestore(tempState);
				if(target.candidate.size() == 1) reset = true;
				else target.candidate.remove((Integer)num);
			}
		}
		//System.out.println("Diff → "+Solver.getDifficulty()); //test
		return;
	}
	
	Cell placeRandom(ArrayList<Cell> list){
		int index;
		Random rand = new Random();
		Cell target;
		
		target = list.get(rand.nextInt(list.size()));
		index = rand.nextInt(target.candidate.size());
		target.setAnswer(target.candidate.get(index));
		return target;
	}
	
	Cell placeLesserCandSum(ArrayList<Cell> list){
		int index,temp,cand = board.candCountSquare();
		Random rand = new Random();
		Cell[] origin = board.cellTrack();
		ArrayList<Integer> cans;
		ArrayList<Cell> places = new ArrayList<Cell>();
		ArrayList<Integer> nums = new ArrayList<Integer>();
		
		for(Cell target:list){
			cans = new ArrayList<Integer>(target.candidate);
			for(Integer num:cans){
				target.setAnswer(num);
				temp = board.candCountSquare();
				board.cellRestore(origin);
				if(temp < cand){
					places.clear();
					nums.clear();
					cand = temp;
				}
				if(temp == cand){
					places.add(target);
					nums.add(num);
				}
			}
		}
		index = rand.nextInt(places.size());
		places.get(index).setAnswer(nums.get(index));
		return places.get(index);
	}
	
	Cell placeHarderMethod(ArrayList<Cell> list){
		int index,diff = 1,tempDiff;
		Random rand = new Random();
		Cell[] origin = board.cellTrack();
		ArrayList<Integer> cans;
		ArrayList<Cell> places = new ArrayList<Cell>();
		ArrayList<Integer> nums = new ArrayList<Integer>();
		
		for(Cell target:list){
			cans = new ArrayList<Integer>(target.candidate);
			for(Integer num:cans){
				target.setAnswer(num);
				Solver.solving();
				tempDiff = Solver.getDifficulty();
				board.cellRestore(origin);
				if(tempDiff > diff){
					places.clear();
					nums.clear();
					diff = tempDiff;
				}
				if(tempDiff == diff){
					places.add(target);
					nums.add(num);
				}
			}
		}
		//System.out.println("Diff → "+diff);
		index = rand.nextInt(places.size());
		places.get(index).setAnswer(nums.get(index));
		return places.get(index);
		
	}

//	boolean emptyMinimize(String mode){
//		Integer origin;	//変更前の数字
//		int empty,tempEmpty;
//		Cell[] originState = new Cell[81];
//		Cell[] tempState = new Cell[81];
//		Cell[] changedState = new Cell[81];
//		ArrayList<Integer> tempCand;
//		ArrayList<Cell> initList = new ArrayList<Cell>();
//		Cell c;
//		
//		changes = 0;
//		switch(mode){
//		case "RANDOM": makeAllRandom();break;
//		case "ERASE": makeErase();break;
//		case "NARROW": makeNarrow();break;
//		case "SOFT": makeNarrowSoft();break;
//		}
//		for(int i=0;i<81;i++)
//			if(init[i]) initList.add(board.cell[i]);
//		originState = board.cellTrack();
//		if(solver.solving()){
//			return true;
//		}else empty = board.emptyCount();
//		for(int i=0;i<initList.size();i++){
//			board.cellRestore(originState);
//			c = initList.get(i);
//			origin = c.answer;
//			c.cancelAnswer();
//			if(c.candidate.size() == 1) continue;
//			tempState = board.cellTrack();
//			tempCand = new ArrayList<Integer>(c.candidate);
//			for(Integer num:tempCand){
//				if(num == origin){
//					board.cellRestore(tempState);
//					continue;
//				}
//				c.setAnswer(num);
//				changedState = board.cellTrack();
//				if(solver.solving()){
//					changes++;
//					return true;
//				}else tempEmpty = board.emptyCount();
//				board.cellRestore(changedState);
//				if(tempEmpty < empty){
//					changes++;
//					empty = tempEmpty;
//					originState = board.cellTrack();
//					i = -1;
//					break;
//				}
//				board.cellRestore(tempState);
//			}
//		}
//		return false;
//		
//	}

	//make > cell_(cand_(change > check > restore))	
//	boolean emptyMinimize(String mode){
//		Integer origin;	//変更前の数字
//		int empty,tempEmpty,goal;
//		boolean isChanged;
//		Cell[] originState = new Cell[81];
//		Cell[] tempState = new Cell[81];
//		Cell[] changedState = new Cell[81];
//		ArrayList<Integer> tempCand;
//		ArrayList<Cell> initList = new ArrayList<Cell>();
//		Cell c;
//		
//		changes = 0;
//		switch(mode){
//		case "RANDOM": makeRandom();break;
//		case "ERASE": makeErase();break;
//		case "NARROW": makeNarrow();break;
//		case "SOFT": makeNarrowSoft();break;
//		}
//		for(int i=0;i<81;i++)
//			if(init[i]) initList.add(board.cell[i]);
//		originState = board.cellTrack();
//		if(solver.solving()){
//			
//			return true;
//		}else empty = board.emptyCount();
//		goal = hint;
//		isChanged = false;
//		for(int i=0;i<hint;i++){
//			board.cellRestore(originState);
//			c = initList.get(i);
//			origin = c.answer;
//			c.cancelAnswer();
//			if(c.candidate.size() == 1) continue;
//			tempState = board.cellTrack();
//			tempCand = new ArrayList<Integer>(c.candidate);
//			for(Integer num:tempCand){
//				if(num == origin){
//					board.cellRestore(tempState);
//					continue;
//				}
//				c.setAnswer(num);
//				changedState = board.cellTrack();
//				if(solver.solving()){
//					changes++;
//					return true;
//				}else tempEmpty = board.emptyCount();
//				board.cellRestore(changedState);
//				if(tempEmpty < empty){
//					changes++;
//					isChanged = true;
//					goal = i;
//					empty = tempEmpty;
//					originState = board.cellTrack();
////					i = -1;
////					break;
//				}
//				board.cellRestore(tempState);
//			}
//			if(i == initList.size()-1 & isChanged){
//				i = -1;
//				isChanged = false;
//			}
//			if(i == goal-1 & !isChanged) break;
//		}
//		return false;
//		
//	}
	
	boolean replaceLesserEmpty(ArrayList<Cell> initList){
		int originAns,empty;
		Cell[] originState,tempState;
		ArrayList<Integer> tempCand;
		
		//System.out.println("normal");
		empty = board.emptyCount();
		board.problemReset();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}else{
				tempState = board.cellTrack();
				tempCand = new ArrayList<Integer>(c.candidate);
			}
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				if(Solver.solving()){
					changes++;
					return true;
				}
				if(board.emptyCount() < empty){
					changes++;
					return true;
				}
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		return false;
	}
	
	boolean replaceLeastEmpty(ArrayList<Cell> initList){
		int originAns,empty,tempEmpty;
		Cell[] originState,tempState,changedState = null;
		ArrayList<Integer> tempCand;
		
		empty = board.emptyCount();
		board.problemReset();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}else{
				tempState = board.cellTrack();
				tempCand = new ArrayList<Integer>(c.candidate);
			}
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				if(Solver.solving()){
					changes++;
					return true;
				}else{
					tempEmpty = board.emptyCount();
					if(tempEmpty < empty){
						changedState = board.cellTrack();
						empty = tempEmpty;
					}
				}
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		if(changedState != null){
			changes++;
			board.cellRestore(changedState);
			return true;
		}
		return false;
	}
	
	//	boolean candMinimize(String mode){
//		Integer origin;	//変更前の数字
//		int candSum,tempSum;	//候補数字の平方合計数
//		Cell[] originState = new Cell[81];
//		Cell[] tempState = new Cell[81];
//		Cell[] changedState = new Cell[81];
//		ArrayList<Integer> tempCand;
//		ArrayList<Cell> initList = new ArrayList<Cell>();
//		Cell c;
//		
//		changes = 0;
//		switch(mode){
//		case "RANDOM": makeRandom();break;
//		case "ERASE": makeErase();break;
//		case "NARROW": makeNarrow();break;
//		case "SOFT": makeNarrowSoft();break;
//		}
//		for(int i=0;i<81;i++)
//			if(init[i]) initList.add(board.cell[i]);
//		originState = board.cellTrack();
//		if(solver.solving()){
//			return true;
//		}else candSum = board.candCountSquare();
//		for(int i=0;i<initList.size();i++){
//			board.cellRestore(originState);
//			c = initList.get(i);
//			origin = c.answer;
//			c.cancelAnswer();
//			if(c.candidate.size() == 1) continue;
//			tempState = board.cellTrack();
//			tempCand = new ArrayList<Integer>(c.candidate);
//			for(Integer num:tempCand){
//				if(num == origin){
//					board.cellRestore(tempState);
//					continue;
//				}
//				c.setAnswer(num);
//				changedState = board.cellTrack();
//				if(solver.solving()){
//					changes++;
//					return true;
//				}
//				board.cellRestore(changedState);
//				tempSum = board.candCountSquare();
//				if(tempSum < candSum){
//					changes++;
//					candSum = tempSum;
//					originState = board.cellTrack();
//					i = -1;
//					break;
//				}
//				board.cellRestore(tempState);
//			}
//		}
//		return false;
//		
//	}
	
	boolean replaceLesserCandSum(ArrayList<Cell> initList){
		int originAns,candSum;
		Cell[] originState,tempState;
		ArrayList<Integer> tempCand;
		
		board.problemReset();
		candSum = board.candCountSquare();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}else{
				tempCand = new ArrayList<Integer>(c.candidate);
				tempState = board.cellTrack();
			}
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				if(Solver.solving()){
					//System.out.println("Rep Diff -> "+Solver.getDifficulty()); //test
					changes++;
					return true;
				}				
				board.problemReset();
				if(board.candCountSquare() < candSum){
					changes++;
					return true;
				}				
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		return false;
	}
	
	boolean replaceLeastCandSum(ArrayList<Cell> initList){
		int originAns,candSum,tempCandSum;
		Cell[] originState,tempState,changedState = null;
		ArrayList<Integer> tempCand;
		
		board.problemReset();
		candSum = board.candCountSquare();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}else{
				tempCand = new ArrayList<Integer>(c.candidate);
				tempState = board.cellTrack();
			}
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				if(Solver.solving()){
					//System.out.println("Rep Diff -> "+Solver.getDifficulty()); //test
					changes++;
					return true;
				}else{
					board.problemReset();
					tempCandSum = board.candCountSquare();
					if(tempCandSum < candSum){
						changedState = board.cellTrack();
						candSum = tempCandSum;
					}
				}
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		if(changedState != null){
			changes++;
			board.cellRestore(changedState);
			return true;
		}
		return false;
	}
	
	boolean replaceLesserEmptyHarder(ArrayList<Cell> initList){
		int originAns,diff,tempDiff,empty,tempEmpty;
		Cell[] originState,tempState;
		ArrayList<Integer> tempCand;
		
		//System.out.println("harder");
		diff = Solver.getDifficulty();
		empty = board.emptyCount();
		//System.out.println("initEmpty → "+empty+" initDiff → "+diff); //test
		board.problemReset();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}
			tempState = board.cellTrack();
			tempCand = new ArrayList<Integer>(c.candidate);
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				Solver.solving();
				tempEmpty = board.emptyCount();
				tempDiff = Solver.getDifficulty();
				if(tempEmpty < empty & tempDiff >= diff){
					changes++;
					Solver.difficulty = tempDiff;
					return true;
				}				
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		return false;
	}
	
	//空白マス数減少 かつ 解法難度向上 で変更採用
	boolean replaceLeastEmptyHarder(ArrayList<Cell> initList){
		int originAns,diff,tempDiff,empty,tempEmpty;
		Cell[] originState,tempState,changedState = null;
		ArrayList<Integer> tempCand;
		
		diff = Solver.getDifficulty();
		empty = board.emptyCount();
		//System.out.println("initEmpty → "+empty+" initDiff → "+diff); //test
		board.problemReset();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}
			tempState = board.cellTrack();
			tempCand = new ArrayList<Integer>(c.candidate);
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				Solver.solving();
				tempEmpty = board.emptyCount();
				tempDiff = Solver.getDifficulty();
				if(tempEmpty < empty & tempDiff >= diff){
					if(Solver.result()){
						Solver.difficulty = tempDiff;
						//System.out.println("Diff → "+tempDiff); //test
						return true;
					}
					changedState = board.cellTrack();
					diff = tempDiff;
					empty = tempEmpty;
				}
				
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		if(changedState != null){
			//System.out.println("Empty → "+empty+" Diff → "+diff); //test
			changes++;
			Solver.difficulty = diff;
			board.cellRestore(changedState);
			return true;
		}
		return false;
	}
	
	boolean replaceLesserCandSumHarder(ArrayList<Cell> initList){
		int originAns,diff,tempDiff,candSum,tempCandSum;
		Cell[] originState,tempState;
		ArrayList<Integer> tempCand;
		
		diff = Solver.getDifficulty();
		//System.out.println("initDiff → "+diff); //test
		board.problemReset();
		candSum = board.candCountSquare();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}
			tempState = board.cellTrack();
			tempCand = new ArrayList<Integer>(c.candidate);
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				tempCandSum = board.candCountSquare();
				Solver.solving();
				tempDiff = Solver.getDifficulty();
				if(tempCandSum < candSum & tempDiff >= diff){
					changes++;
					Solver.difficulty = tempDiff;
					return true;
				}
				
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		return false;
	}

	//候補数字平方和減少 かつ 解法難度向上 で変更採用
	boolean replaceLeastCandSumHarder(ArrayList<Cell> initList){
		int originAns,diff,tempDiff,candSum,tempCandSum;
		Cell[] originState,tempState,changedState = null;
		ArrayList<Integer> tempCand;
		
		diff = Solver.getDifficulty();
		//System.out.println("initDiff → "+diff); //test
		board.problemReset();
		candSum = board.candCountSquare();
		originState = board.cellTrack();
		for(Cell c:initList){
			originAns = c.answer;
			c.cancelAnswer();
			if(c.candidate.size() == 1){
				c.setAnswer(originAns);
				continue;
			}
			tempState = board.cellTrack();
			tempCand = new ArrayList<Integer>(c.candidate);
			for(Integer num:tempCand){
				if(num == originAns) continue;
				c.setAnswer(num);
				tempCandSum = board.candCountSquare();
				Solver.solving();
				tempDiff = Solver.getDifficulty();
				if(tempCandSum < candSum & tempDiff >= diff){
					if(Solver.result()){
						//System.out.println("Diff → "+tempDiff); //test
						return true;
					}
					changedState = board.cellTrack();
					diff = tempDiff;
					candSum = tempCandSum;
				}
				
				board.cellRestore(tempState);
			}
			board.cellRestore(originState);
		}
		if(changedState != null){
			//System.out.println("Cand → "+candSum+" Diff → "+diff); //test
			changes++;
			Solver.difficulty = diff;
			board.cellRestore(changedState);
			board.problemReset();
			return true;
		}
		return false;
	}
	
	
	
//	String[] minimizingTimesTest(int times,String makeMode,String minimizeMode){
//		long total,indiv;
//		String[] logs = new String[times+1];
//		int changeTotal = 0,trial = 0,trialTotal = 0;
//		boolean isSuccess = false;
//		
//		archive.clear();
//		total = System.nanoTime();
//		indiv = System.nanoTime();
//		while(archive.size() < times){
//			trial++;
////			System.out.println(trial);
//			switch(minimizeMode){
//			case "EMPTY":isSuccess = emptyMinimize(makeMode);break;
//			case "CAND":isSuccess = candMinimize(makeMode);break;
//			}
//			if(isSuccess){
//				if(!isDuplicate()){
//					archive.add(board.cellTrack());
//					logs[archive.size()-1] = archive.size()+","+trial+","+changes+","+((System.nanoTime() - indiv)/1000000);
//					changeTotal += changes;
//					trialTotal += trial;
////					System.out.println(logs[archive.size()-1]);
//				}
//				trial = 0;
//				indiv = System.nanoTime();
//			}
//		}
//		if(makeMode == "SOFT") logs[times] = "total,"+trialTotal+","+changeTotal+","+((System.nanoTime() - total)/1000000)+",border,"+border;
//		else logs[times] = "total,"+trialTotal+","+changeTotal+","+((System.nanoTime() - total)/1000000);
////		System.out.println(logs[times]);
//		return logs;
//	}
	
	String[] replacingTimesTest(int times,String makeMode,String replaceMode){
		long total,indiv;
		String[] logs = new String[times+1];
		ArrayList<Cell> initList = board.getInitList(); 
		int changeTotal = 0,trial = 0,trialTotal = 0;
		
		archive.clear();
		total = System.nanoTime();
		indiv = System.nanoTime();
		while(archive.size() < times){
			trial++;
			if(create(initList,makeMode,replaceMode)){
				if(!isDuplicate()){
					archive.add(board.cellTrack());
					logs[archive.size()-1] = archive.size()+","+trial+","+changes+","+((System.nanoTime() - indiv)/1000000+","+Solver.difficulty);
					changeTotal += changes;
					trialTotal += trial;
				}
				trial = 0;
				indiv = System.nanoTime();
			}
			
		}
		if(makeMode == "SOFT") logs[times] = "total,"+trialTotal+","+changeTotal+","+((System.nanoTime() - total)/1000000)+",border,"+border;
		else logs[times] = "total,"+trialTotal+","+changeTotal+","+((System.nanoTime() - total)/1000000);
		return logs;
	}
	
	String[] replacingPeriodTest(long period,String makeMode,String replaceMode){
		long start,indiv;
		ArrayList<String> logs = new ArrayList<String>();
		ArrayList<Cell> initList = board.getInitList(); 
		int changeTotal = 0,trial = 0,trialTotal = 0;
		
//		String l;
		
		archive.clear();
		start = System.currentTimeMillis();
		indiv = System.nanoTime();
		while(System.currentTimeMillis() - start < period){
			trial++;
			if(create(initList,makeMode,replaceMode)){
				if(!isDuplicate()){
//					l = archive.size()+","+trial+","+changes+","+((System.nanoTime() - indiv)/1000000);
//					System.out.println(l);
//					logs.add(l);
					logs.add(archive.size()+","+trial+","+changes+","+((System.nanoTime() - indiv)/1000000));
					archive.add(board.cellTrack());
					changeTotal += changes;
					trialTotal += trial;
				}
				trial = 0;
				indiv = System.nanoTime();
			}
		}
		if(makeMode == "SOFT") logs.add("total,"+logs.size()+"/"+(trialTotal+trial)+","+changeTotal+",border,"+border);
		else logs.add("total,"+logs.size()+"/"+(trialTotal+trial)+","+changeTotal);
		return logs.toArray(new String[logs.size()]);
	}
	
//	String[] minimizingPeriodTest(long period,String makeMode,String minimizeMode){
//		long start,indiv;
//		ArrayList<String> logs = new ArrayList<String>();
//		int changeTotal = 0,trial = 0,trialTotal = 0;
//		boolean isSuccess = false;
//		
//		archive.clear();
//		start = System.currentTimeMillis();
//		indiv = System.nanoTime();
//		while(System.currentTimeMillis() - start < period){
//			trial++;
////			System.out.println(trial);
//			switch(minimizeMode){
//			case "EMPTY":isSuccess = emptyMinimize(makeMode);break;
//			case "CAND":isSuccess = candMinimize(makeMode);break;
//			}
//			if(isSuccess){
//				if(!isDuplicate()){
//					archive.add(board.cellTrack());
//					logs.add(archive.size()+","+trial+","+changes+","+((System.nanoTime() - indiv)/1000000));
//					changeTotal += changes;
//					trialTotal += trial;
////					System.out.println(logs[archive.size()-1]);
//				}
//				trial = 0;
//				indiv = System.nanoTime();
//			}
//		}
//		if(makeMode == "SOFT") logs.add("total,"+logs.size()+"/"+(trialTotal+trial)+","+changeTotal+",border,"+border);
//		else logs.add("total,"+logs.size()+"/"+(trialTotal+trial)+","+changeTotal);
////		System.out.println(logs[times]);
//		return logs.toArray(new String[logs.size()]);
//	}
	
	String[] makingPeriodTest(long period, String makeMode){
		long start,indiv;
		ArrayList<Cell> initList = board.getInitList();
		ArrayList<String> logs = new ArrayList<String>();
		int trial = 0,total = 0;
		
		archive.clear();
		start = System.currentTimeMillis();
		indiv = System.nanoTime();
		while(System.currentTimeMillis() - start < period){
			trial++;
			switch(makeMode){
			case "RANDOM":makeRandom(initList);break;
			case "NARROW":makeNarrow(initList);break;
			case "SOFT":makeNarrowSoft(initList);break;
			case "ERASE":makeErase();break;
			}
			if(Solver.solving()){
				if(!isDuplicate()){
					archive.add(board.cellTrack());
					logs.add(archive.size()+","+trial+","+((System.nanoTime() - indiv)/1000000));
					total += trial;
				}
				trial = 0;
				indiv = System.nanoTime();
			}
		}
		if(makeMode == "SOFT") logs.add("total,"+logs.size()+"/"+(total+trial)+",border,"+border);
		else logs.add("total,"+logs.size()+"/"+(total+trial));
		return logs.toArray(new String[logs.size()]);
	}

}
	

