import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class CreatingFrame extends SudokuFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	JLabel hintLabel=null;
	//JLabel creating=null;
	JButton OK,clear;
	JCheckBox harder;
	Creator creator;
	
	public CreatingFrame(boolean isDemo){
		setTitle("SudokuGenerator");
		setLayout(null);
		setBounds(0,0,450,328);
		//if(isDemo) hint = 24;
		
		OK=new JButton("OK");	
		OK.setBounds(335,140,60,30);
		add(OK);
		OK.addActionListener(this);
		clear=new JButton("クリア");	
		clear.setBounds(325,180,80,30);
		add(clear);
		clear.addActionListener(this);
		
		hintLabel=new JLabel("初期配置の数:"+0);
		hintLabel.setBounds(320,110,100,30);
		add(hintLabel);
		
		creating=new JLabel("生成中");
		creating.setForeground(Color.red);
		creating.setBounds(335,220,100,30);
		creating.setVisible(false);
		add(creating);
		
		harder = new JCheckBox("高難易度化",false);
		harder.setBounds(315, 70, 200, 30);
		add(harder);
		
		outer = new JPanel();
		outer.setLayout(null);
		outer.setLocation(0,0);
		outer.setPreferredSize(new Dimension(291,291));
		outer.setSize(outer.getPreferredSize());
		outer.setBackground(Color.BLACK);
		outer.setOpaque(true);
		outer.setVisible(true);
		add(outer);
		
		panel = new SudokuPanel[81];
		for(int i = 0; i < panel.length; i++){
				panel[i] = new SudokuPanel(this);
				panel[i].setLocation((i%9)*32+(i%9)/3,(i/9)*32+(i/9)/3);
				panel[i].setVisible(true);
				panel[i].createInit();
				outer.add(panel[i]);
		}
		
		if(isDemo){
			int[] demoPattern =
				{
					0,0,1,1,0,0,0,1,0,
					0,1,0,0,0,0,0,0,1,
					0,1,0,0,1,0,0,1,0,
					0,0,0,1,0,1,0,0,1,
					0,0,1,0,0,0,1,0,0,
					1,0,0,1,0,1,0,0,0,
					0,1,0,0,1,0,0,1,0,
					1,0,0,0,0,0,0,1,0,
					0,1,0,0,0,1,1,0,0
				};
			for(int i=0;i<81;i++)
				if(demoPattern[i]>0) panel[i].changeInit();
		}
		
		
		
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent arg0) {
		int hint = panel[0].getHint();
		boolean[] place = new boolean[81]; 
		if(arg0.getSource() == OK){
			if(hint == 0){
				new SudokuAlert(this,"初期配置がありません");
				return;
			}
			for(int i=0;i<81;i++){
				place[i]=panel[i].getIsClicked();
			}
			setVisible(false);
			creator=new Creator(place,hint);
			if(harder.isSelected()){
				creator.makeMode = "RANDOM";
				creator.replaceMode = "CAND_H";
			}else{
				creator.makeMode = "NARROW";
				creator.replaceMode = "EMPTY";
			}
			//im.setModal(false);
//			im = new infoMessage(this);
//			im.setVisible(true);
			JDialog d = new JOptionPane("生成中").createDialog(this,"問題生成中");
			d.setModal(false);
			d.setVisible(true);
			
			if(creator.creating()){
				setVisible(true);
				//im.setVisible(false);
				new ResultFrame(this,creator);
			}else{
				//creating.setVisible(false);
				setVisible(true);
				//im.setVisible(false);
				new SudokuAlert(this,"","生成に失敗しました");
			}
			d.dispose();
		}else{
			resetPanels();
		}
	}
	
	public void rewriteHintNumber(int num){
		hintLabel.setText("初期配置の数:"+Integer.toString(num));
		repaint();
	}
	
	public void resetPanels(){
		for(SudokuPanel p:panel) p.resetNumber(); 
		rewriteHintNumber(0);
	}
}

//class infoMessage extends JDialog implements ActionListener{
//	private static final long serialVersionUID = 1L;
//	JLabel label;
//	
//	infoMessage(SudokuFrame owner){
//		super(owner);
//		setLayout(null);
//		setSize(270,130);
//		setLocationRelativeTo(null);
//
//		label = new JLabel("生成中");
//		label.setBounds(70,10,160,30);
//		add(label);
//		//setModal(false);
//		//setVisible(true);
//	}
//	
//	public void actionPerformed(ActionEvent arg0){
//		//parent.creating.setVisible(false);
//		dispose();
//	}
//}
