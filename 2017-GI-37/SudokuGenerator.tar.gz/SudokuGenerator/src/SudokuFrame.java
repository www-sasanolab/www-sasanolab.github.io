import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class SudokuFrame extends JFrame{
	private static final long serialVersionUID = 1L;
	SudokuPanel panel[];
	JPanel outer;
	JLabel creating;
	int hint;
	
	public void rewriteHintNumber(int num){
	}
	
	public void resetPanels(){
	}
}

class SudokuAlert extends JDialog implements ActionListener{
	private static final long serialVersionUID = 1L;
	SudokuFrame parent;
	JLabel alertLabel;
	JButton alertOK;
	
	SudokuAlert(SudokuFrame owner,String message){
		super(owner,"初期配置数エラー",true);
		setLayout(null);
		setSize(270,130);
		setLocationRelativeTo(null);
		
		parent = owner;
		alertLabel = new JLabel(message);
		alertLabel.setBounds(70,10,160,30);
		add(alertLabel);
		alertOK = new JButton("OK");
		alertOK.setBounds(100,50,60,30);
		add(alertOK);
		alertOK.addActionListener(this);
		setVisible(true);
	}
	
	SudokuAlert(SudokuFrame owner,String title,String message){
		super(owner,title,true);
		setLayout(null);
		setSize(270,130);
		setLocationRelativeTo(null);
		
		parent = owner;
		alertLabel = new JLabel(message);
		alertLabel.setBounds(70,10,160,30);
		add(alertLabel);
		alertOK = new JButton("OK");
		alertOK.setBounds(100,50,60,30);
		add(alertOK);
		alertOK.addActionListener(this);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent arg0){
		//parent.creating.setVisible(false);
		dispose();
	}
}
