import java.util.ArrayList;
import java.util.HashSet;

class Board {
	Cell[] cell = new Cell[81];
	Cell[][] row = new Cell[9][9];
	Cell[][] column = new Cell[9][9];
	Cell[][] brock = new Cell[9][9];
	boolean[] places = null;
	BoardLog current = null;
	ArrayList<BoardLog> logs = new ArrayList<BoardLog>();
	ArrayList<BoardState> stateLog;
	
	Board(){
		init();
	}
	
	Board(boolean[] init){
		places = init;
		init();
	}
	
	Board(int[][] initials){
		init();
		for(int i=0;i<81;i++){
			if(initials[i/9][i%9]!= 0){
				cell[i].setAnswer(initials[i/9][i%9]);
				places[i] = true;
			}
		}
	}
	
	Board(int[] initials){
		init();
		places = new boolean[81];
		for(int i=0;i<81;i++){
			if(initials[i] != 0){
				cell[i].setAnswer(initials[i]);
				cell[i].isInit = true;
				places[i] = true;
			}
		}
	}
	
	//初期化処理
	//cellを初期化し、各領域配列と各マスの親領域をセット
	void init(){
		for(int i=0;i<81;i++){
			cell[i] = new Cell(this);
			row[i/9][i%9] = cell[i];
			column[i%9][i/9] = cell[i];
			brock[3*((i/9)/3)+(i%9)/3][3*((i/9)%3)+(i%9)%3] = cell[i];
			cell[i].id = i;
			cell[i].id_r = i/9;
			cell[i].id_c = i%9;
			cell[i].id_b = 3*(cell[i].id_r/3)+cell[i].id_c/3;
			cell[i].parentRow = row[i/9];
			cell[i].parentColumn = column[i%9];
			cell[i].parentBrock = brock[3*((i/9)/3)+(i%9)/3];
			if(places != null) cell[i].isInit = places[i];
		}
	}
	
	//全セルリセット
	//解と候補Listを初期化
	void cellReset(){
		for(Cell c:cell) c.init();
	}
	
	//初期配置でない全てのマスリセット+再絞込み
	//解と候補Listを初期化
	void problemReset(){
		for(Cell c:cell)
			if(!c.isInit) c.init();
		allNarrowing();
	}
	
	//候補チェック
	//answerが0かつcandidateのサイズが0のマスがある→false,無い→true
	boolean candCheck(){
		for(Cell target:cell)
			if(target.answer == 0 & target.candidate.size() == 0) return false;
		return true;
	}
	
	//候補カウント
	//盤面中の候補数字の合計個数を返す
	int candCount(){
		int num = 0;
		
		for(Cell target:cell) num += target.candidate.size();
		return num;
	} 
	
	//候補カウント
	//盤面中の候補数字の平方和を返す
	int candCountSquare(){
		int num = 0;
		for(Cell target:cell) num += target.candidate.size()*target.candidate.size();
		return num;
	}
	
	//空白マスカウント
	//空白マス数を返す
	int emptyCount(){
		int num = 0;
		
		for(Cell target:cell)
			if(target.answer == 0) num++;
		return num;
	}
	
	//空白の有無チェック
	//空白アリ→true,空白ナシ→false
	boolean isEmpty(){
		for(Cell target:cell)
			if(target.answer == 0) return true;
		return false;
	}
	
	//cellの保存
	//cellをCell[]型の値として出力
	Cell[] cellTrack(){
		Cell track[] = new Cell[81];
		
		for(int i=0;i<81;i++){
			track[i] = new Cell();
			track[i].answer = cell[i].answer;
			track[i].candidate = new ArrayList<Integer>(cell[i].candidate);
		}		
		return track;
	}
	
	//cellの復元
	//Cell[]型の値をcellにコピー
	void cellRestore(Cell track[]){
		for(int i=0;i<81;i++){
			cell[i].answer = track[i].answer;
			cell[i].candidate = new ArrayList<Integer>(track[i].candidate);
		}
	}
	
	BoardLog makeBoardLog(){
		Cell track[] = new Cell[81];
		
		for(int i=0;i<81;i++) track[i] = new Cell(cell[i]);
		return new BoardLog(track);
	}
	
	BoardState getBoardState(){
		Cell[] track = new Cell[81];
		
		for(int i=0;i<81;i++) track[i] = new Cell(cell[i]);
		return new BoardState(track);
	}
	
	//全マス絞り込み
	//確定済み全マスに関して親領域の絞込みを行う
	void allNarrowing(){
		for(Cell target:cell)
			if(target.answer != 0) target.narrowing();
	}
	
	//初期配置マスList取得
	//初期配置である全てのcellをArrayListに格納し、出力
	ArrayList<Cell> getInitList(){
		ArrayList<Cell> initList = new ArrayList<Cell>();
		
		for(Cell c:cell)
			if(c.isInit) initList.add(c);
		return  initList;
	}
	
	//answer配列出力
	//board.cellのanswerをint[][]型配列として出力
	int[][] outputArray(){
		int[][] answer = new int[9][9];
		
		for(int i=0;i<9;i++)
			for(int j=0;j<9;j++) answer[i][j] = cell[i*9+j].answer;
		return answer;
	}
	
	int[] getArrayA(){
		int[] a = new int[81];
		
		for(int i=0;i<81;i++)
			a[i] = cell[i].answer;
		return a;
	}
	
	int[] getArrayQ(){
		int[] q = new int[81];
		
		for(int i=0;i<81;i++)
			if(places[i]) q[i] = cell[i].answer;
		return q;
	}
	
	int getInitDistance(){
		int dis = 0;
		
		for(Cell c:cell)
			if(c.isInit) dis += c.getDistance();
		return dis;
	}
}

class Cell{
	Integer answer;
	ArrayList<Integer> candidate;
	ArrayList<Cell> chain;
	
	//親領域
	Board parentBoard;
	Cell[] parentRow;
	Cell[] parentColumn;
	Cell[] parentBrock;
	
	//セル・行・列・ブロック番号
	int id;
	int id_r;
	int id_c;
	int id_b;
	
	//true → 初期配置マス
	boolean isInit;
	
	Cell(){
		answer = 0;
		candidate = new ArrayList<Integer>();
	}
	
	Cell(Board board){
		parentBoard = board;
		init();
	}
	
	Cell(Cell c){
		answer = c.answer;
		candidate = new ArrayList<Integer>(c.candidate);
		parentBoard = c.parentBoard;
		parentRow = c.parentRow;
		parentColumn = c.parentColumn;
		parentBrock = c.parentBrock;
		id = c.id;
		id_r = c.id_r;
		id_c = c.id_c;
		id_b = c.id_b;
		isInit = c.isInit;
	}
	
	//初期化処理
	//answerに0をセットしてcandidate初期化
	void init(){
		answer = 0;
		initCandidate();
	}
	
	//候補数字初期化
	//candidateに1~9をセット
	void initCandidate(){
		candidate = new ArrayList<Integer>();
		for(int i=1;i<10;i++) candidate.add(i);
	}
	
	//解の確定処理
	//answerに値を代入、candidateを解放し、narrowing実行
	void setAnswer(int num){
		answer = num;
		candidate.clear();
		narrowing();	
	}
	
	//解の取り消し処理
	//一度確定したマスのanswerを取り消す
	void cancelAnswer(){
		answer = 0;
		for(Cell target:parentRow)
			if(target.answer == 0) target.resetCandidate();
		for(Cell target:parentColumn)
			if(target.answer == 0) target.resetCandidate();
		for(Cell target:parentBrock)
			if(target.answer == 0) target.resetCandidate();
	}
	
	//候補数字の再設定
	//candidateを初期化して絞り込み直す
	void resetCandidate(){
		init();
		for(int i=0;i<9;i++){
			if(parentRow[i].answer != 0) candidate.remove(parentRow[i].answer);
			if(parentColumn[i].answer != 0) candidate.remove(parentColumn[i].answer);
			if(parentBrock[i].answer != 0) candidate.remove(parentBrock[i].answer);
		}
	}
	
	//絞り込み処理
	//同領域内のcandidateからanswerを取り除く
	void narrowing(){
		for(int i=0;i<9;i++){
			parentRow[i].candidate.remove(answer);
			parentColumn[i].candidate.remove(answer);
			parentBrock[i].candidate.remove(answer);
		}
	}
	
	int getDistance(){
		int dis = 0;
		int dis_r,dis_c;
		
		for(Cell c:parentBoard.cell){
			if(c == this) continue;
			if(c.isInit){
				dis_r = (this.id_r - c.id_r) * (this.id_r - c.id_r);
				dis_c = (this.id_c - c.id_c) * (this.id_c - c.id_c);
				dis += dis_r + dis_c;			
			}
		}
		return dis;
	}
}

class BoardState{
	Cell[] state;
	Cell[][] row;
	Cell[][] column;
	Cell[][] brock;
	ArrayList<Cell> changedCell;
	ArrayList<Cell> focusedCell;
	String method;
	
	BoardState(){}
	BoardState(Cell[] c){
		state = c;
		setArea();
	}
	
	void setArea(){
		row = new Cell[9][9];
		column = new Cell[9][9];
		brock = new Cell[9][9];
		
		for(int i=0;i<81;i++){
			row[i/9][i%9] = state[i];
			column[i%9][i/9] = state[i];
			brock[3*((i/9)/3)+(i%9)/3][3*((i/9)%3)+(i%9)%3] = state[i];
			state[i].parentRow = row[i/9];
			state[i].parentColumn = column[i%9];
			state[i].parentBrock = brock[3*((i/9)/3)+(i%9)/3];
		}
	}
	
	boolean setChangedCell(Cell[] c){
		
		changedCell = new ArrayList<Cell>();
		for(int i=0;i<81;i++){
			if(c[i].answer != state[i].answer) changedCell.add(state[i]);
			else if(!c[i].candidate.equals(state[i].candidate)) changedCell.add(state[i]);
		}
		if(changedCell.isEmpty()) return false;
		else return true;
	}
	
	boolean setFocusedCell(ArrayList<Cell> list){
		
		focusedCell = new ArrayList<Cell>();
		list = new ArrayList<>(new HashSet<>(list));
		focusedCell.addAll(list);
		if(focusedCell.isEmpty()) return false;
		else return true;
	}
	
}

class BoardLog{
	Cell[] state;
	Cell[][] rowState,columnState,brockState;
	String log;
	int methodDifficulty;
	ArrayList<Cell> changedCell;
	ArrayList<Cell> focusedCell;
	
	BoardLog(){
	}
	
	BoardLog(Cell[] p){
		state = p;
		changedCell = new ArrayList<Cell>();
		focusedCell = new ArrayList<Cell>();
		setArea();
	}
	
	void setArea(){
		rowState = new Cell[9][9];
		columnState = new Cell[9][9];
		brockState = new Cell[9][9];
		
		for(int i=0;i<81;i++){
			rowState[i/9][i%9] = state[i];
			columnState[i%9][i/9] = state[i];
			brockState[3*((i/9)/3)+(i%9)/3][3*((i/9)%3)+(i%9)%3] = state[i];
		}
	}
	
	void printAns(){
		for(int i=0;i<81;i++){
			System.out.print(state[i].answer);
			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
			if((i%9) == 8) System.out.println();
			if(i == 26 | i == 53) System.out.println("-----------");
		}
	}
	
	void printCand(){
		for(int i=0;i<81;i++){
			System.out.print(String.format("%11s",getCand(state[i])));
			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
			if((i%9) == 8) System.out.println();
			if(i == 26 | i == 53) System.out.println("-----------------------------------------------------------------------------------------------------");
		}	
	}
	
	String getCand(Cell c){
		String cands = "(";
		
		for(Integer n:c.candidate) cands += n;
		return cands+")";
	}
	
	void setChangedCell(Cell[] cells){
		
		if(methodDifficulty == 1){
			for(int i=0;i<state.length;i++){
				if(cells[i].answer != state[i].answer){
					changedCell.add(state[i]);
					return;
				}
			}
		}else{
			for(int i=0;i<state.length;i++)
				if(cells[i].candidate.size() != state[i].candidate.size()) changedCell.add(state[i]);			
		}
	}
	
//	void printPreAns(){
//		for(int i=0;i<81;i++){
//			System.out.print(previous[i].answer);
//			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
//			if((i%9) == 8) System.out.println();
//			if(i == 26 | i == 53) System.out.println("-----------");
//		}	
//	}
//	
//	void printPreCand(){
//		for(int i=0;i<81;i++){
//			System.out.print(String.format("%11s",getCand(previous[i])));
//			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
//			if((i%9) == 8) System.out.println();
//			if(i == 26 | i == 53) System.out.println("-----------------------------------------------------------------------------------------------------");
//		}	
//	}
//	
//	void printNextAns(){
//		for(int i=0;i<81;i++){
//			System.out.print(next[i].answer);
//			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
//			if((i%9) == 8) System.out.println();
//			if(i == 26 | i == 53) System.out.println("-----------");
//		}	
//	}
//	
//	void printNextCand(){
//		for(int i=0;i<81;i++){
//			System.out.print(String.format("%11s",getCand(next[i])));
//			if((i%9) == 2 | (i%9) == 5) System.out.print("|");
//			if((i%9) == 8) System.out.println();
//			if(i == 26 | i == 53) System.out.println("-----------------------------------------------------------------------------------------------------");
//		}
//	}
//	

//	
//	String compareAns(){
//		for(int i=0;i<81;i++)
//			if(previous[i].answer != next[i].answer) return "["+((i/9)+1)+","+((i%9)+1)+"-"+next[i].answer+"]";
//		return "not changes";
//	}
//	
//	String compareCand(){
//		String log = "(";
//		boolean flag;
//		
//		for(int i=0;i<81;i++){
//			flag = false;
//			for(Integer num:previous[i].candidate){
//				if(!next[i].candidate.contains(num)){
//					if(flag) log += ","+num;
//					else{
//						flag = true;
//						log += "("+((i/9)+1)+","+((i%9)+1)+"-"+num;
//					}
//				}
//			}
//			if(flag) log += ")";
//		}
//		return log+")";
//	}
//	
//	void setLog(){
//		if(method == "rule1") log = compareAns();
//		else log = compareCand();
//	}
}

class LogReader{
	
	static int getMethodDifficulty(ArrayList<BoardLog> logs){
		int diff = 1;
		
		for(BoardLog log:logs)
			if(log.methodDifficulty > diff) diff = log.methodDifficulty;
		return diff;
	}
	
	static void setChangedCell(ArrayList<BoardLog> logs){
		BoardLog preLog = null;
		
		for(BoardLog log:logs){
			if(log.methodDifficulty == 1){
				for(int i=0;i<log.state.length;i++){
					if(preLog.state[i].answer != log.state[i].answer){
						log.changedCell.add(log.state[i]);
						break;
					}
				}
			}else if(log.methodDifficulty > 1){
				for(int i=0;i<log.state.length;i++)
					if(preLog.state[i].candidate.size() != log.state[i].candidate.size()) log.changedCell.add(log.state[i]);
			}
			preLog = log;
		}
	}
	
	static void setStatesChangedCell(ArrayList<BoardState> logs){
		BoardState preState = null;
		
		for(BoardState state:logs){
			if(state.method != "start")
				state.setChangedCell(preState.state);			
			preState = state;
		}
	}
	
	static void removeDuplicateCell(ArrayList<Cell> list){
		
		list = new ArrayList<Cell>(new HashSet<>(list));
	}
	
}

