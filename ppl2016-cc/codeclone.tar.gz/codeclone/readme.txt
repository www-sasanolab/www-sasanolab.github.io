含まれるのもの
  readme.txt このファイル
  clonedetect.patch
  data/ SML#コンパイラのコードクローン検出実験の結果が含まれるディレクトリ

ツールのコンパイル方法
1. SML#コンパイラ version 2.0.0を以下のページからダウンロード
     http://www.pllab.riec.tohoku.ac.jp/smlsharp/ja/?Download
2. SML#コンパイラ version 2.0.0のmakeおよびinstallの実行
3. SML#コンパイラのトップディレクトリsmlsharp-2.0.0の親ディレクトリで以下のようにパッチをあてる
     patch -p0 < clonedetect.patch
4. 再び、smlsharp-2.0.0内のmakeを実行

ツールの実行方法
SML#コンパイラのトップディレクトリsmlsharp-2.0.0で以下のようにコマンドを実行する
   src/compiler/smlsharp <ディレクトリ名>
<ディレクトリ名>はコードクローン検出を行うソースコードを含むディレクトリへのパスを記述する。
上記コマンドの実行後に検出するコードクローンの大きさの閾値(th_para)とコードクローンに対するパラメータの数の閾値(th_para)を入力するように求められる。入力を求められた時、例えば、
input th_size: 10
input th_para: 0.1
のように入力する。
なお、コードクローン除去部分に現在バグが含まれるため、実行できない(のちに修正予定)。
動作はubuntu 14 32bit、gcc (Ubuntu 4.8.4-2ubuntu1~14.04) 4.8.4、llvm 3.4
で確認


実験結果の読み方
ディレクトリdata内にあるディレクトリはそれぞれの閾値による検出結果が含まれる。
例としてディレクトリdata/10-0.1はth_size=10、th_para=0.1で実行した結果が含まれる。
ディレクトリ内のファイルoutput_....txtはSML#コンパイラのディレクトリsrc/compiler/...に存在するコードクローンが書き込まれている。
ファイルは以下のような形でで書き込まれている。
number
fileName1
begin, end = (a, b), (c, d)
fileName2
begin, end = (x, y), (z, w)
これはnumber番に検出されたコードクローンで、fileName1内のa行目b列からc行目d列までの部分とfileName2内のx行目y列からz行目w列までの部分がお互いにコードクローンとして検出されたことを意味している。
