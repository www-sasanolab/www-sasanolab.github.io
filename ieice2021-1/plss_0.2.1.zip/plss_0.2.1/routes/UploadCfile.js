var express = require('express')
var router = express.Router();
var multer = require('multer');
var fs = require('fs');
var Pythonshell = require('python-shell');
var mutation = require('./mutation');
const { c, cpp, node, python, java } = require('compile-run');

var yellow = '\u001b[33m';
var magenta = '\u001b[35m';
var reset = '\u001b[0m';


var upload = multer({
    dest: '../uploads/'
});


function compile(filedata) {
  return c.runSource(filedata, { timeout: 1000 }, (err, result) => {
      if(err){
          console.log(err);
      } else {
          console.log(result);
      }
  });
}


function run(compile_result, filename, id) {
    var result_stdout = '', exit_code, errortype = '';
    var oriname = filename.split('.')[0]
    var run_result = '';

    exit_code = compile_result.exitCode;
    errortype = compile_result.errorType;

    /*コンパイルエラー時には errortype = compile-time となるが、
      現実装でのmutation生成では無限ループでひとくくりにしている*/
    if (exit_code == 0) {
        result_stdout = compile_result.stdout;
        fs.writeFileSync('../result/' + filename + '/' +  oriname + '.txt', result_stdout);
        run_result = 'run_success';
        console.log(yellow + run_result + reset);
        return run_result;
    } else if (errortype.length > 0) {
        run_result = 'compile_error or infinite_loop';
        console.log(magenta + run_result + reset);
        return run_result;
    }
    /*実行結果が空の場合を許容するか*/
    /*
    if(result_stdout.length == 0){
        run_result = 'stdout_empty';
        console.log(magenta + run_result + reset);
        return run_result;
    }
    */
}

function strComb(array, val) {
    var str = "";
    for (var i in array) {
        str += array[i] + val;
    }
    return str;
}

async function compile_run(filename, file_data){

    //var file_data = fs.readFileSync('../cfile/' + filename, 'UTF-8');
    file_data = file_data.split('\n');
    file_data = strComb(file_data, '\n');

    var compile_result = await compile(file_data);

    var message = run(compile_result, filename);

    if (message == 'infinite_loop'){
      console.log(filename+ ':' + message);
      console.log('出力結果のリザルトファイルは作られていません.')
    }

}


router.get('/', function (req, res) {
    res.render('UC', { title: 'Mutation' });
});

router.post('/', upload.single('importfile'), function (req, res) {
    var filename = req.file.originalname;
        //var dt = new Date();
        message = 'Upload Complete!';
        fs.rename(req.file.path, '../cfile/' + filename, function (err) {
            console.log(filename+ ':' + message);
        })

        var option = {
            args: ['../cfile/' + filename]
        };

        Pythonshell.run('../python/mutation.py', option, function (err, results) {
            if (err) console.log(err);
            console.log(results);
        })

        if (!fs.existsSync('../mutant/' + filename)) {
            fs.mkdirSync('../mutant/' + filename, function (err, folder) {
                if (err) throw err;
                console.log(folder)
            })
        }
        if (!fs.existsSync('../result/' + filename)) {
            fs.mkdirSync('../result/' + filename, function (err, folder) {
                if (err) throw err;
                console.log(folder)
            })
        }

        if (!fs.existsSync('../changedata/' + filename)) {
            fs.mkdirSync('../changedata/' + filename, function (err, folder) {
                if (err) throw err;
                console.log(folder)
            })
        }
    var file_data = fs.readFileSync('../cfile/' + filename, 'UTF-8');

    //compile_run(filename, file_data).then(result => res.send(result));
    compile_run(filename, file_data);
    res.render('UC', { title: 'Mutation' });
    console.log(req.file);
});

module.exports = router;
