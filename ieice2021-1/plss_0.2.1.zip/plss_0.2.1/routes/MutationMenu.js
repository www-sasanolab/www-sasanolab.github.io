var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  var filename = req.query.filename;
  var type = req.query.type;

  res.render('MutationMenu', {
              title: 'MutationMenu',
              filename: filename,
              type: type
              })
});

module.exports = router;
