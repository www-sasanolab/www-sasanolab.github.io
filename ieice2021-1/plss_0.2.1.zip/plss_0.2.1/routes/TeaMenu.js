var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('TeaMenu', { title: 'Mutation' })
});

/*POST home page. */
router.post('/', function (req, res, next) {
  var id = req.body['inputuser'];
  var pass = req.body['inputPassword'];
  res.render('TeaMenu', { title: 'Mutation' });

  console.log(id + "   " + pass);

});

module.exports = router;