var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mutation = require('./mutation');
const { c, cpp, node, python, java } = require('compile-run');
function strIns(str, column, target, data) {
    var str_before = str.slice(0, column);
    var res = str.slice(column).replace(target, data);
    return str_before + res;
}
function strComb(array, val) {
    var str = "";
    for (var i in array) {
        str += array[i] + val;
    }
    return str;
}

var compile = function (filedata, callback) {
    try {
        var resultPromise = c.runSource(filedata, { timeout: 1000 });
    } catch (err) {
        console.log(err);
    }
    resultPromise
        .then(result => {
            callback(result);
        })
        .catch(err => {
            console.log(err);
            callback(err);
        });
}

var run = function (filedata, filename, id, mutant_json, callback) {
    var resultdata = '', exit_code, errortype = '';
    var oriname = filename.split('.')[0]
    compile(filedata, function (result, error) {
        if (error) { callback(error); }
        console.log(result);
        exit_code = result.exitCode;
        errortype = result.errorType;
        if (exit_code != null) {
            resultdata = result.stdout;
        } else if (errortype.length > 0) {
            console.log('無限ループ');
            resultdata = '無限ループ';
        }
        fs.writeFileSync('../result/' + filename + '/mutant-' + String(id) + '-' + oriname + '.txt', resultdata);
        callback(resultdata);
    });

}

router.get('/', function (req, res, next) {
    var filename = req.query.filename;
    var type = req.query.type;
    console.log(req.query);
    var oriname = filename.split('.')[0];
    var contents = fs.readFileSync('../cfile/' + filename, 'UTF-8');
    contents = contents.replace(/</g, "&lt");
    contents = contents.replace(/>/g, "&gt");
    contents = contents.split('\n');
    var json_data = fs.readFileSync('../json/' + oriname + '.json', 'UTF-8');
    json_data = JSON.parse(json_data);

    /*web上でコード断片に選択肢を出すためのタグを追加する*/
    function add_tag(str, id) {
        var tag = mutation.add_option_tag(str);
        if (tag != '') {
            return '<select id=\"' + String(id) + '\"' + 'class=\'select\'  size=1>'
                + tag + '</select>'
        } else {
            return str;
        }
    }

    for (var i = json_data.BOList.length - 1; i >= 0; i--) {
        contents[json_data.BOList[i].end_line - 1]
        = strIns(contents[json_data.BOList[i].end_line - 1],
          json_data.BOList[i].start_column - 1,
          json_data.BOList[i].data.replace(/</g, "&lt").replace(/>/g, "&gt"),
          add_tag(json_data.BOList[i].data, i));
    }

    contents = strComb(contents, '\n');

    /*html上でコードを表示するための記述の確認*/
    console.log(contents);

    res.render('make', {
        title: filename,
        filename: filename,
        contents: contents,
        type: type,
        url: '/list'
    });
});

/*router.get('/lang', function (req, res, next) {
    var filename = req.query.filename;
    var type = req.query.type;
    console.log(req.query);
    var oriname = filename.split('.')[0];
    var contents = fs.readFileSync('../cfile/' + filename, 'UTF-8');
    contents = contents.replace(/</g, "&lt").replace(/>/g, "&gt").split('\n');
    var json_data = fs.readFileSync('../json/' + oriname + '.json', 'UTF-8');
    json_data = JSON.parse(json_data);

    for (var i in json_data.BOList) {
        contents[json_data.BOList[i].end_line - 1] =
            strIns(contents[json_data.BOList[i].end_line - 1],
                json_data.BOList[i].start_column - 1,
                json_data.BOList[i].data.replace(/</g, "&lt").
                    replace(/>/g, "&gt"), '<span style="color:red">' +
                    json_data.BOList[i].data + '</span>');
    }

    contents = strComb(contents, '\n');
    res.render('lang', {
        title: filename,
        filename: filename,
        contents: contents,
        type: type,
        url: '/list'
    });
});
*/
router.post('/', function (req, res, next) {
    console.log(req.body);
    var data = JSON.parse(req.body.data)
    console.log(data)
    var mutation_data = data.data;
    var filename = data.filename, i = 0;
    var filedata = fs.readFileSync('../cfile/' + filename, 'UTF-8');
    filedata = filedata.split('\n');
    var oriname = filename.split(".")[0]
    var jsondata = fs.readFileSync('../json/' + oriname + '.json');
    jsondata = JSON.parse(jsondata);
    var before = [], after = []

    var mutant_json =[];

    if (data.random == 1) {
        while (1) {
            var random = Math.floor(Math.random() * jsondata.BOList.length);
            var mutant_str = mutation.random_mutation(jsondata.BOList[random].data, 0);
            if (mutant_str != '' && mutant_str != jsondata.BOList[random].data) break;
        }

        filedata[jsondata.BOList[random].start_line - 1] = filedata[jsondata.BOList[random].start_line - 1].replace(jsondata.BOList[random].data, mutant_str);
        console.log('random(' + random + '):' + jsondata.BOList[random].data + '-->' + mutant_str);
        before.push(jsondata.BOList[random].data);
        after.push(mutant_str);

        var tempdata = {original_str : jsondata.BOList[random].data, mutant_str : mutant_str,
                        ori_start_line : jsondata.BOList[random].start_line,
                        ori_start_column : jsondata.BOList[random].start_column,
                        ori_end_column : jsondata.BOList[random].end_column };

        mutant_json.push(tempdata);



    } else {
        console.log(mutation_data.length)
        for (i = 0; i < mutation_data.length; i++) {
            console.log(filedata[jsondata.BOList[mutation_data[i].id].start_line - 1]);
            filedata[jsondata.BOList[mutation_data[i].id].start_line - 1] = filedata[jsondata.BOList[mutation_data[i].id].start_line - 1].replace(jsondata.BOList[mutation_data[i].id].data, mutation_data[i].text);
            console.log('-->' + jsondata.BOList[mutation_data[i].id].start_line + ':' + filedata[jsondata.BOList[mutation_data[i].id].start_line - 1]);
            before.push(jsondata.BOList[mutation_data[i].id].data);
            after.push(mutation_data[i].text);
            if(jsondata.BOList[mutation_data[i].id].data != mutation_data[i].text){
              var tempdata = {original_str : jsondata.BOList[mutation_data[i].id].data, mutant_str : mutation_data[i].text,
                              ori_start_line : jsondata.BOList[mutation_data[i].id].start_line,
                              ori_start_column : jsondata.BOList[mutation_data[i].id].start_column,
                              ori_end_column : jsondata.BOList[mutation_data[i].id].end_column };
              mutant_json.push(tempdata);
            }
        }
    }
    filedata = strComb(filedata, '\n');
    console.log(filedata);

    mutant_id = 1;
    while (true) {
        if (!fs.existsSync('../mutant/' + filename + '/mutant-' + String(mutant_id) + '-' + filename)) {
            break;
        } else {
            mutant_id++;
        }
    }


    run(filedata, filename, mutant_id, mutant_json, function (resu, error) {
        if (error) { console.log(error); }
        if (resu == "無限ループ") {
            res.send("無限ループ")
        } else {
            var result = {}
            fs.writeFileSync('../mutant/' + filename + '/mutant-' + String(mutant_id) + '-' + filename, filedata);
            result.before = before;
            result.after = after;

            //どこが変わったかをJSON形式で保存

            mutant_json = JSON.stringify(mutant_json);
            fs.writeFileSync('../changedata/' + filename + '/mutant-' + String(mutant_id) + '-' + filename.split('.')[0] + '.json', mutant_json);
            res.send(result)
        }
    });

});



module.exports = router;
