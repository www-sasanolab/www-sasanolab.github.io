var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');

function strIns(str, start_column, end_column, target, data) {
    var str_start = str.slice(0, start_column);

    if(target.match('&gt') != null || target.match('&lt') != null)
      end_column = end_column + 3;

    var str_body = str.slice(start_column, end_column + 1);
    //console.log(str_body);
    str_body = str_body.replace(target, data);
    var str_end = str.slice(end_column + 1);
    console.log(str_start)
    console.log(str_body)
    console.log(str_end)
    console.log(str_start + str_body + str_end)
    return str_start + str_body + str_end;
}

function strComb(array, val) {
    var str = "";
    for (var i in array) {
        str += array[i] + val;
    }
    return str;
}


router.get('/', function (req, res, next) {
    console.log(req.query);
    var type = req.query.type;
    var filename = req.query.filename, source_filename = '' //source_filenameには生成元のcfile名が入る;
    var contents; //mutationしたcコード
    var namepart = filename.split('-')
    for (i = 2; i < namepart.length; i++) {
        if (i == namepart.length - 1) source_filename += namepart[i]
        else source_filename += namepart[i] + '-'
    }
    var back_filename = filename
    if (type == 'mutant') {
        source_contents = fs.readFileSync('../cfile/' + source_filename, 'UTF-8');
        contents = fs.readFileSync('../mutant/' + source_filename + "/" + filename, 'UTF-8');
        type = 'mutant-list'
        //back_filename = filename.split('-').slice(-1)
    }
    else
        contents = fs.readFileSync('../' + type + '/' + filename, 'UTF-8');

    source_contents = source_contents.replace(/</g, "&lt").replace(/>/g, "&gt").split('\n');
    contents = contents.replace(/</g, "&lt").replace(/>/g, "&gt").split('\n');

    //変更前後の箇所を赤色にしていく
    var json_data = fs.readFileSync('../changedata/' + source_filename + '/'+ filename.split('.')[0] + '.json');
    json_data = JSON.parse(json_data);
    //同じ行に対象が複数の時columnが降順じゃないとバグるので、ソートする

    json_data.sort(function(a,b){
    if(a.ori_start_line < b.ori_start_line) return -1;
    if(a.ori_start_line > b.ori_start_line) return 1;
    return 0;
    });
    json_data.sort(function(a,b){
    if(a.ori_start_column > b.ori_start_column) return -1;
    if(a.ori_start_column < b.ori_start_column) return 1;
    return 0;
    });
    console.log(json_data);

    var source_contents_length_diff = 0, source_contents_sum_diff = 0; //差分
    var source_contents_before_length, source_contents_after_length;

    var contents_length_diff = 0, contents_sum_diff = 0; //差分
    var contents_before_length, contents_after_length;
    console.log(source_contents[json_data[0].ori_start_line - 1]);
    console.log(contents[json_data[0].ori_start_line - 1]);

        for (var i=0; i < json_data.length; i++) {
                  //ソースCファイル
                  source_contents[json_data[i].ori_start_line - 1] =
                  strIns(source_contents[json_data[i].ori_start_line - 1],
                         json_data[i].ori_start_column -1 ,
                         json_data[i].ori_end_column -1 ,
                         json_data[i].original_str.replace(/</g, "&lt").replace(/>/g, "&gt"),
                         '<span style="color:red">' + json_data[i].original_str + '</span>');

                  //mutantCファイル
                  contents[json_data[i].ori_start_line - 1] =
                  strIns(contents[json_data[i].ori_start_line - 1],
                         json_data[i].ori_start_column -1 ,
                         json_data[i].ori_end_column -1 ,
                         json_data[i].mutant_str.replace(/</g, "&lt").replace(/>/g, "&gt"),
                         '<span style="color:red">' + json_data[i].mutant_str + '</span>');
        }

    source_contents = strComb(source_contents, '\n');
    contents = strComb(contents, '\n');

    var source_result = fs.readFileSync('../result/' + source_filename + '/' + source_filename.split('.')[0] +'.txt', 'UTF-8');
    var mutant_result = fs.readFileSync('../result/' + source_filename + '/' + filename.split('.')[0] +'.txt', 'UTF-8');

    res.render('Mcontents', {
        title: filename,
        filename: filename,
        source_filename: source_filename,
        source_contents: source_contents,
        contents: contents,
        source_result: source_result,
        mutant_result: mutant_result,
        type: type,
        name: back_filename,
        url: '/list'
    });
});

var deleteFolderRecursive = function (path) {
    if (fs.existsSync(path)) {
        fs.readdirSync(path).forEach(function (file, index) {
            var curPath = path + "/" + file;
            if (fs.lstatSync(curPath).isDirectory()) { // recurse
                deleteFolderRecursive(curPath);
            } else { // delete file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
};

router.post('/', function (req, res, next) {
    console.log(req.body)
    var type = req.body.type;
    var filename = req.body.filename;
    if (type == "cfile") {
        deleteFolderRecursive('../mutant/' + filename)
        fs.unlinkSync('../cfile/' + filename, function (err) {
            if (err) {
                console.log(err);
            }
        });
        fs.unlinkSync('../json/' + filename.split('.')[0] + '.json/', function (err) {
            if (err) {
                console.log(err);
            }
        });
    } else {
        fs.unlinkSync('../mutant/' + filename.split('-').slice(-1) + '/' + filename, function (err) {
            if (err) {
                console.log(err);
            }
        });
        fs.unlinkSync('../result/' + filename.split('-').slice(-1) + '/' + filename.split('.')[0] + '.txt', function (err) {
            if (err) {
                console.log(err);
            }
        });
    }

    res.send("削除しました");


});

module.exports = router;
