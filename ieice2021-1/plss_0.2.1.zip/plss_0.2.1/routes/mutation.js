var yellow = '\u001b[33m';
var magenta = '\u001b[35m';

var reset = '\u001b[0m';
var BO_List = [
    ['+', '-', '*', '/', '%'],
    ['==', '!='],
    ['<<', '>>'],
    ['<', '<=', '>', '>='],
    ['&&', '||'],
    ['&', '|', '^'],
    ['=']
]

function make_mutation(str, trigger=0) {
    mutants = [str];
    //二項演算子がforとwhileの()内不等式の場合，
    //不等式の向きが反対になるとほとんど意味を成さない出力結果になるので，現状ではその場合不等式を2分割して同じ向き内での変更にする
    if(trigger == 1 && BO_List.length == 7){
        var push_list = [];
        push_list[0] = BO_List[3].slice(0, 2);
        push_list[1] = BO_List[3].slice(2, 4);
        BO_List.splice(3,1);
        BO_List.push(push_list[0]);
        BO_List.push(push_list[1]);
        console.log(BO_List);
        loop = 1;
    }
    for (i = 0; i < BO_List.length; i++) {
        for (j = 0; j < BO_List[i].length; j++) {
            if (str == BO_List[i][j]) {
                for (k = 0; k < BO_List[i].length; k++) {
                    if (k != j)
                      mutants.push(BO_List[i][k])
                }
                return mutants
            }
        }
    }
}
exports.add_option_tag = function (str) { /* "="を赤色表示にしないためのタグ*/
    if (str != '=')
        var mutants = make_mutation(str);
    else return '';

    console.log(mutants)
    var tag = '';
    for (var i = 0; i < mutants.length; i++) {
        tag += '<option>' + mutants[i] + '</option>\n';
    }
    console.log(magenta + tag + reset);
    return tag;
}

exports.random_mutation = function (str, trigger) {
    if (str != '=')
        var mutants = make_mutation(str, trigger);
    else return '';
    if (mutants.length == 0) {
        return '';
    }
    //console.log(mutants.length);
    //var random = Math.floor(Math.random() * (mutants.length - 1)); /*make_mutationでif文ありならこっち*/
    var random = Math.floor(Math.random() * mutants.length);
    console.log(random);
    console.log(yellow + 'str:' + mutants + reset);
    return mutants[random];
}
