var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');

router.get('/', function (req, res, next) {
    console.log(req.query);
    var type = req.query.type;
    var filename = req.query.filename;
    var contents, mutantname = ''
    var namepart = filename.split('-')
    for (i = 2; i < namepart.length; i++) {
        if (i == namepart.length - 1) mutantname += namepart[i]
        else mutantname += namepart[i] + '-'
    }
    var back_filename = filename
    if (type == 'mutant') {
        contents = fs.readFileSync('../mutant/' + mutantname + "/" + filename, 'UTF-8');
        type = 'mutant-list'
        back_filename = filename.split('-').slice(-1)
    }
    else
        contents = fs.readFileSync('../' + type + '/' + filename, 'UTF-8');
    console.log(contents)
    contents = contents.replace(/</g, "&lt").replace(/>/g, "&gt");

    var source_result = fs.readFileSync('../result/' + filename + '/' + filename.split('.')[0] +'.txt', 'UTF-8');
    res.render('contents', {
        title: filename,
        filename: filename,
        contents: contents,
        type: type,
        name: back_filename,
        url: '/list',
        source_result: source_result
    });
});

var deleteFolderRecursive = function (path) {
    if (fs.existsSync(path)) {
        fs.readdirSync(path).forEach(function (file, index) {
            var curPath = path + "/" + file;
            if (fs.lstatSync(curPath).isDirectory()) { // recurse
                deleteFolderRecursive(curPath);
            } else { // delete file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
};

router.post('/', function (req, res, next) {
    console.log(req.body)
    var type = req.body.type;
    var filename = req.body.filename;
    if (type == "cfile") {
        deleteFolderRecursive('../mutant/' + filename)
        fs.unlinkSync('../cfile/' + filename, function (err) {
            if (err) {
                console.log(err);
            }
        });
        fs.unlinkSync('../json/' + filename.split('.')[0] + '.json/', function (err) {
            if (err) {
                console.log(err);
            }
        });
    } else {
        fs.unlinkSync('../mutant/' + filename.split('-').slice(-1) + '/' + filename, function (err) {
            if (err) {
                console.log(err);
            }
        });
        fs.unlinkSync('../result/' + filename.split('-').slice(-1) + '/' + filename.split('.')[0] + '.txt', function (err) {
            if (err) {
                console.log(err);
            }
        });
    }

    res.send("削除しました");


});

module.exports = router;
