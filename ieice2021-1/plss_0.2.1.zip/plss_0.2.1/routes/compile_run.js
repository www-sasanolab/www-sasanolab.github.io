var fs = require('fs')
const { c, cpp, node, python, java } = require('compile-run');

var compile = function (filedata, callback) {
    try {
        var resultPromise = c.runSource(filedata, { timeout: 1000 });
    } catch (err) {
        console.log(err);
    }
    resultPromise
        .then(result => {
            callback(result);
        })
        .catch(err => {
            console.log(err);
            callback(err);
        });
}

exports.run = function (filedata, id, filename, callback) {
    var resultdata = '', exit_code, errortype = '';
    var oriname = filename.split('.')
    compile(filedata, function (result, error) {
        if (error) { callback(error); }
        console.log(result);
        exit_code = result.exitCode;
        errortype = result.errorType;
        if (exit_code != null) {
            resultdata = result.stdout;
        } else if (errortype.length > 0) {
            console.log('無限ループ');
            resultdata = '無限ループ';
        }
        fs.writeFileSync('../result/' + filename + '/mutant-' + String(id) + '-' + oriname + '.txt', resultdata);
        callback(resultdata);
    });

}