var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    var studentID = req.query.studentID;
    console.log(studentID);
    res.render('StuMenu', { title: 'Mutation' })
});

/*POST home page. */
router.post('/', function (req, res, next) {
    console.log(req.body)
    var studentID = req.body.studentID;
    var number_file = fs.readfileSync('../grade/number.txt', 'UTF-8');
    number_file = number_file.split('\n');
    console.log(number_file)
    console.log(studentID);
    res.send('OK!');
});

module.exports = router;