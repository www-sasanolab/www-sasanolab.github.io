var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mutation = require('./mutation');
const { c, cpp, node, python, java } = require('compile-run');

var filename ='';
var before = [], after = [];
var mfilename_list=[];
var opline=[], op_startcolumn_list=[], op_endcolumn_list=[];

var yellow = '\u001b[33m';
var magenta = '\u001b[35m';
var reset = '\u001b[0m';


function strIns(str, column, target, data) {
    var str_before = str.slice(0, column);
    var res = str.slice(column).replace(target, data);
    return str_before + res;
}

function strComb(array, val) {
    var str = "";
    for (var i in array) {
        str += array[i] + val;
    }
    return str;
}

function searchParenthesis(file_data, stmt_list, start_line, end_line, num){
  //start_columnは条件文()の直後の位置になるので，それ以前を探索する
    var end_column = stmt_list[num].start_column
    var line_str = file_data[start_line-1];
    var trigger = 0;
    var end_bracket_count = 0; // コード中の")"をカウント
    var column_list = [];
    for(i = file_data.length-1 ; i>=0 ;i--){
      for(var i = end_column-1; i >= 0 ;i--){
        if(line_str[i] == ")"){
            if(end_bracket_count == 0) end_column = i + 1;
            end_bracket_count += 1;
        }
        if(line_str[i] == "(" ){
            if(end_bracket_count == 1){
              var start_column = i + 1;
              trigger = 1;
              break;
            }
            end_bracket_count -= 1;
        }
      }
      if(trigger == 1)
        break;
    }
    column_list.start_column = start_column;
    column_list.end_column = end_column;
    return column_list;
}

function operatorDetermination(json_data, start_line, end_line, start_column, end_column, mutant_num, file_data){
    var op_list = [];
    var num_list = []; //op_list[i]について、jsondataのoperatorから抜き出したnumberを格納
    var error = '';
    /*mutationをかけるoperatorを選択，現状BOListから('='は対象外なので除く)*/

    for(var i = 0; i < json_data.BOList.length; i++){
            /*選択範囲が1行のみ*/
            if((start_line == end_line) && (start_line == json_data.BOList[i].start_line) && (json_data.BOList[i].data != '=') &&
               (start_column <= json_data.BOList[i].end_column) && (json_data.BOList[i].start_column <= end_column)){
                op_list.push(json_data.BOList[i]);
                num_list.push(i);
            }

            /*選択範囲が2行以上ある*/
            else if((start_line != end_line) &&(start_line <= json_data.BOList[i].start_line) &&
                    (json_data.BOList[i].end_line <= end_line) && (json_data.BOList[i].data != '=')){
                 if(start_line == json_data.BOList[i].start_line){
                  /*始点の行でかつ、列も範囲内のときpush*/
                    if(start_column <= json_data.BOList[i].end_column){
                       op_list.push(json_data.BOList[i]);
                       num_list.push(i);
                    }
                }
                else if(end_line == json_data.BOList[i].end_line){
                  /*終点の行でかつ、列も範囲内のときpush*/
                    if(json_data.BOList[i].start_column <= end_column){
                       op_list.push(json_data.BOList[i]);
                       num_list.push(i);
                    }
                }
                /*始点と終点の間の行では列に関係なくpush*/
                else {
                    op_list.push(json_data.BOList[i]);
                    num_list.push(i);
                }
           }
    }
    /*op_listが空の場合*/
    if(!op_list.length){
        var op_obj = new Object();
        op_obj.error =  'none_of_mutation';
        return op_obj;
    }
    console.log(op_list);
    console.log(num_list);

    if(mutant_num > op_list.length) mutant_num = op_list.length
    var temp_op_list = Array.from(op_list); //下記for文で対象となったミューテーションを削除するためコピーを使用
    var op_list_num = []; //op_list中のミューテーション対象の要素数を格納
    var mutant_str_list =[];
    var op_trigger_list =[]; //op_listの要素がforとwhileの()に該当するなら1を，そうでなければ0を代入
    var stmt_start_column, stmt_end_column;
    var stmt_trigger = 0;
    for(i=0; i< op_list.length ;i++){
       //op_listの位置がfor文とwhile文の()内にあればtrigger = 1、1であるとき、不等式のミューテーション条件を後で変える
       for(n=0; n < json_data.FORList.length; n++){
         var column_list = searchParenthesis(file_data, json_data.FORList, json_data.FORList[n].start_line,
                                             json_data.FORList[n].end_line, n);
         stmt_start_column = column_list.start_column;
         stmt_end_column = column_list.end_column;
         if((json_data.BOList[num_list[i]].start_line == json_data.FORList[n].start_line) &&
            (json_data.BOList[num_list[i]].end_column <= stmt_end_column)){
               op_trigger_list[i] = 1;
         }
       }
       if(op_trigger_list[i] = 1)
         continue;
       //whileも
       for(n=0; n < json_data.WHILEList.length; n++){
         var column_list = searchParenthesis(file_data, json_data.WHILEList, json_data.WHILEList[n].start_line,
                                             json_data.WHILEList[n].end_line, n);
         stmt_start_column = column_list.start_column;
         stmt_end_column = column_list.end_column;
         if((json_data.BOList[num_list[i]].start_line == json_data.WHILEList[n].start_line) &&
            (json_data.BOList[num_list[i]].end_column <= stmt_end_column)){
               op_trigger_list[i] = 1;

         }
       }
     }


    for(i=0 ;i < mutant_num; i++){
      var mutant_str = '';
      do {  //ランダムの結果, 同じoperatorは認めない
             var random = Math.floor(Math.random() * temp_op_list.length);
             if(temp_op_list[random] == 'already'){
                 mutant_str = '';
                 continue;
             }
             var mutant_str = mutation.random_mutation(temp_op_list[random].data, op_trigger_list[random]);
         } while (mutant_str == '' || mutant_str == json_data.BOList[num_list[random]].data);
      temp_op_list[random] = 'already';
      op_list_num[i] = random ;
      mutant_str_list[i] = mutant_str;
    }


    var op_obj = new Object();
    op_obj.op_list = op_list;
    op_obj.op_list_num = op_list_num;
    op_obj.mutant_str_list =  mutant_str_list;
    op_obj.error = error;
    return op_obj;

}

function fileId(filename){
    var mutant_id = 1;
    while (true) {
        if (!fs.existsSync('../mutant/' + filename + '/mutant-' + String(mutant_id) + '-' + filename)) {
              break;
        } else {
              mutant_id++;
        }
    }
    return mutant_id;
}

function compile(filedata) {
  return c.runSource(filedata, { timeout: 500 }, (err, result) => {
      if(err){
          console.log(err);
      } else {
          console.log(result);
      }
  });
}


function run(compile_result, filename, id) {
    var result_stdout = '', exit_code, errortype = '';
    var oriname = filename.split('.')[0]
    var run_result = '';

    exit_code = compile_result.exitCode;
    errortype = compile_result.errorType;

    /*コンパイルエラー時には errortype = compile-time となるが、
      アップロード時に一度ソースファイルをコンパイルを通しているため、現実装でのmutation生成では無限ループでひとくくりにしている*/
    if (exit_code != null) {
        result_stdout = compile_result.stdout;
    } else if (errortype.length > 0) {
        run_result = 'infinite_loop';
        console.log(magenta + run_result + reset);
        return run_result;
    }
    /*実行結果が空の場合を許容するか*/
    /*
    if(result_stdout.length == 0){
        run_result = 'stdout_empty';
        console.log(magenta + run_result + reset);
        return run_result;
    }
    */
    fs.writeFileSync('../result/' + filename + '/mutant-' + String(id) + '-' + oriname + '.txt', result_stdout);
    run_result = 'run_success';
    console.log(yellow + run_result + reset);
    return run_result;
}


async function mainProcess(filename, json_data, inf_loop_num, remaining_generation_number, original_generation_number, range_info){
    console.log('remaining_generation_number:' + remaining_generation_number);
    if(inf_loop_num >= 10 && generation_num == parse_data.generation_number){
      var result = {};
      result.message = "serial_infinite_loop";
      return result;
    }
    /*ループ前提でfileを再度読み込む*/
    var file_data = fs.readFileSync('../cfile/' + filename, 'UTF-8');
    file_data = file_data.split('\n');

    var start_line, end_line, start_column, end_column;　//mutationの範囲

    start_line = range_info.start_line;
    end_line = range_info.end_line;
    start_column = range_info.start_column;
    end_column = range_info.end_column;

    var op_list = [];
    //var before = [], after = [];
    var error = '';


    var mutant_num = range_info.mutant_num;

    if((isNaN(mutant_num) == true) || (mutant_num <= 0)){
                var result = {};
                result.message = 'mutant_number_error';
                return result;
    }

    /* ミューテーションするopを決定 */
    var op_data = operatorDetermination(json_data, start_line, end_line, start_column, end_column, mutant_num, file_data);

    if(op_data.error == 'none_of_mutation'){
      var result = {};
      result.message = "none_of_mutation";
      return result;
    }

    var op_list_num = op_data.op_list_num;
    var mutant_str_list = op_data.mutant_str_list;
    op_list = op_data.op_list;
    var mutant_json = [];
    var before_list = [];
    var opline_list = [];
    var ori_start_str = "", start_str = "";
    var start_str_diff = 0;
    var ori_file_data =　file_data.concat();
    //複数ヶ所の変更に対応する処理
    for(var i=0; i < mutant_str_list.length; i++){

          ori_start_str = ori_file_data[op_list[op_list_num[i]].start_line - 1].slice( 0, op_list[op_list_num[i]].start_column-1);
          start_str = file_data[op_list[op_list_num[i]].start_line - 1].slice( 0, op_list[op_list_num[i]].start_column-1 + start_str_diff);
          start_str_diff = start_str.length - ori_start_str.length;//mutationした行の文字数とオリジナルの行の文字数が異なった場合の処理をする

          file_data[op_list[op_list_num[i]].start_line - 1]
          = start_str + mutant_str_list[i]
          + file_data[op_list[op_list_num[i]].start_line - 1].slice(op_list[op_list_num[i]].end_column + start_str_diff);
          console.log('random(' + op_list_num[i] + '):' + op_list[op_list_num[i]].data + ' --> ' + mutant_str_list[i]);
          var tempdata = {
           original_str : op_list[op_list_num[i]].data, mutant_str : mutant_str_list[i],
           ori_start_line : op_list[op_list_num[i]].start_line,
           ori_start_column : op_list[op_list_num[i]].start_column,
           ori_end_column : op_list[op_list_num[i]].end_column
           };
           before_list.push(op_list[op_list_num[i]].data);
           mutant_json.push(tempdata);
           opline_list.push(op_list[op_list_num[i]].start_line);
      }
      before.push(before_list);
      after.push(mutant_str_list);
      opline.push(opline_list);

      file_data = strComb(file_data, '\n');

      var mutant_id = fileId(filename);

      var compile_result = await compile(file_data);

      var message = run(compile_result, filename, mutant_id);

      if(message == 'infinite_loop'){
          inf_loop_num++;
          console.log("inf_loop_number: " + inf_loop_num)
          return mainProcess(filename, json_data, inf_loop_num, remaining_generation_number, original_generation_number,  range_info);
      }
      else if(message == 'run_success' && remaining_generation_number > 1){
          inf_loop_num = 0;
          remaining_generation_number = remaining_generation_number - 1;
          fs.writeFileSync('../mutant/' + filename + '/mutant-' + String(mutant_id) + '-' + filename, file_data);
          var mfilename = 'mutant-' + String(mutant_id) + '-' + filename;
          mfilename_list.push(mfilename);
          console.log(mfilename_list);
          console.log(yellow + 'next_generation' + reset);

          mutant_json = JSON.stringify(mutant_json);
          fs.writeFileSync('../changedata/' + filename + '/mutant-' + String(mutant_id) + '-' + filename.split('.')[0] + '.json', mutant_json);

          return mainProcess(filename, json_data, inf_loop_num, remaining_generation_number, original_generation_number, range_info);
    }
    else {
        fs.writeFileSync('../mutant/' + filename + '/mutant-' + String(mutant_id) + '-' + filename, file_data);
        var result = new Object();
        result.message = 'run_success';
        result.before = before;
        result.after = after;
        result.opline = opline;
        var mfilename = 'mutant-' + String(mutant_id) + '-' + filename;
        mfilename_list.push(mfilename);
        result.mfilename = mfilename_list;
        console.log(result.mfilename);
        console.log(yellow + result.message + reset);

        mutant_json = JSON.stringify(mutant_json);
        fs.writeFileSync('../changedata/' + filename + '/mutant-' + String(mutant_id) + '-' + filename.split('.')[0] + '.json', mutant_json);
        return result;
    }
}



router.get('/', function (req, res, next) {

  filename = req.query.filename;
  var type = req.query.type;
  console.log(req.query);
  var oriname = filename.split('.')[0];
  var contents = fs.readFileSync('../cfile/' + filename, 'UTF-8');
  contents = contents.replace(/</g, "&lt").replace(/>/g, "&gt").split('\n');
  var json_data = fs.readFileSync('../json/' + oriname + '.json', 'UTF-8');
  json_data = JSON.stringify(json_data)
  //json_data = JSON.parse(json_data);

  /*for (var i in json_data.BOList) {
      if(json_data.BOList[i].data!="="){ /* "="は赤色表示にしない */
  /*      contents[json_data.BOList[i].end_line - 1] =
            strIns(contents[json_data.BOList[i].end_line - 1],
                json_data.BOList[i].start_column - 1,
                json_data.BOList[i].data.replace(/</g, "&lt").
                    replace(/>/g, "&gt"), '<span style="color:red">' +
                    json_data.BOList[i].data + '</span>');
      }
  }
*/
  contents = strComb(contents, '\n');

  res.render('MRange', {
      title: 'MSelectRange',
      filename: filename,
      type: type,
      contents: contents,
      data: '',
      url: '/make',
      back_url: '/MutationMenu',
      json_data: json_data,


  })

});

router.post('/', function (req, res, next) {
      //var temp_data = req.body.obj;
      var range_info = {};
      range_info.start_line = req.body.start_line;
      range_info.start_column = req.body.start_column;
      range_info.end_line = req.body.end_line;
      range_info.end_column = req.body.end_column;
      range_info.mutant_num = req.body.mutant_number;
      //var end_point = req.body.end_value;
      var select_str = req.body.result_str;
      //var line_info = req.body.line_feed_point;
      //line_info = JSON.parse(line_info);

      //console.log("start:" + start_point);
      //console.log("end:" + end_point);
      console.log(select_str);
      console.log("start_line: " + range_info.start_line);
      console.log("start_column: " + range_info.start_column);
      console.log("end_line: " + range_info.end_line);
      console.log("end_column: " + range_info.end_column);

      var oriname = filename.split('.')[0];
      var file_data = fs.readFileSync('../cfile/' + filename, 'UTF-8');
      file_data = file_data.split('\n');
      var json_data = fs.readFileSync('../json/' + oriname + '.json', 'UTF-8');
      json_data = JSON.parse(json_data);

      before = [], after = [];//ここでglobal変数を初期化をしないと、1度確定ボタンを押して2回目再びミューテーションを行ったとき、1度目でpushしたものが引き継がれてしまう。
      mfilename_list=[], opline=[], op_startcolumn_list=[], op_endcolumn_list=[];

      var inf_loop_num = 0;
      //ミューテーションファイルの生成数
      var original_generation_number = req.body.generation_number;
      //残りミューテーションファイルの生成数 -->0になれば終わる
      var remaining_generation_number = req.body.generation_number;
      //parseInt(remaining_generation_number, 10);
      //isNaN(remaining_generation_number)
      //console.log(Number.isInteger(remaining_generation_number));
      if ((isNaN(remaining_generation_number) == true) || (remaining_generation_number <= 0)){
            var result = {};
            result.message = 'generation_number_error';
            res.send(result);
            return;
      }

      mainProcess(filename, json_data, inf_loop_num, remaining_generation_number, original_generation_number, range_info).then(result => res.send(result));
      return ;
})

module.exports = router;
