# -*- coding:utf-8 -*-

import sys
import re
import unicodedata
import os
import subprocess
import json
import re

import clang.cindex
from clang.cindex import Index
from clang.cindex import Config

from time import sleep
from chardet.universaldetector import UniversalDetector
import codecs
from operator import itemgetter, attrgetter
from unicodedata import category

# 以下変数は、複数の関数において使用されるため、グローバル変数としている。
# 文字列を引っこ抜く際の情報を入れるデータ構造

element = ''
depth = 0

json_data = ''
json_func_data = ''
json_ifstmt_data =''
json_forstmt_data = ''
json_whilestmt_data = ''
json_dostmt_data = ''
json_switchstmt_data = ''
json_compoundstmt_data = ''


class pycolor:
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    PURPLE = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    END = '\033[0m'
    BOLD = '\038[1m'
    UNDERLINE = '\033[4m'
    INVISIBLE = '\033[08m'
    REVERCE = '\033[07m'


def is_japanese(ch):
    # この関数で文字が日本語文字かを判断する。
    if unicodedata.east_asian_width(ch) in 'FWA':
        jc = 2
    else:
        jc = 0
    return jc


def data_slice(line, sc, ec, sl, el):
    string = line[sl-1]
    slice_data = ['', 0, 0]
    if sl == el:
        for ch_no in range(ec-1):
            if(ch_no == ec-1):
                break  # 引っこ抜き完了
            jc = is_japanese(string[ch_no])  # 引っこ抜く量から何文字分減らすのかをここで確定
            ec = ec - jc
            slice_data[2] += jc  # slice_data[2]に終点番目から何文字減らしたかを格納
            if(ch_no >= sc-1):  # 開始番目を迎えたら、slice_data[0]に引っこ抜きたい文字を格納していく
                slice_data[0] += string[ch_no]
            else:  # 開始番目を迎えていない時に、日本語が発見されると、開始番目からも2文字減らさなければならない
                sc = sc - jc
                slice_data[1] += jc
    else:
        string = line[sl-1]
        for ch_no in range(len(string)):
            jc = is_japanese(string[ch_no])  # 引っこ抜く量から何文字分減らすのかをここで確定
            slice_data[2] += jc  # slice_data[2]に終点番目から何文字減らしたかを格納
            if(ch_no >= sc-1):  # 開始番目を迎えたら、slice_data[0]に引っこ抜きたい文字を格納していく
                slice_data[0] += string[ch_no]
            else:  # 開始番目を迎えていない時に、日本語が発見されると、開始番目からも2文字減らさなければならない
                sc = sc - jc
                slice_data[1] += jc
        slice_data[0] += '\n'
        sl += 1
        while sl < el:
            slice_data[0] += line[sl-1]+'\n'
            sl += 1

        string = line[el-1]
        for ch_no in range(len(string)):
            if(ch_no == ec-1):
                break  # 引っこ抜き完了
            jc = is_japanese(string[ch_no])  # 引っこ抜く量から何文字分減らすのかをここで確定
            ec = ec - jc
            slice_data[2] += jc  # slice_data[2]に終点番目から何文字減らしたかを格納
            # 開始番目を迎えたら、slice_data[0]に引っこ抜きたい文字を格納していく
            slice_data[0] += string[ch_no]

    return slice_data

def correct_column(data, line): #stmtや関数におけるcolumnの位置を求める
    string = data[line-1]
    cut_column = 0;
    index = 0 ;
    for chr in string:
        index += 1;
        if(chr == "{" or chr == "}"):
            break
        jc = is_japanese(chr)
        cut_column += jc  # 何文字減らすか

    true_column = index - cut_column
    return true_column

def make_jsondata(data, startline, endline, startcolumn, endcolumn):
    global json_data
    json_data += '{\"data\":\"'+data+'\",\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":' + str(startcolumn) \
        + ',\"end_column\":' + str(endcolumn)+'}'

def make_json_func_data(data, startline, endline, startcolumn, endcolumn):
    global json_func_data
    #関数のjsonデータ
    json_func_data += '{\"data\":\"'+data+'\",\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":' + str(startcolumn) \
        + ',\"end_column\":' + str(endcolumn)+'}'

def make_json_stmt_data(startline, endline, startcolumn, endcolumn, num):
    global json_ifstmt_data, json_forstmt_data, json_whilestmt_data, json_dostmt_data, json_compoundstmt_data, json_switchstmt_data
    if(num==0):
        json_ifstmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":'+str(startcolumn) + ',\"end_column\":'+str(endcolumn) + '}'
    elif(num==1):
        json_forstmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":'+str(startcolumn) + ',\"end_column\":'+str(endcolumn) + '}'
    elif(num==2):
        json_whilestmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":'+str(startcolumn) + ',\"end_column\":'+str(endcolumn) + '}'

    elif(num==3):
        json_dostmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) + '}'

    elif(num==4):
        json_compoundstmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + '}'
    elif(num==5):
        json_switchstmt_data += '{\"start_line\":'+str(startline)+',\"end_line\":'+str(endline) \
        + ',\"start_column\":'+str(startcolumn) + ',\"end_column\":'+str(endcolumn) + '}'


def shaping_json_data(num):
    global json_data, json_func_data, json_ifstmt_data, json_forstmt_data, \
           json_whilestmt_data, json_compoundstmt_data, json_dostmt_data, json_switchstmt_data
    if(num==0):
        json_data += '{"BOList":['
        json_func_data += '['
        json_ifstmt_data += '['
        json_forstmt_data += '['
        json_whilestmt_data += '['
        json_dostmt_data += '['
        json_switchstmt_data += '['
        json_compoundstmt_data += '['

    elif(num==1):
        json_data += ']}'
        json_func_data += ']'
        json_ifstmt_data += ']'
        json_forstmt_data += ']'
        json_whilestmt_data += ']'
        json_dostmt_data += ']'
        json_switchstmt_data += ']'
        json_compoundstmt_data += ']'
    elif(num==2):
        json_data = json_data.replace('}{', '},{')
        json_func_data = json_func_data.replace('}{', '},{')
        json_ifstmt_data = json_ifstmt_data.replace('}{', '},{')
        json_forstmt_data = json_forstmt_data.replace('}{', '},{')
        json_whilestmt_data = json_whilestmt_data.replace('}{', '},{')
        json_dostmt_data = json_dostmt_data.replace('}{', '},{')
        json_switchstmt_data = json_switchstmt_data.replace('}{', '},{')
        json_compoundstmt_data = json_compoundstmt_data.replace('}{', '},{')
    elif(num==3):
        json_data = json.loads(json_data)
        json_func_data= json.loads(json_func_data)
        json_ifstmt_data= json.loads(json_ifstmt_data)
        json_forstmt_data= json.loads(json_forstmt_data)
        json_whilestmt_data= json.loads(json_whilestmt_data)
        json_dostmt_data= json.loads(json_dostmt_data)
        json_switchstmt_data= json.loads(json_switchstmt_data)
        json_compoundstmt_data= json.loads(json_compoundstmt_data)
    elif(num==4):
        json_data['BOList'] = BOList
        json_data['FUNCList'] = json_func_data
        json_data['IFList'] = json_ifstmt_data
        json_data['FORList'] = json_forstmt_data
        json_data['WHILEList'] = json_whilestmt_data
        json_data['DOList'] = json_dostmt_data
        json_data['SWITCHList'] = json_switchstmt_data
        json_data['COMPOUNDList'] = json_compoundstmt_data




def print_node_tree(node, filepath):
    global line, element, json_data, depth, json_func_data #ここでのlineはおそらくコード全体の配列
    if str(node.location.file) == filepath:
        type_name = node.kind.name
        start_line = int(node.extent.start.line)
        start_col = int(node.extent.start.column)
        end_line = int(node.extent.end.line)
        end_col = int(node.extent.end.column)
        print('%s : (%s,%s)<=>(%s,%s)' %
              (type_name, start_line, start_col, end_line, end_col), end='')
        slice_data = data_slice(
            line, start_col, end_col, start_line, end_line)
        print()
        print(slice_data[0])

        if 'BINARY_OPERATOR' in node.kind.name:
            child_num = 0
            for BO_child in node.get_children():
                if(child_num == 0):
                    start_line = BO_child.extent.end.line
                    start_col = BO_child.extent.end.column
                else:
                    end_line = BO_child.extent.start.line
                    end_col = BO_child.extent.start.column
                child_num += 1
            if start_col < end_col or start_line != end_line:
                slice_data = data_slice(
                    line, start_col, end_col, start_line, end_line)
                slice_data[0], start_col, end_col, start_line, end_line =\
                    remove_spaces(slice_data[0], int(start_col) - slice_data[1]-1,
                                  int(end_col)-slice_data[2]-1, start_line, end_line)
                make_jsondata(
                    str(slice_data[0]), start_line, end_line, start_col, end_col)
        elif 'FUNCTION_DECL' in node.kind.name:
            func_tempname = node.displayname
            #関数名から()以降を取り除く
            func_tempname = re.split(r'[(]',func_tempname)
            func_name = func_tempname[0]
            start_col = correct_column(line, start_line)
            end_col = correct_column(line, end_line)
            make_json_func_data(func_name, start_line, end_line, start_col, end_col)


        elif 'IF_STMT' in node.kind.name:
            start_col = correct_column(line, start_line)
            end_col = correct_column(line, end_line)
            make_json_stmt_data(start_line, end_line, start_col, end_col, 0)


        elif 'FOR_STMT' in node.kind.name:

            start_col = correct_column(line, start_line)
            end_col = correct_column(line, end_line)
            make_json_stmt_data(start_line, end_line, start_col, end_col, 1);


        elif 'WHILE_STMT' in node.kind.name:
            start_col = correct_column(line, start_line)
            end_col = correct_column(line, end_line)
            make_json_stmt_data(start_line, end_line, start_col, end_col, 2)

        elif 'DO_STMT' in node.kind.name:
            make_json_stmt_data(start_line, end_line, start_col, end_col, 3)

        elif 'COMPOUND_STMT' in node.kind.name:
            make_json_stmt_data(start_line, end_line, start_col, end_col, 4)

        elif 'SWITCH_STMT' in node.kind.name:
            start_col = correct_column(line, start_line)
            end_col = correct_column(line, end_line)
            make_json_stmt_data(start_line, end_line, start_col, end_col, 5)

    for child in node.get_children():
        print_node_tree(child, filepath)



def json_name(filename):
    orig_name = filename.split('.')
    return orig_name[0]+'.json'


def shaping_cfile(file_path):
    result = subprocess.check_call(['clang-format', '-i', file_path])
    # print(result)
    print("")


def count_depth(jsn):
    if 'child' in jsn:
        return 1 + max([0] + list(map(count_depth, jsn['child'])))
    else:
        return 1


def max_check(AST, max_char):
    i = len(AST)-1
    while(i > -1):
        print(i)
        if(AST[i-1]['start_line'] == AST[i]['start_line']):
            if(AST[i-1]['start_column'] <= AST[i]['start_column'] and AST[i-1]['end_column'] >= AST[i]['end_column']):
                print(AST[i]['data'])
                AST.pop(i)
                if(i != len(AST)):
                    i = i+1
        i = i-1
    return AST


def remove_comment(data, sc, ec, sl, el):
    status = True
    str_status = True
    line_status = True
    BO_data = ''
    length = len(data)
    i = 0
    while i < length:
        if data[i] == "\"":
            if i > 0:
                if data[i-1] != '\\':
                    if str_status:
                        str_status = False
                    else:
                        str_status = True
        if str_status:
            if i < length-1:
                if data[i]+data[i+1] == '/*':
                    status = False
                    i = i + 2
                if not status:
                    if data[i]+data[i+1] == '*/':
                        status = True
                        i = i + 2
                if data[i]+data[i+1] == '//':
                    line_status = False
                    i = i+2
                if not line_status:
                    if data[i] == '\n':
                        line_status = True
                        i = i + 2

        if status and line_status:
            BO_data += data[i]
        i += 1
    return BO_data


def remove_spaces(str, sc, ec, sl, el):
    data = ''
    length = 0
    SlaStatus = False
    AstStatus = False
    Status1 = False
    Status2 = False
    for i in str:
        print(i, Status1, Status2, SlaStatus, AstStatus)

        if category(i) == 'Cc':
            print("Cc")
            sc += 1
            if(i == '\n'):
                sl += 1
                sc = 0
                if Status2:
                    Status2 = False

        elif i == '/':
            if SlaStatus:
                Status2 = True
            else:
                SlaStatus = True
            if AstStatus and SlaStatus:
                Status1 = False
        elif i == '*':
            AstStatus = True
            if AstStatus and SlaStatus:
                Status1 = True

        else:
            if i == " ":
                sc += 1
                print("Space")
            elif not Status1 and not Status2:
                print("pick up")
                data += i
                length += 1
            if SlaStatus and not AstStatus:
                if not Status2:
                    data += '/'
                    length += 1
            if not SlaStatus and AstStatus:
                data += '*'
                length += 1
            AstStatus = False
            SlaStatus = False

    return data, sc, sc+length-1, sl, sl


index = Index.create()
if re.compile(r'.*\.c').search(sys.argv[1]):

    dir_list = str(sys.argv[1]).split('/')
    filename = dir_list[len(dir_list)-1]
    print(filename)

    jsonfile = open('../json/'+json_name(filename), 'w')

    filedata = codecs.open(sys.argv[1], 'r+', "UTF-8")
    contents = filedata.read()

    #  content = re.sub(r'[\t\v\f\r]',' ',contents)
    line = re.split(r'\n', contents)
    print(line)

    shaping_json_data(0)
    tree = index.parse(sys.argv[1])
    print_node_tree(tree.cursor, sys.argv[1])
    shaping_json_data(1)
    shaping_json_data(2)
    shaping_json_data(3)

    #print(pycolor.YELLOW + json_data+pycolor.END)

    BOList = sorted(json_data['BOList'], key=lambda x: (
        x['start_line'], x['start_column']))
    shaping_json_data(4)

    json.dump(json_data, jsonfile, indent=4)

    jsonfile.close()
