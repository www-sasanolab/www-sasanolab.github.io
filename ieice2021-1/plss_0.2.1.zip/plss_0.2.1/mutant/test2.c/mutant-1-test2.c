#include<stdio.h>

int main(void){
    int i, j;
    for(i = 1; i < 5; i++){
        if(i - 2 == 0)
            continue;
        for(j = 1; j <= 5; j++){
            printf("%d ", i * j);
        }
        printf("\n");
    }
    return 0;
}

