PLSS version 0.2.1
(Perturbation-based Learning Support System)

[0.1.0からの変更点]
画像の変更

[0.1.1からの変更点]
〜Teacher〜
・ランダムにミューテーションを行う生成方法を3種類追加
1. M言語による生成: M言語でミューテーション範囲を決めてランダム生成する。M言語はjisonディレクトリのMLanguage_parser.jison参照
2. 条件指定による生成 : M言語を使用せずともテキストやセレクトボックスでM言語による生成と同等な生成ができる。
3. マウスの範囲選択による生成 : マウスカーソルでドラックして範囲を決定しその中でランダム生成を行う。ブラウザはChrome環境で動作

・ソースコードや生成したコードを確認するページにて，コードの標準出力を表示する枠を追加。
・ミューテーションで生成したコードを確認するページにおいて，元のコードと生成されたコードで比較しやすくするため並べるように変更し，
　違いが分かるように変更された二項演算子を赤字で表示する機能を追加。

〜Student〜
・1つのコード中で解答が一度不正解だったとき，問題を再び解く際に答えが確認できるよう「答えを見る」ボタンを追加。ボタンを押すとポップアップに答えが表示される。
・解答が不正解だったときに、ユーザが入力したテキストボックスの内容が消えてしまう状態から、そのまま残るように修正。

[0.2.0からの変更点]
UIや生成機能の修正

MacOS Mojave 10.14.6及びUbuntu18.04.1で動作確認済

[Server側　共通]
・Node.jsライブラリ群(npmでインストール)
http-errors     version 1.7.3
express         version 4.16.4
cookie-parser   version 1.4.4
morgan          version 1.9.1
multer          version 1.4.2
python-shell    version 0.50.0
ejs             version 2.5.9
compile-run     version 2.3.2

・DBServerについて
MySQLを用いたDBServerを使用
testという名前のデータベースを作成
test@localhostよりtestという名前のテーブルを作成
testテーブルのカラムは、
v_id        int
s_id        int
answer      varchar(1024)
correct     boolean
time        int
filename    varchar(30)

ユーザtestにtestテーブルへのアクセス権限を付与する

[Server側　MacOS]
・Clang
MacOS : Apple LLVM version 10.0.1 (clang-1001.0.46.4)

・パッケージ(Homebrew version 2.1.1でインストール)
llvm     version 8.0.1
pip3     version 19.1.1
nodejs   version 8.16.0
npm      version 6.4.1
python   version 3.7.4
mysql    version 8.0.17

サーバーのインストールおよび実行手順(MacOSの場合)
1. 上記のパッケージ及びライブラリをインストール
2. PYTHONPATHに/usr/local/opt/llvm/lib/python2.7/site-packagesを追加
3. LD_LIBRARY_PATHに$(llvm-config --libdir)を追加
4. mysql.serverを起動
5. パスワードが「test」であるユーザー「test」を作成し、このユーザーでテーブル「test」を作成する
    (plss-0.2.1/routes内にあるQuestion.jsの6行目から9行目においてテーブルを指定)
    (ソースコード直書きのため、セキュリティを考慮する場合はユーザ名、パスワードを変更して別の場所においてください)
6. plss-0.2.1ディレクトリにおいて上記のNode.jsライブラリ群をインストール
    (例) npm install http-errors
7. plss-0.2.1/bin/においてwwwをnodejsで実行(ポート番号3000でWebサーバーが起動。wwwの14行目においてポート番号3000を指定。)
    (例) node www

[Server側　Ubuntu]
・Clang
Ubuntu : clang version 6.0.0-1ubuntu2 (tags/RELEASE_600/final)

・パッケージ(apt version 1.6.12でインストール)
llvm     version 6.0.0
pip3	 version 9.0.1
nodejs	 version 8.10.0
npm	 version 3.5.2
python	 version 3.6.8
mysql	 version 14.14

・pip3ライブラリ群(Ubuntuで動作させる際に必要)
clang		version 6.0.0.2

サーバーのインストールおよび実行手順(Ubuntuの場合)
1. 上記のパッケージ及びライブラリのインストール
2. LD_LIBRARY_PATHに$(llvm-config --libdir)を追加
3. mysql.serverを起動
4. パスワードが「test」であるユーザー「test」を作成し、このユーザーでテーブル「test」を作成する
    (plss-0.2.1/routes内にあるQuestion.jsの6行目から9行目においてテーブルを指定)
    (ソースコード直書きのため、セキュリティを考慮する場合はユーザ名、パスワードを変更して別の場所においてください)
5. plss-0.2.1ディレクトリにおいて上記のNodejsライブラリ群をインストール
    (例) npm install http-errors
6. plss-0.2.1/bin/においてwwwをnodejsで実行(ポート番号3000でWebサーバーが起動。wwwの14行目においてポート番号3000を指定。)
    (例) node www

[Client側]
実行方法
ブラウザにおいてURLに以下を指定してアクセス
http://<IPアドレス>:3000/
あるいは
http://<ホスト名>:3000/
※Chrome、Safari、Firefoxにて動作確認済み(マウスの範囲選択による生成の関係上Chrome推奨)

[開発者] 吉塚 大浩
[連絡先] ma19092@shibaura-it.ac.jp
[リリース日] 2019年9月27日
[0.2.1更新者]　亀井 亮汰
[連絡先] ma19018@shibaura-it.ac.jp
[0.2.1更新日] 2021年3月16日

