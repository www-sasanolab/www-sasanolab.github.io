/*jisonパッケージをインストールし，'jison MLanguage_parser.jison'でjsファイル作成可能*/
/* lexical grammar */

%lex
%%
"function"                  return 'FUNCTION'
"stmt"                      return 'STMT'
"stmt_elem"                 return 'STMT_ELEM'
"operator_type"             return 'OPERATOR_TYPE'
"assign_num"                return 'ASSIGN_NUM'
"generation_num"            return 'GENERATION_NUM'
"mutant_num"                return 'MUTANT_NUM'
"if"                        return 'IF'
"else"                      return 'ELSE'
"for"                       return 'FOR'
"while"                     return 'WHILE'
"do"                        return 'DO'
"switch"                    return 'SWITCH'
"main"                      return 'MAIN'
"binary"                    return 'BINARY'  /* Binary operator */
"unary"                     return 'UNARY'  /* Unary operator */
"paren"                     return 'PAREN' /* 条件式or関数 */
"body"                      return 'BODY' /*　条件式or関数の中身 */
"data_type"                 return 'DATA_TYPE'
"min"                       return 'MIN'
"max"                       return 'MAX'
"int"                       return 'INT'
"double"                    return 'DOUBLE'
"/"                         return '/'
"["                         return '['
"]"                         return ']'
";"                         return 'SEMICOLON'
"'"                         return 'APOSTROPHE'
"="                         return '='
\"[^"]+\"         yytext = yytext.slice(1,-1); return 'STRING' /* yytextを挟まないと後ろの「"」を認識しない */
[0-9]+("."[0-9]+)?\b        return 'NUMBER' /*[] -> 省略可, + -> 1回以上繰り返す
\s+                 /* skip whitespace */
"/n"                        return 'LF'
<<EOF>>                     return 'EOF'

/lex

%% /* language grammar */

input
            : mutationSyntax EOF  {$$ = "{ " +$1 + " }"; return $$;}
            ;

mutationSyntax
            : mutationStatement
            | mutationSyntax mutationStatement {$$= $1 + ", " + $2;}
            ;

mutationStatement
            : selectFunction   {$$ = "'function': " +  $1  ; }
            | selectStmt   {$$ = "'statement': " +  $1  ; }
            | selectStmtElement  {$$ = "'stmt_element': " +  $1; }
            | selectOperatorType  {$$= "'opetator_type': " +  $1; }
            | selectGenerationNumber  {$$= "'generation_number': " +  $1; }
            | selectMutantNumber  {$$= "'mutant_number': " +  $1; }
            ;

selectFunction
            : FUNCTION functionList SEMICOLON {$$ = $2;}
            ;

selectStmt
            : STMT stmtNesting SEMICOLON {$$ = "'" + $2 + "'";}
            ;

stmtNesting
            : stmtList
            | stmtNesting "/" stmtList  {$$ =  $1 + "/" + $3 ;}
            ;

selectStmtElement
            : STMT_ELEM PAREN SEMICOLON{$$ = "'parenthesis'";}
            | STMT_ELEM BODY SEMICOLON{$$ = "'body'";}
            ;

selectOperatorType
            : OPERATOR_TYPE operatorList SEMICOLON{$$ = $2;}
            ;

selectGenerationNumber
            : GENERATION_NUM NUMBER SEMICOLON{$$ = $2;}
            ;

selectMutantNumber
            : MUTANT_NUM NUMBER SEMICOLON{$$ = $2;}
            ;

assign_number
            : ASSIGN_NUM assign_number_struct {$$= "'"  + $1 + "'" + ": " + $2;}
            ;

assign_number_struct
            : "[" assign_number_member_list "]" {$$="{" + $2 + "}";}
            ;

assign_number_member_list
            : assign_number_member
            | assign_number_member_list assign_number_member {$$= $1 + ", " + $2;}
            ;

functionList
            : MAIN {$$ = "'main'";}
            | STRING {$$ = "'" + $1 + "'";} /*関数名として指定，入力時には""をつける */
            ;

stmtList
            : FOR {$$ = "for";}
            | WHILE {$$ = "while";}
            | IF {$$ = "if";}
            | ELSE {$$ = "else";}
            | DO {$$ = "do";}
            | SWITCH {$$ = "switch";}
            ;


operatorList
            : BINARY {$$ = "'BINARY_OPERATOR'"}
            | UNARY {$$ = "'UNARY_OPERATOR'"}
            ;

assign_number_member
            : DATA_TYPE dataTypeList SEMICOLON {$$ = $1 + ": " + $2;}
            | MIN  NUMBER SEMICOLON {$$ = "'" + $1 + "'" + ": " + $2;}
            | MAX  NUMBER SEMICOLON {$$ = "'" + $1 + "'" + ": " + $2;}
            ;

dataTypeList
            :INT {$$ = "'int'";}
            |DOUBLE {$$ = "'double'";}
            ;
