#include<stdio.h>
int main(void){
    int a = 0;
    if(a < 1)
        a = a + 2;
    printf("a=%d", a);
    return 0;
}
