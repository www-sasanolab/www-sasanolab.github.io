var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var multer = require('multer');
var bodyParser = require('body-parser');

var indexRouter = require('./routes/index');
var TMenuRouter = require('./routes/TeaMenu');
var SMenuRouter = require('./routes/StuMenu');
var UCRouter = require('./routes/UploadCfile');
var LRouter = require('./routes/list');
var MRouter = require('./routes/make');
var CRouter = require('./routes/contents');
var QRouter = require('./routes/Question');
var MLRouter = require('./routes/MLanguage');
var MCRouter = require('./routes/MCondition');
var MRRouter = require('./routes/MRange');
var MMenuRouter  = require('./routes/MutationMenu');
var McontentsRouter = require('./routes/Mcontents');
//var MLErrRouter = require('./routes/MLErr');
//var SummaryRouter = require('./routes/Summary');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use('/', indexRouter);
app.use('/TeaMenu', TMenuRouter);
app.use('/StuMenu', SMenuRouter);
app.use('/UploadCfile', UCRouter);
app.use('/list', LRouter);
app.use('/make', MRouter);
app.use('/contents', CRouter);
app.use('/Question', QRouter);
app.use('/MLanguage', MLRouter);
app.use('/MRange', MRRouter);
app.use('/MCondition', MCRouter);
app.use('/MutationMenu', MMenuRouter);
app.use('/Mcontents', McontentsRouter);



//app.use('/MLErr', MLErrRouter);


// catch 404 and forward to error handler
/*
app.use(function (err, req, res, next) {
  if(err.statusCode == 400) {
    next(createError(400));
  }
  else {
    next(createError(404));
  }
});
*/
// error handler

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
