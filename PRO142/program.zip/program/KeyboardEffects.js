const key_list = [
    '1'  , '2', '3', '4', '5', '6', '7', '8', '9', '0', '-' , '^', //'\xA5',
    '\\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p' , '@', '[' , 
    'a'  , 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', ':' , ']', 
    'z'  , 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', '\\', ' '
];
const key_array = [
    ['1', 1, 2]  , ['2', 1, 3], ['3', 1, 4], ['4', 1, 5], ['5', 1, 6], ['6', 1, 7], ['7', 1, 8], ['8', 1, 9] , ['9', 1, 10], ['0', 1, 11], ['-', 1, 12] , ['^', 1, 13] , //['\\', 1, 14], // 1:E/J
    ['\\t', 2, 1], ['q', 2, 2], ['w', 2, 3], ['e', 2, 4], ['r', 2, 5], ['t', 2, 6], ['y', 2, 7], ['u', 2, 8] , ['i', 2, 9] , ['o', 2, 10], ['p', 2, 11] , ['@', 2, 12] , ['[', 2, 13]  , // 14:Enter
    ['a', 3, 2]  , ['s', 3, 3], ['d', 3, 4], ['f', 3, 5], ['g', 3, 6], ['h', 3, 7], ['j', 3, 8], ['k', 3, 9] , ['l', 3, 10], [';', 3, 11], [':', 3, 12] , [']', 3, 13] , //['\\n', 3, 14], // 1:CapsLock
    ['z', 4, 3]  , ['x', 4, 4], ['c', 4, 5], ['v', 4, 6], ['b', 4, 7], ['n', 4, 8], ['m', 4, 9], [',', 4, 10], ['.', 4, 11], ['/', 4, 12], ['\\', 4, 13], // 1:lShift, 2:none, 14:rShift
    [' ', 5, 7]  // key[5][7]:space
];
const num       = ["1", "2" , "3", "4", "5", "6", "7" , "8", "9"];
const num_shift = ["!", "\"", "#", "$", "%", "&", "\'", "(", ")"];
const unn_shift = ["-", "^" , "" , "@", "[", ";", ":" , "]", ",", ".", "/", "\\"];
const nes_shift = ["=", "~" , "|", "`", "{", "+", "*" , "}", "<", ">", "?", "_" ];

var color = new Array(6);
var key = new Array(6);
var lines = new Array();
var line = 0;
var pos = 0;
var sampleCode;
var stat = 0;
var backup_program = "";
var backup_stat = 0;
var tabCount = 0;

function InputProcess(input) {
    if (stat == 0) {
        alert("入力すべき文字がありません．\n［ファイルを選択］からファイルを選択するか，選択済みの場合は［はじめから］をクリックしてください．");
    } else if (stat == 1) {
        if (input == lines[line][pos]) {
            KeyboardClear();
            WriteProgram(lines[line][pos]);
            if (pos < lines[line].length-1) {
                ++pos;
            } else if (line < lines.length) {
                ++line;
                pos = 0;
                stat = 4;
                EnterEffects();
                return;
            }
            KeyboardEffects(lines[line][pos]);
        } else {
            MissEffects(input);
        }
    } else if (stat != 3) {
        MissEffects(input);
    }
}

function TabProcess() {
    if (stat == 0) {
        alert("入力すべき文字がありません．\n［ファイルを選択］からファイルを選択するか，選択済みの場合は［はじめから］をクリックしてください．");
    } else if (stat == 2) {
        KeyboardClear();
        WriteProgram("\t");
        if (--tabCount == 0) {
            KeyboardEffects(lines[line][pos]);
        } else {
            TabEffects();
        }
    } else if (stat != 3) {
        MissEffects("\t");
    }
}

function MissProcess() {
    if (stat == 0) {
        alert("入力すべき文字がありません．\n［ファイルを選択］からファイルを選択するか，選択済みの場合は［はじめから］をクリックしてください．");
    } else if (stat == 3) {
        KeyboardClear();
        document.getElementById('program').value = backup_program;
        document.getElementById('program').style.backgroundColor = 'white';
        if (backup_stat == 1) {
            KeyboardEffects(lines[line][pos]);
        } else if (backup_stat == 2) {
            TabEffects();
        } else if (backup_stat == 4) {
            EnterEffects();
        }
    } else {
        // 
    }
}

function EnterProcess() {
    if (stat == 0) {
        alert("入力すべき文字がありません．\n［ファイルを選択］からファイルを選択するか，選択済みの場合は［はじめから］をクリックしてください．");
    } else if (stat == 4) {
        KeyboardClear();
        if (document.getElementById('program').value.slice(0, -1) == document.getElementById('sample').value) {
            Output();
            return;
        }
        WriteProgram("\n");
        if (document.getElementById('program').value.slice(0, -1) == document.getElementById('sample').value) {
            Output();
            return;
        }
        LineProcess();
    } else if (stat != 3) {
        MissEffects("\n");
    }
}

function LineProcess() {
    var tabArray = lines[line].split('\t');
    tabCount = 0;
    for (i=0; i<tabArray.length; ++i) {
        if (tabArray[i] == "") {
            ++tabCount;
        } else {
            lines[line] = tabArray[i];
        }
    }
    if (tabCount > 0) TabEffects();
    else KeyboardEffects(lines[line][pos]);
}

function KeyboardEffects(ch) {
    var lightUp = new Array();
    init();
    lightUp = translate(ch);
    for (r=0; r<lightUp.length; ++r) {
        key[lightUp[r][0]][lightUp[r][1]] = 0x01000000 | 0xff00ff;
    }
    stat = 1;
    CreateEffect();
}

function TabEffects() {
    init();
    key[2][1] = 0x01000000 | 0xff00ff;
    stat = 2;
    CreateEffect();
}

function MissEffects(input) {
    backup_program = document.getElementById('program').value;
    backup_stat = stat;
    WriteProgram(input);
    document.getElementById('program').style.backgroundColor = 'lightcoral';
    init();
    key[1][15] = 0x01000000 | 0xff00ff;
    stat = 3;
    CreateEffect();
}

function EnterEffects() {
    init();
    key[3][14] = 0x01000000 | 0xff00ff;
    stat = 4;
    CreateEffect();
}

function KeyboardClear() {
    init();
    CreateEffect();
}

function WriteProgram(ch) {
    var program = document.getElementById('program').value;
    document.getElementById('program').value = program.slice(0, -1) + ch + "|";
}

function translate(ch) {
    var lightUp = new Array();
    var index;
    if (key_list.includes(ch) == true) { // shift不要
        index = key_list.indexOf(ch);
    } else { // shift必要
        lightUp.push([4, 1]); // lshift
        lightUp.push([4, 14]); // rshift
        if (ch.match(/^[A-Z]+$/)) { // 大文字アルファベット
            index = key_list.indexOf(ch.toLowerCase());
        } else if (num_shift.includes(ch) == true) { // 数字+shift
            index = num_shift.indexOf(ch);
            index = key_list.indexOf(num[index]);
        } else if (nes_shift.includes(ch) == true) { // 記号+shift
            index = nes_shift.indexOf(ch);
            index = key_list.indexOf(unn_shift[index]);
        }
    }
    lightUp.push([key_array[index][1], key_array[index][2]]);
    return lightUp;
}

function InitTextarea(sample) {
    sampleCode = sample.replace(/    /g, "\t");
    document.getElementById('sample').value = sampleCode;
    document.getElementById('program').value = "";
    LightUp();
}

function init() {
    for (r = 0; r < 6; r++) {
        color[r] = new Array(22);
        for (c = 0; c < 22; c++) {
            color[r][c] = 0;
        }
   }
   for (r = 0; r < 6; r++) {
        key[r] = new Array(22);
        for (c = 0; c < 22; c++) {
            key[r][c] = 0;
        }
    }
}

function CreateEffect() {
    var data = { 'color': color, 'key': key };
    chromaSDK.createKeyboardEffect("CHROMA_CUSTOM_KEY", data);
}

function LightUp() {
    if (lines[0] == '' && lines.length <= 1) {
        alert('サンプルコードが入力されていません．\nサンプルコードを入力してからボタンをクリックしてください．');
    } else {
        line = 0;
        pos = 0;
        document.getElementById('program').style.backgroundColor = 'white';
        document.getElementById('sample').style.backgroundColor = 'white';
        lines = new Array();
        lines = sampleCode.split(/\r\n|\n/);
        document.getElementById('program').value = "|";
        document.activeElement.blur();
        KeyboardEffects(lines[line][pos]);
    }
}

function Output() {
    document.getElementById('program').value = document.getElementById('program').value.slice(0, -1);
    document.getElementById('program').style.backgroundColor = 'lightgreen';
    document.getElementById('sample').style.backgroundColor = 'lightgreen';
    if (confirm("プログラムの写経が完了しました．\n写経したプログラムをファイルに書き出して保存しますか？")) {
        const blob = new Blob([document.getElementById('program').value],{type:"text/plain"});
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'download.c';
        link.click();
    }
    stat = 0;
}