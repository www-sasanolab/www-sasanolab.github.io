#ifndef OBJECTDB_H_
#define OBJECTDB_H_

#include <memory>
#include <string>
#include <unordered_map>

struct Color {
    float R, G, B, A;
    Color() = default;
    Color(float _R = 0.0, float _G = 0.0, float _B = 0.0, float _A = 0.0) : R(_R), G(_G), B(_B), A(_A) {}
    static Color getdefaultColor();
};

enum class ShapeType { Shape, Rect, Circle };

struct Shape {
    virtual ShapeType getShapeType();
};

struct Rect : public Shape {
    float W, H;
    Color c;
    Rect() = default;
    Rect(float _W = 20.0, float _H = 20.0, Color _c = Color::getdefaultColor()) : W(_W), H(_H), c(_c) {}
    ShapeType getShapeType() override;
};

struct Circle : public Shape {
    float R;
    Color c;
    Circle(float _R = 20.0, Color _c = Color::getdefaultColor()) : R(_R), c(_c) {}
    Circle(const Circle &) = default;
    ShapeType getShapeType() override;
};

struct ObjectDB {
    std::unordered_map<std::string, std::shared_ptr<Shape>> shapes;
    ObjectDB() = default;
    ~ObjectDB() = default;

    void pushShape(std::string name, std::shared_ptr<Shape> shape);
    std::shared_ptr<Shape> getShape(std::string name);
    void eraseData();

private:
};

#endif
