#ifndef PROGRAM_H_
#define PROGRAM_H_

#include <Windows.h>
#include <gl/gl.h>


extern int finish;
extern HDC hDC;
extern HGLRC hRC;

#endif