#ifndef DRWER_H_
#define DRWER_H_

#define _USE_MATH_DEFINES
#include <memory>
#include "objectdb.h"

struct Drawer {
    static void Reset(Color c);
    static void Wait(int count);
    static void DrawRect(std::shared_ptr<Rect> r, float x, float y);
    static void DrawCircle(std::shared_ptr<Circle> c, float ox, float oy);
    static void Flush();
};

#endif