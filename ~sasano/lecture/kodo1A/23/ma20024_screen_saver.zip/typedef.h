#ifndef TYPEDEF_H_
#define TYPEDEF_H_
#include <string>
#include <unordered_map>

using VariableDB = std::unordered_map<std::string, float>;

#endif