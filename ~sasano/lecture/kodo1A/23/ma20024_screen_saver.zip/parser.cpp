#include "parser.h"
#include <Windows.h>
#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include "arithmetic.h"
#include "drawer.h"
#include "objectdb.h"
#include "program.h"
#include "typedef.h"
#include "util.h"

std::vector<float> Parser::calcParams(std::vector<std::string> rawParams, const std::shared_ptr<VariableDB>& values) {
    std::vector<float> params = {};
    for (auto rawParam : rawParams) { params.push_back(Arithmetic::Parse(rawParam, values)); }
    return params;
}

std::shared_ptr<Circle> Parser::createCircle(std::vector<float> params) {
    auto c = Color(params.at(1), params.at(2), params.at(3));
    return std::make_shared<Circle>(Circle(params.at(0), c));
}
std::shared_ptr<Rect> Parser::createRect(std::vector<float> params) {
    auto c = Color(params.at(2), params.at(3), params.at(4));
    return std::make_shared<Rect>(Rect(params.at(0), params.at(1), c));
}

void Parser::Let(std::vector<std::string> v, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values) {
    auto type = v.at(0).replace(0, 1, "");
    if (type == "Circle") {
        auto params = calcParams(split(v.at(2), ','), values);
        db->pushShape(v.at(1), createCircle(params));
    } else if (type == "Rect") {
        auto params = calcParams(split(v.at(2), ','), values);
        db->pushShape(v.at(1), createRect(params));
    } else if (type == "Number") {
        auto params = calcParams(std::vector<std::string>({ v.at(2) }), values);
        if (!values.get()->insert({ v.at(1), params.at(0) }).second) { values.get()->at(v.at(1)) = params.at(0); }
    } else {
        std::cout << "non supported type" << std::endl;
    }
}

void Parser::Eval(std::vector<std::string> v, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values) {
    auto func = v.at(0);
    if (func == "Reset") {
        auto params = calcParams(split(v.at(1), ','), values);
        Drawer::Reset(Color(params.at(0), params.at(1), params.at(2)));
    } else if (func == "Sleep") {
        auto params = calcParams(split(v.at(1), ','), values);
        Drawer::Wait(params.at(0));
    } else if (func == "Draw") {
        auto rawParams = split(v.at(1), ',');
        auto name = rawParams.at(0);
        rawParams.erase(rawParams.begin());
        auto params = calcParams(rawParams, values);
        auto shape = db->getShape(name);
        switch (shape->getShapeType()) {
            case ShapeType::Circle: {
                Drawer::DrawCircle(std::static_pointer_cast<Circle>(shape), params.at(0), params.at(1));
                break;
            }
            case ShapeType::Rect: {
                Drawer::DrawRect(std::static_pointer_cast<Rect>(shape), params.at(0), params.at(1));
                break;
            }
            default: {}
        }
    } else if (func == "Flush") {
        Drawer::Flush();
    }
}

void Parser::Parse(std::vector<std::string> lines, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values) {
    while (1) {
        std::string line;
        for (auto itr = lines.begin(); itr != lines.end(); ++itr) {
            try {
                line = *itr;
                if (finish) return;
                if (line.empty() || line.find("//") == 0) continue;
                auto v = split(line, ':');
                if (line.front() == '@') {
                    Let(v, db, values);
                } else if (v.at(0) == "Loop") {
                    std::vector<std::string> newlines(itr + 1, lines.end());
                    return Parse(newlines, db, values);
                } else {
                    Eval(v, db, values);
                }
            } catch (std::exception& e) {
                std::cout << line << std::endl << "error" << e.what() << std::endl;
                return;
            }
        }
    }
}

void Parser::Run(std::string code) {
    auto db = std::make_shared<ObjectDB>(ObjectDB());
    auto numberdb = std::make_shared<VariableDB>();
    return Parse(split(code, '\n'), db, numberdb);
}
