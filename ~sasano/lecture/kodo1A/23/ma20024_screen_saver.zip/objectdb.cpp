#include "objectdb.h"
#include <memory>
#include <string>
#include <unordered_map>

Color Color::getdefaultColor() {
    return Color(0, 0, 0);
}

ShapeType Shape::getShapeType() {
    return ShapeType::Shape;
}

ShapeType Circle::getShapeType() {
    return ShapeType::Circle;
}

ShapeType Rect::getShapeType() {
    return ShapeType::Rect;
}

void ObjectDB::pushShape(std::string name, std::shared_ptr<Shape> shape) {
    shapes.insert({ name, shape });
}

std::shared_ptr<Shape> ObjectDB::getShape(std::string name) {
    return shapes.at(name);
}

void ObjectDB::eraseData() {
    shapes.clear();
}