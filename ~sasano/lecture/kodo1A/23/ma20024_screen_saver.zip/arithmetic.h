#ifndef ARITHMETIC_H_
#define ARITHMETIC_H_
#include <array>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include "typedef.h"

using Result = std::pair<float, unsigned int>;
static constexpr float pi = 3.141592653589793;

class Arithmetic {
    static std::unordered_map<std::string, std::function<float(float)>> functions;
    static std::vector<char> symbols;
    static VariableDB consts;
    static Result expr(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result term(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result factor(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result value(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result number(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result variable(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);
    static Result func(std::string source, unsigned int i, const std::shared_ptr<VariableDB>& values);

public:
    static float Parse(std::string source, const std::shared_ptr<VariableDB>& values);
};

#endif