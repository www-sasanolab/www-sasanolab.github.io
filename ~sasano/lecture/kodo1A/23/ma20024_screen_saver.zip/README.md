# WSSI

Windows用スクリーンセーバーインタープリター
