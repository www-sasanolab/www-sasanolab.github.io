
#ifndef PARSER_H_
#define PARSER_H_

#include <memory>
#include <string>
#include <vector>
#include "objectdb.h"
#include "typedef.h"

class Parser {
    static std::vector<float> calcParams(std::vector<std::string> rawParams, const std::shared_ptr<VariableDB>& values);
    static std::shared_ptr<Circle> createCircle(std::vector<float> params);
    static std::shared_ptr<Rect> createRect(std::vector<float> params);
    static void Eval(std::vector<std::string> v, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values);
    static void Let(std::vector<std::string> v, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values);
    static void Parse(std::vector<std::string> lines, std::shared_ptr<ObjectDB> db, std::shared_ptr<VariableDB> values);

public:
    static void Run(std::string code);
};

#endif