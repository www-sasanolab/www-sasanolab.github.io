#include "program.h"
#include <gl/gl.h>
#include <process.h>
#include <regstr.h>
#include <stdio.h>
#include <windows.h>
#include <fstream>
#include <string>
#include "parser.h"
#include "scrnsave.h"

void EnableOpenGL(void);   // prototype宣言
void DisableOpenGL(HWND);  // prototype宣言
HDC hDC;
HGLRC hRC;
int wx, wy;     // displayの横と縦のpixel数格納用変数
int finish = 0; /* 生成したスレッドを終了させるかどうかを最初のスレッド
                   から通知するための変数。0なら終了しない、1なら終了 */

void init() {
    EnableOpenGL();  // OpenGL設定
    /* OpenGL初期設定 */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-50.0 * wx / wy, 50.0 * wx / wy, -50.0, 50.0, -50.0, 50.0);  // 座標系設定
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

unsigned __stdcall disp(void *arg) {
    init();
    glViewport(0, 0, wx, wy);
    /* ここまで */

    std::ifstream ifs("prog");
    std::string str;
    std::string code;
    while (std::getline(ifs, str)) { code.append(str + '\n'); }
    ifs.close();
    Parser::Run(code);
    return 0;
}

LRESULT WINAPI ScreenSaverProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static HANDLE thread_id1;
    RECT rc;
    switch (msg) {
        case WM_CREATE:
            hDC = GetDC(hWnd);        // ウィンドウハンドルhWndからデバイスコンテクストを取得
            GetClientRect(hWnd, &rc); /* hWndのウィンドウの左上と右下の座標を
                                         構造体rcに格納する。*/
            wx = rc.right - rc.left;  /* GetClientRectで取得した左上、右下の座標を使って
                                        displayの横のpixel数を計算 */
            wy = rc.bottom - rc.top;  /* GetClientRectで取得した左上、右下の座標を使って
                                        displayの縦のpixel数を計算 */

            thread_id1 = (HANDLE)_beginthreadex(NULL, 0, disp, NULL, 0, NULL);  // 描画用スレッド生成
            if (thread_id1 == 0) {  // スレッド生成に失敗したらスクリーンセーバを終了
                fprintf(stderr, "pthread_create : %s", strerror(errno));
                exit(0);
            }
            break;
        case WM_ERASEBKGND:
            return TRUE;
        case WM_DESTROY:                                // マウスやキーボードの入力があるとここに来る
            finish = 1;                                 // 描画スレッドを終了させるために1を代入
            WaitForSingleObject(thread_id1, INFINITE);  // 描画スレッドの終了を待つ
            CloseHandle(thread_id1);                    // 生成したスレッドを閉じる
            DisableOpenGL(hWnd);
            PostQuitMessage(0); /* 自分のスレッド（メインスレッド）を終了していいことを
                                   自分のメッセージキューに入れる。 */
            return 0;
        case WM_CLOSE: {                              // Windows Aeroが有効かどうかを判定
            HMODULE dwm = LoadLibrary("dwmapi.dll");  // dwmapi.dllの動的ロード
            if (dwm) {
                typedef HRESULT(WINAPI * proc_type)(BOOL *);
                proc_type DwmIsCompositionEnabled =
                        (proc_type)GetProcAddress(dwm,
                                                  "DwmIsCompositionEnabled");  // DwmIsCompositionEnabled関数のアドレスを取得
                if (DwmIsCompositionEnabled) {
                    BOOL enable;
                    HRESULT hr = DwmIsCompositionEnabled(&enable);
                    FreeLibrary(dwm);
                    if (SUCCEEDED(hr) && enable == TRUE)  // enabled == TRUEの時，DWMが有効(Windows Aeroを使用している)
                        break;                            //使ってたらこのWorkaroundは不要なので抜ける
                }
            }
        }
            // Workaround: Windowサイズを一度変更するとブラックアウト問題を回避できる
            GetWindowRect(hWnd, &rc);
            SetWindowPos(hWnd, 0, rc.left, rc.top, 1, 1, SWP_NOZORDER);
            SetWindowPos(hWnd, 0, rc.left, rc.top, rc.right, rc.bottom, SWP_NOZORDER);
            break;
        default:  // 上記以外のメッセージの場合はswitch文を終了。（これは書かなくても同じだが。）
            break;
    }
    return DefScreenSaverProc(hWnd, msg, wParam, lParam); /* 上のswitch文で処理していない
                                                             メッセージを処理してからreturn。*/
}

/* https://msdn.microsoft.com/ja-jp/library/cc422062.aspx 参照 */
BOOL WINAPI ScreenSaverConfigureDialog(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam) {
    return TRUE;
}

/* https://msdn.microsoft.com/ja-jp/library/cc422061.aspx 参照 */
BOOL WINAPI RegisterDialogClasses(HANDLE hInst) {
    return TRUE;
}

void EnableOpenGL(void) {
    int format;
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd368826(v=vs.85).aspx
       を参照 */
    PIXELFORMATDESCRIPTOR pfd = {
        sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
        1,                              // version number
        0 | PFD_DRAW_TO_WINDOW          // support window
                | PFD_SUPPORT_OPENGL    // support OpenGL
                | PFD_DOUBLEBUFFER      /* double buffered
                                 (front bufferとback bufferの2枚使う) */
        ,
        PFD_TYPE_RGBA,  // RGBA type
        24,             // 24-bit color depth
        0,
        0,
        0,
        0,
        0,
        0,  // color bits ignored
        0,  // no alpha buffer
        0,  // shift bit ignored
        0,  // no accumulation buffer
        0,
        0,
        0,
        0,               // accum bits ignored
        32,              // 32-bit z-buffer
        0,               // no stencil buffer
        0,               // no auxiliary buffer
        PFD_MAIN_PLANE,  // main layer
        0,               // reserved
        0,
        0,
        0  // layer masks ignored
    };

    /* OpenGL設定 */
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd318284(v=vs.85).aspx 参照 */
    format = ChoosePixelFormat(hDC, &pfd);
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd369049(v=vs.85).aspx 参照 */
    SetPixelFormat(hDC, format, &pfd);
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd374379(v=vs.85).aspx 参照 */
    hRC = wglCreateContext(hDC);
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd374387(v=vs.85).aspx 参照 */
    wglMakeCurrent(hDC, hRC);
    /* ここまで */
}

void DisableOpenGL(HWND hWnd) {
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd374387(v=vs.85).aspx 参照 */
    wglMakeCurrent(NULL, NULL);
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd374381(v=vs.85).aspx 参照 */
    wglDeleteContext(hRC);
    /* https://msdn.microsoft.com/en-us/library/windows/desktop/dd162920(v=vs.85).aspx 参照 */
    ReleaseDC(hWnd, hDC);
}
