#include "arithmetic.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <iostream>
#include "program.h"

/*
- <expr>   ::= <term> [ ('+'|'-') <term> ]*
- <term>   ::= <factor> [ ('*'|'/'|'%') <factor> ]*
- <factor> ::= '(' <expr> ')' | <value>
- <value> ::= <number> | <variable> | <func>
- <number> ::= (0|1|2|3|4|5|6|7|8|9)+
- <variable>  ::= '@' (a-Z)+
- <func>   ::= 'sin(' <expr> ')' | 'cos('  <expr> ')'
*/

std::unordered_map<std::string, std::function<float(float)>> Arithmetic::functions = { { "sin", [](float v) { return std::sin(v); } },
                                                                                       { "cos", [](float v) { return std::cos(v); } } };

VariableDB Arithmetic::consts = { { "PI", pi } };
std::vector<char> Arithmetic::symbols = { '+', '-', '*', '/', '%', '(', ')', '@', '#' };

Result Arithmetic::expr(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    auto left = term(s, i, values);
    while (true) {
        const auto op = s[left.second];
        if ('+' == op) {
            const auto right = term(s, left.second + 1, values);
            left.first = left.first + right.first;
            left.second = right.second;
        } else if ('-' == op) {
            const auto right = term(s, left.second + 1, values);
            left.first = left.first - right.first;
            left.second = right.second;
        } else {
            break;
        }
    }
    return left;
}

Result Arithmetic::term(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    auto left = factor(s, i, values);
    while (true) {
        const auto op = s[left.second];
        if ('*' == op) {
            const auto right = factor(s, left.second + 1, values);
            left.first = left.first * right.first;
            left.second = right.second;
        } else if ('/' == op) {
            const auto right = factor(s, left.second + 1, values);
            left.first = left.first / right.first;
            left.second = right.second;
        } else if ('%' == op) {
            const auto right = factor(s, left.second + 1, values);
            left.first = (int)left.first % (int)right.first;
            left.second = right.second;
        } else {
            break;
        }
    }
    return left;
}

Result Arithmetic::factor(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    if ('(' == s[i]) {
        i++;  // '('の分
        const auto value = expr(s, i, values);
        return Result(value.first, value.second + 1);
    } else {
        return value(s, i, values);
    }
}

Result Arithmetic::value(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    if ('@' == s[i]) {
        i++;
        return variable(s, i, values);
    } else if ('#' == s[i]) {
        i++;
        return func(s, i, values);
    } else if ('0' <= s[i] && s[i] <= '9') {
        return number(s, i, values);
    } else {
        throw std::invalid_argument("unexpected token");
    }
}

Result Arithmetic::number(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    std::string num;
    while (('0' <= s[i] && s[i] <= '9') || '.' == s[i]) {
        num.push_back(s[i]);
        i++;
    }
    return Result(std::stof(num), i);
}

Result Arithmetic::variable(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    std::string name;
    while (std::find(symbols.begin(), symbols.end(), s[i]) == symbols.end() && i != s.size()) {
        name.push_back(s[i]);
        i++;
    }
    if (values.get()->count(name) != 0) {
        return Result(values.get()->at(name), i);
    } else {
        throw std::invalid_argument("undefined values");
    }
}

Result Arithmetic::func(std::string s, unsigned int i, const std::shared_ptr<VariableDB>& values) {
    for (auto func : functions) {
        if (s.find(func.first, i) == i) {
            i += func.first.size();
            if ('(' == s[i]) {
                i++;
                const auto param = expr(s, i, values);
                const auto result = func.second(param.first);
                return Result(result, param.second + 1);
            } else {
                throw std::invalid_argument("unexpected token");
            }
        }
    }
    throw std::invalid_argument("undefined values");
}
float Arithmetic::Parse(std::string s, const std::shared_ptr<VariableDB>& values) {
    values.get()->insert(consts.begin(), consts.end());
    s.erase(std::remove_if(s.begin(), s.end(), ([](char c) { return c == ' '; })), s.end());
    return expr(s, 0, values).first;
}