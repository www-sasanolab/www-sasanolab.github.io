#define _USE_MATH_DEFINES
#include "drawer.h"
#include <Windows.h>
#include <gl/gl.h>
#include <cmath>
#include <iostream>
#include "objectdb.h"
#include "program.h"

void Drawer::Flush() {
    glFlush();
    SwapBuffers(hDC);
}

void Drawer::Reset(Color c) {
    glClearColor(c.R / 256.0f, c.B / 256.0f, c.G / 256.0f, c.A / 256.0f);
    glClear(GL_COLOR_BUFFER_BIT);
}

void Drawer::Wait(int count) {
    Sleep(count);
}

void Drawer::DrawRect(std::shared_ptr<Rect> r, float x, float y) {
    glColor3f((float)r->c.R / 256.0f, r->c.B / 256.0f, r->c.G / 256.0f);
    glRectf(x - r->W / 2, y - r->H / 2, x + r->W / 2, y + r->H / 2);
}

void Drawer::DrawCircle(std::shared_ptr<Circle> c, float ox, float oy) {
    float x, y;
    glColor3f(c->c.R / 256.0f, c->c.B / 256.0f, c->c.G / 256.0f);
    glBegin(GL_POLYGON);
    for (float t = 0.0f; t <= 360.0; t += 1.0) {
        x = c->R * cos(2.0 * M_PI * ((double)t / 360.0)) + ox;
        y = c->R * sin(2.0 * M_PI * ((double)t / 360.0)) + oy;
        glVertex3f(x, y, 0.0);
    }
    glEnd();
    glFlush();
}
