#include "parsetree.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define BUFSIZE 65536
#define SERVER_PORT 50000

int position;
extern int num_chars;

struct cell {
  char *car;
  struct cell *cdr;
}; 

typedef struct cell *list;

char * strcat2(const char *s1, const char *s2)
{
  char *ret;
  char *p;
  int s1_len;
  s1_len = strlen(s1);
  p = (char *)malloc(s1_len + strlen(s2) + 2);
  ret = p;
  while (*s1 != '\0') {
    *p++ = *s1++;
  }
  if (s1_len>0) *p++ = ' ';
  while (*s2 != '\0') {
    *p++ = *s2++;
  }
  *p = '\0';
  return ret;
}

char * strcat1(const char *s1, const char *s2)
{
  char *ret;
  char *p;
  int s1_len;
  s1_len = strlen(s1);
  p = (char *)malloc(s1_len + strlen(s2) + 1);
  ret = p;
  while (*s1 != '\0') {
    *p++ = *s1++;
  }
  while (*s2 != '\0') {
    *p++ = *s2++;
  }
  *p = '\0';
  return ret;
}

/* insert a space */
list consAppCar2 (char* str, list list) {
  struct cell *c;
  if(list==NULL)
    return NULL;
  c = malloc (sizeof (struct cell));
  c->car = strcat2 (list->car, str);
  c->cdr = list;
  return c;
}

/* does not insert a space */
list consAppCar1 (char* str, list list) {
  struct cell *c;
  if(list==NULL)
    return NULL;
  c = malloc (sizeof (struct cell));
  c->car = strcat1 (list->car, str);
  c->cdr = list;
  return c;
}

list cons (char* str, list list) {
  struct cell *c;
  c = malloc (sizeof (struct cell));
  c->car = str;
  c->cdr = list;
  return c;
}  

list concat (list x, list y) {
  struct cell *c;
  if(x==NULL)
    return y;
  c = malloc (sizeof(struct cell));
  c->car = x->car;
  c->cdr = concat (x->cdr, y);
  return c;
}

list allSYNatexp (struct atexp *atexp, list result);
list allSYNappexp (struct appexp *appexp, list result);
list allSYNexp (struct exp *exp, list result);
list allSYNdec (struct dec *dec, list result);

list allSYNatexp (struct atexp *atexp, list result) {
  list temp;
  switch (atexp->tag) {
  case ATEXP1: /* ID */
    return NULL;
  case PATEXP1_CURSOR: /* CURSOR */
    return cons("...", result);
  case ATEXP2: /* (exp) */
    return allSYNexp (atexp->exp, result);
  case PATEXP2: /* (exp */
    temp = allSYNexp (atexp->exp, result);
    return consAppCar1 (")", temp);
  case ATEXP3: /* LET dec IN exp END */
    return NULL;
  case PATEXP3: /* LET dec IN pexp */
    temp = allSYNexp (atexp->exp, cons (atexp->dec->id, result));
    return consAppCar2 ("end", temp);
  case PATEXP3_2: /* LET pdec */
    temp = allSYNdec (atexp->dec, result);
    return consAppCar2 ("in ... end", temp);
  }
}

list allSYNappexp (struct appexp *appexp, list result) {
  list temp;
  switch (appexp->tag) {
  case APPEXP1: /* atexp */
    return NULL;
  case PAPPEXP1: /* patexp */
  case PAPPEXP2: /* appexp patexp */
    return allSYNatexp (appexp->atexp, result);
  }
}

list allSYNexp (struct exp *exp, list result){
  switch (exp->tag) {
  case EXP1: /* appexp */
    return NULL;
  case PEXP1: /* pappexp */
    return allSYNappexp(exp->appexp, result);
  case EXP2: /* FN ID RA exp */
    return NULL;
  case PEXP2: /* FN ID RA pexp */
    return allSYNexp (exp->exp, cons (exp->id, result));
  case PEXP3: /* FN ID CURSOR */
    return cons("=> ...", result);
  }
}

list allSYNdec (struct dec *dec, list result) {
  switch (dec->tag) {
  case PDEC_CURSOR:
    return cons("val ... = ...", result);
  case PDEC: /* VAL ID '=' pexp */
    return allSYNexp (dec->exp, result);
  }
}

list allSYN (struct exp *exp) {
  return allSYNexp (exp, NULL);
}

list computeCandidates (struct exp *parseResult) {
  return allSYN (parseResult);
}

void clearbuf(char *buf) {
  int i;
  for(i=0; i<BUFSIZE; i++)
    buf[i]=0;
}

int main(void) {
  char stringarray[256];
  extern struct exp *parseResult;
  extern int yyparse(void);
  //  extern FILE *yyin;
  struct cell *idList=NULL;
  int fd[2];
  FILE *pipeFile;
  int sockfd; /* file descriptor returned by socket() */
  int ns; /* file descriptor returned by accept() */
  struct sockaddr_in server;
  struct  sockaddr_in client;
  socklen_t fromlen;
  char buf[BUFSIZE];
  int msglen;
  const int one = 1;
  if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
    perror("server: socket");
    exit(1);
  }
  bzero((char *)&server, sizeof(server));
  server.sin_family = PF_INET;
  server.sin_port = htons(SERVER_PORT);
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, 
	     &one, sizeof(int));
  if(bind(sockfd, (struct sockaddr *)&server, sizeof(server))
     == -1) {
    perror("server: bind");
    //    exit(1);
  }
  if(listen(sockfd, 5) == -1){
    perror("server: listen");
    exit(1);
  }
  fromlen = sizeof(client);

  while (1) {
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    //    printf("\nconnect request from: %s   port: %d\n",
    //	   inet_ntoa(client.sin_addr), ntohs(client.sin_port));

    clearbuf(buf);
    if(read(ns, buf, BUFSIZE) == -1){
      perror("server: read1");
      exit(1);
    }
    //    printf("\n<SERVER> message from client  :  %s\n", buf);

    close (ns);

    sscanf (buf, "%d", &position);
    //    printf("position=%d\n", position);
    
    
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    //    printf("\nconnect request from: %s   port: %d\n",
    //	   inet_ntoa(client.sin_addr), ntohs(client.sin_port));
    
    if(pipe(fd)==-1) {
      perror("pipe");
      exit(1);
    }

    while(1){
      msglen=read(ns, buf, BUFSIZE);
      if(msglen == -1){
	perror("server: read2");
	exit(1);
      }
      //      printf("msglen=%d\n", msglen);
      //      fflush(stdout);
      if(msglen==0)break;
      if(write(fd[1], buf, msglen)==-1){
	perror("write");
	exit(1);
      }
    }
    close(ns);
    close(fd[1]);
    pipeFile=fdopen(fd[0], "r");

    //  yyin = pipeFile;
    yyrestart(pipeFile);
    if (yyparse()) {
      fprintf (stderr, "syntax error in yyparse\n"); 
    } else {
      idList = computeCandidates (parseResult);
    }

    

    fclose(pipeFile);
    close(fd[0]); // is this necessary?

    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }

    if(write(ns, &stringarray, strlen(stringarray)) == -1){ 
      perror("server: write");
      exit(1);
    }
    if(write(ns, "\n", 1) == -1){ 
      perror("server: write");
      exit(1);
    }
    for (;idList!=NULL; idList=idList->cdr) {
      if (*(idList->car)=='\0') continue;
      msglen = strlen (idList->car);
      printf("cand: %s\n", idList->car);
      if(write(ns, idList->car, msglen) == -1){ 
          perror("server: write");
          exit(1);
        }
      if (idList->cdr!=NULL) {
	if(write(ns, "\n", 1) == -1){ 
          perror("server: write");
          exit(1);
        }
      }
    }

    close(ns);
    num_chars=0;
    idList=NULL;
  }
  close(sockfd);
  return 0;
}
