enum tag {EXP1, PEXP1, EXP2, PEXP2, PEXP3, APPEXP1, PAPPEXP1, APPEXP2, PAPPEXP2, 
	  ATEXP1, PATEXP1_CURSOR, ATEXP2, PATEXP2, 
	  ATEXP3, PATEXP3, PATEXP3_2, DEC, PDEC_CURSOR, PDEC};

  struct exp {
    enum tag tag;
    struct appexp *appexp;
    char *id;
    struct exp *exp;
  };

  struct appexp {
    enum tag tag;
    struct appexp *appexp;
    struct atexp *atexp;
  };

  struct atexp {
    enum tag tag;
    char *id;
    struct exp *exp;
    struct dec *dec;
  };

  struct dec {
    enum tag tag;
    char *id;
    struct exp *exp;
  };
