%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parsetree.h"

  struct exp *parseResult;

  struct exp *make_exp1 (struct appexp *appexp);
  struct exp *make_pexp1 (struct appexp *appexp);
  struct exp *make_exp2 (char *id, struct exp *exp);
  struct exp *make_exp3 (char *id, struct exp *exp);
  struct exp *make_pexp2 (char *id, struct exp *exp);
  struct exp *make_pexp3 (char *id, struct exp *exp);
  struct appexp *make_appexp1 (struct atexp *atexp);
  struct appexp *make_pappexp1 (struct atexp *atexp);
  struct appexp *make_appexp2 (struct appexp *appexp, struct atexp *atexp);
  struct appexp *make_pappexp2 (struct appexp *appexp, struct atexp *atexp);
  struct atexp *make_atexp1 (char *id);
  struct atexp *make_patexp1_CURSOR (void);
  struct atexp *make_atexp2 (struct exp *exp);
  struct atexp *make_patexp2 (struct exp *exp);
  struct atexp *make_atexp3 (struct dec *dec, struct exp *exp);
  struct atexp *make_patexp3 (struct dec *dec, struct exp *exp);
  struct atexp *make_patexp3_1 (struct dec *dec, struct exp *exp);
  struct atexp *make_patexp3_2 (struct dec *dec, struct exp *exp);
  struct dec *make_dec (char *id, struct exp *exp);
  struct dec *make_pdec_CURSOR (void);
  struct dec *make_pdec (char *id, struct exp *exp);
  %}

%union{
  int int_value;
  char *id_value;
  struct exp *exp;
  struct appexp *appexp;
  struct atexp *atexp;
  struct dec *dec;
 }

%token <id_value> ID 
%token <int_value> NUM
%token LET VAL IN END FN RA CURSOR

%type<exp> exp
%type<exp> pexp
%type<appexp> appexp
%type<appexp> pappexp
%type<atexp> atexp
%type<atexp> patexp
%type<dec> dec
%type<dec> pdec

%%

start
: pexp
{
  printf ("succeeded.\n");
  parseResult = $1;
}

exp
: appexp
{
  $$ = make_exp1 ($1);
}
| FN ID RA exp
{
  $$ = make_exp2 ($2, $4);
}

pexp
: pappexp
{
  $$ = make_pexp1 ($1);
}
| FN ID RA pexp
{
  $$ = make_pexp2 ($2, $4);
}
| FN ID CURSOR
{
  $$ = make_pexp3 ($2, NULL);
}

appexp
: atexp
{
  $$ = make_appexp1($1);
}
| appexp atexp
{
  $$ = make_appexp2 ($1, $2);
}

pappexp
: patexp
{
  $$ = make_pappexp1($1);
}
| appexp patexp
{
  $$ = make_pappexp2 ($1, $2);
}

atexp
: ID
{
  $$ = make_atexp1 ($1);
}
| '(' exp ')'
{
  $$ = make_atexp2 ($2);
}
| LET dec IN exp END
{
  $$ = make_atexp3 ($2, $4);
}

patexp
: CURSOR
{
  $$ = make_patexp1_CURSOR ();
}
| '(' pexp
{
  $$ = make_patexp2 ($2);
}
| LET dec IN pexp
{
  $$ = make_patexp3 ($2, $4);
}
| LET pdec
{
  $$ = make_patexp3_2 ($2, NULL);
}

dec
: VAL ID '=' exp
{
  $$ = make_dec($2, $4);
}

pdec
: CURSOR
{
  $$ = make_pdec_CURSOR ();
}
| VAL ID '=' pexp
{
  $$ = make_pdec($2, $4);
}

%%

struct exp *make_exp1 (struct appexp *appexp) {
  struct exp *exp1;
  exp1 = malloc (sizeof (struct exp));
  exp1->tag=EXP1;
  exp1->appexp=appexp;
  return exp1;
}

struct exp *make_pexp1 (struct appexp *appexp) {
  struct exp *exp1;
  exp1 = malloc (sizeof (struct exp));
  exp1->tag=PEXP1;
  exp1->appexp=appexp;
  return exp1;
}

struct exp *make_exp2 (char *id, struct exp *exp) {
  struct exp *exp2;
  exp2 = malloc (sizeof (struct exp));
  exp2->tag=EXP2;
  exp2->exp=exp;
  exp2->id=id;
  return exp2;
}

struct exp *make_pexp2 (char *id, struct exp *exp) {
  struct exp *exp2;
  exp2 = malloc (sizeof (struct exp));
  exp2->tag=PEXP2;
  exp2->exp=exp;
  exp2->id=id;
  return exp2;
}

struct exp *make_pexp3 (char *id, struct exp *exp) {
  struct exp *exp2;
  exp2 = malloc (sizeof (struct exp));
  exp2->tag=PEXP3;
  exp2->exp=exp;
  exp2->id=id;
  return exp2;
}

struct appexp *make_appexp1 (struct atexp *atexp) {
  struct appexp *appexp1;
  appexp1 = malloc (sizeof (struct appexp));
  appexp1->tag=APPEXP1;
  appexp1->atexp=atexp;
  return appexp1;
}

struct appexp *make_pappexp1 (struct atexp *atexp) {
  struct appexp *appexp1;
  appexp1 = malloc (sizeof (struct appexp));
  appexp1->tag=PAPPEXP1;
  appexp1->atexp=atexp;
  return appexp1;
}

struct appexp *make_appexp2 (struct appexp *appexp, struct atexp *atexp) {
  struct appexp *appexp2;
  appexp2 = malloc (sizeof (struct appexp));
  appexp2->tag=APPEXP2;
  appexp2->appexp=appexp;
  appexp2->atexp=atexp;
  return appexp2;
}

struct appexp *make_pappexp2 (struct appexp *appexp, struct atexp *atexp) {
  struct appexp *appexp2;
  appexp2 = malloc (sizeof (struct appexp));
  appexp2->tag=PAPPEXP2;
  appexp2->appexp=appexp;
  appexp2->atexp=atexp;
  return appexp2;
}

struct atexp *make_atexp1 (char *id) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP1;
  atexp->id=id;
  return atexp;
}

struct atexp *make_patexp1_CURSOR (void) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=PATEXP1_CURSOR;
  return atexp;
}

struct atexp *make_atexp2 (struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP2;
  atexp->exp=exp;
  return atexp;
}

struct atexp *make_patexp2 (struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=PATEXP2;
  atexp->exp=exp;
  return atexp;
}

struct atexp *make_atexp3 (struct dec *dec, struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP3;
  atexp->dec=dec;
  atexp->exp=exp;
  return atexp;
}

struct atexp *make_patexp3 (struct dec *dec, struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=PATEXP3;
  atexp->dec=dec;
  atexp->exp=exp;
  return atexp;
}

struct atexp *make_patexp3_2 (struct dec *dec, struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=PATEXP3_2;
  atexp->dec=dec;
  atexp->exp=exp;
  return atexp;
}

struct dec *make_dec (char *id, struct exp *exp) {
  struct dec *dec;
  dec = malloc (sizeof (struct dec));
  dec->tag=DEC;
  dec->id=id;
  dec->exp=exp;
  return dec;
}

struct dec *make_pdec_CURSOR (void) {
  struct dec *dec;
  dec = malloc (sizeof (struct dec));
  dec->tag=PDEC_CURSOR;
  return dec;
}

struct dec *make_pdec (char *id, struct exp *exp) {
  struct dec *dec;
  dec = malloc (sizeof (struct dec));
  dec->tag=PDEC;
  dec->id=id;
  dec->exp=exp;
  return dec;
}
