## Summary 

The program is implemented by a cohesive hierarchical clustering algorithm, which takes vectors (matrices) as input and outputs the clustering results for each iteration.

## Requirement

Python 3.10

NumPy 1.23.1

Scipy 1.10.0

## Install

### Python installer

You can download a Python installer from the official [Python download website](https://www.python.org/downloads/) 

### Installing Numpy

If you use pip, you can install NumPy with:

```
pip install numpy
```

If you use conda, you can install NumPy from the defaults or conda-forge channels:

```bash
# Best practice, use an environment rather than install in the base env
conda create -n my-env
conda activate my-env
# If you want to install from conda-forge
conda config --env --add channels conda-forge
# The actual install command
conda install numpy
```

### Installing Scipy

If you use pip, you can install Scipy with:

```
pip install scipy
```

If you want the installation to be done through conda, you can use the below command:

```
conda install scipy
```

### Execute

To run Python scripts with the python command, you need to open a command-line and type in the word python, or python3 if you have both versions, followed by the path to your script, just like this:

```
python3 DistMeasures.py
```

v1 is the execution path of replace.c, but any vector can be used as input. 

```python
matrixfile = open(DT_PATH, "r")
```

Refer to GCOV for methods to generate execution paths from c programs.

```sh
gcov replace.c
```

gcov: https://gcc.gnu.org/onlinedocs/gcc/Gcov.html

The end conditions of the clustering can be customized

```python
target = n
```

 and the distance function can be selected from DistMeasures or can be customized.

```python
metric = jaccard_distance
```

## Note

**DistMeasures** stores functions for distance metrics.A distance metric is a function that defines the distance between two elements in a dataset. Common distance metrics include Euclidean distance, Manhattan distance, and cosine similarity.

**avglkge:**

In Average linkage clustering, the distance between two clusters is defined as the average of distances between all pairs of objects, where each pair is made up of one object from each group.

**creat_distMatrix:**

Create a Distance Matrix.A distance matrix is a matrix that contains the distance between each pair of elements in a dataset.

**creat_distsort:**

Create a distance sorted from largest to smallest.

**merge_mix:**

Merge the two clusters with the smallest distance.

**update_distsort:**

Update the sorted list of distances.
