$('#upload').click(function(e){
    e.preventDefault();
    var formData =  new FormData($('#uploadform')[0]);
    console.log(formData);
    $.ajax({
        url:'/upload', 
        type:'post',
        data: formData,
        contentType: false,
        processData: false,
        beforeSend: function() {
            $('#Loading').modal('show');    
        },
        success: function (res) {
            console.log('hide modal');
            $('#Loading').modal('hide');  
            console.log(res.result);
            data = res.result.data;
            if (res["code"] == 200) {
                console.log(data);
                $("#tbody").empty();

                var tbody = $('#tbody');
                tr = $('<tr/>').appendTo(tbody);
                tr.append('<td> obj </td>');
                tr.append('<td>' + res.result.count + '</td>');
                
                $.each(res.result.result_list, function(index, item) {
                    console.log(index, item);
                    var tr = $('<tr/>').appendTo(tbody);
                    tr.append('<td> v' + index + '</td>');
                    tr.append('<td>' + item + '</td>');
                })
                
                // var songUrl = '/static/songs/' + res['result']['songname'];
                ec_chart_Option.series = data;
                ec_chart.setOption(ec_chart_Option)
            }else{
                alert('ERROR,please try again');
            }
        }
    })
})