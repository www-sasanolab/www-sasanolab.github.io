import os
import funcs
from flask import Flask, render_template, request, jsonify, flash, send_file
from werkzeug.utils import secure_filename
import xlrd
# basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
BASEDIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASEDIR, 'static/uploads')
ALLOWED_EXTENSIONS = set(['xlsx'])
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['DOWNLOAD_FOLDER'] = os.path.join(basedir, 'static/download')

def allowed_file(filename):
    return '.' in filename and \
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    return render_template('index.html')

def convert_result_to_list(result_list, coords_list):
    #['0-2-4-7-8', '5-6-3', '1']
    points_list = []
    finnal_result_list = []
    for item in result_list:
        tmp_list = item.split('-')
        # 各个元素加2
        tmp_list = [int(tmp) + 2 for tmp in tmp_list]
        finnal_result_list.append('-'.join([str(tmp) for tmp in tmp_list]))
        # 首尾添加起始点
        tmp_list.insert(0, 1)
        tmp_list.append(1)
        tmp_list_1 = [ coords_list[tmp-1] + [tmp]  for tmp in tmp_list ]
        # print('tmp_list_1: {}'.format(tmp_list_1))
        # print(tmp_list)
        # tmp_list_2 = [ tmp_list_1[idx]+[tmp]  for idx, tmp in enumerate(tmp_list) ]
        # print('tmp_list_2: {}'.format(tmp_list_2))
        points_list.append(tmp_list_1)

    return (points_list, finnal_result_list)

def get_coords_from_xlsx(xlspath):
    coords = []
    try:
        print('xlspath: {}'.format(xlspath))
        wb = xlrd.open_workbook(xlspath)
        sheet = wb.sheet_by_index(0)
    except Exception as e:
        print('Excepiton - {}'.format(str(e)))
    nrows = sheet.nrows
    # ncols = sheet.ncols
    for r in range(1, nrows):
        try:
            x_coord = sheet.cell_value(r, 1) 
            y_coord = sheet.cell_value(r, 2)
            coords.append([x_coord, y_coord])
        except Exception as e:
            print("Excepiton - {}".format(str(e)))
    return coords
@app.route('/download/<filename>')
def download_file (filename):
    folder = app.config['DOWNLOAD_FOLDER']
    # 构造供下载文件的完整路径
    path = os.path.join(folder, filename)
    return send_file(path, as_attachment=True)

@app.route('/upload', methods=['GET','POST'])
def upload():
    xlsxname = ''
    if request.method == 'POST':
        filepath = ''
        points_list = []
        coords_list = []
        chart_data = []
        result_list = []
        f = request.files['xlsfile']
        if f and allowed_file(f.filename):
            try:
                xlsxname = secure_filename(f.filename)
                filepath = os.path.join(UPLOAD_DIR, xlsxname)
                f.save(filepath)
                print('xlsxname: {}'.format(xlsxname))
                print('get corrds list form xlsx file')
                coords_list = get_coords_from_xlsx(filepath)
                # print(coords_list)

                print('run the detect funciton now ')
                result_list = funcs.run(filepath=filepath,epochs=500,pc=0.6,pm=0.2,popsize=100,v_cap=100)
                # result_list = [32.0142, '0-2-4-7-8', '5-6-3', '1']
                print(result_list)

                if result_list:
                    points_list, final_result_list= convert_result_to_list(result_list[1:], coords_list)
                    # print(points_list)
                    # print(final_result_list)
                
                if points_list:
                    for idx, item in enumerate(points_list):
                        chart_data.append({'name': 'R {}'.format(idx+1), 'data': item, 'type':'line'})
                print('chart_data:{}'.format(chart_data))

                return jsonify({
                    "code":200,
                    "msg": "success",
                    "result":
                        {   "count": result_list[0],
                            "result_list": final_result_list,
                            "xlsxname": xlsxname,
                            "data": chart_data
                        }
                })
            except Exception as e:
                print(e)
                return jsonify({
                    "code": 500,
                    "msg": "Error, please check!"
                })
        else:
            return jsonify({
                "code": 500,
                "msg": "File is empty or format incorrect, only xlsx allowed!"
            })

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)
 