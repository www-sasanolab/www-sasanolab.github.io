(require 'cl)
(require 'lambda-common)
(require 'lambda-exp)
(require 'lambda-type-env)
(require 'lambda-unification)
(require 'lambda-struct-w-result)

(defun type-inference-w (env expM)
  "return the set of pair of substitution and type"
  (cond
   ;;const
   ((intExp-p expM)
    (w-result nil (intTy)))
   ;;variable
   ((varExp-p expM)
    (let ((type (find-env env (varExp-name expM))))
      (w-result nil (if (polyTy-p type) (instanciate type) type))))
   ;;function abstraction
   ((absExp-p expM)
    (let* ((new-tyVar (varTy (freshTyVar)))
	   (result-for-body (type-inference-w
			     (insert-env env (absExp-name expM) new-tyVar)
			     (absExp-body expM))))
      (w-result (w-result-subst result-for-body)
			   (arrowTy (apply-subst-to-type new-tyVar (w-result-subst result-for-body))
				    (w-result-type result-for-body)))))
   ;;function application
   ((appExp-p expM)
    (let* 
	((result-for-fun (type-inference-w env (appExp-fun expM)))
	 (result-for-arg (type-inference-w (apply-subst-to-env env (w-result-subst result-for-fun)) (appExp-arg expM)))
	 (new-tyVar (varTy (freshTyVar)))
	 (subst (unify (singleton-set 
			(cons (apply-subst-to-type (w-result-type result-for-fun) (w-result-subst result-for-arg))
			      (arrowTy (w-result-type result-for-arg) new-tyVar))))))
      (w-result (union-subst subst (union-subst (w-result-subst result-for-arg) (w-result-subst result-for-fun)))
		(apply-subst-to-type new-tyVar subst))))
   ;;let expression
   ((letExp-p expM)
    (let* ((result-for-decl (type-inference-w-decl env (letExp-decl expM)))
	   (result-for-exp (type-inference-w (w-decl-result-env result-for-decl) (letExp-body expM)))
	   (subst (union-subst (w-result-subst result-for-exp) (w-decl-result-subst result-for-decl))))
      (w-result subst (w-result-type result-for-exp))))
   (t (throw 'error 'type-inference-w))))

;;decl: list
(defun type-inference-w-decl (env decl)
  "return a pair of substitution and environment"
  (let*
      (value
       (subst (empty-subst)))
    ;;dec: valBind or recValBind
    (dolist (valBind decl value)
      (cond
       ((valBind-p valBind)
	(let* 
	    ((result-for-exp (type-inference-w env (valBind-exp valBind)))
	     (new-env (insert-env (apply-subst-to-env env (w-result-subst result-for-exp))
				    (varPat-name (valBind-pat valBind))
				    (to-polyTy env (w-result-type result-for-exp)))))
	  (setq subst (union-subst (w-result-subst result-for-exp) subst))
	  (setq env new-env)))
       ;;recursive function
       ((recValBind-p valBind)
	(let* 
	    ((new-tyVar (freshTyVar))
	     (new-env (insert-env env (varPat-name (recValBind-pat valBind)) (varTy new-tyVar)))
	     (result-for-exp (type-inference-w new-env (recValBind-exp valBind)))
	     (subst (unify (singleton-set 
			    (cons (apply-subst-to-type (varTy new-tyVar) (w-result-subst result-for-exp))
				  (w-result-type result-for-exp)))))
	     (subst2 (union-subst subst (w-result-subst result-for-exp)))
	     (new-env2 (insert-env env (varPat-name (recValBind-pat valBind)) 
				   (to-polyTy env (apply-subst-to-type (varTy new-tyVar) subst2)))))
	  (setq subst subst2)
	  (setq env new-env2)))
       ;;error
       (t (throw 'error 'type-inference-w-valBind))))
    (w-decl-result subst env)))
	  
(provide 'lambda-inference-w)