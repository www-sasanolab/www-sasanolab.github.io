(require 'cl)
(require 'lambda-common)
(require 'lambda-type)

(setq freshTyVar 0)

(defun initialize-freshTyVar ()
  (setq freshTyVar 0))

(defun freshTyVar ()
  (let ((tyVar (format "X%d" freshTyVar)))
    (setq freshTyVar (+ 1 freshTyVar))
    tyVar))

;;���ƂŃo�����X�̂Ƃꂽ2���T���؂ŏ�������
(defun make-empty-env ()
  nil)

(defun insert-env (env key value)
  (cons (cons key value)
	env))

(defun find-env (env key)
  (cdr (assoc key env)))

(defun enum-all-keys (env)
  "return the set of keys in env"
  (let ((result (empty-set))
	(lst (mapcar '(lambda (x) (singleton-set (car x))) env)))
    (dolist (singleton lst result)
      (setq result (set-union singleton result)))
    result))

(defun env-to-set (func env)
  (let* ((env (remove-duplicate-key env))
	 (result (empty-set))
	 (lst (mapcar '(lambda (x) (singleton-set (funcall func x))) env)))
    (dolist (singleton lst result)
      (setq result (set-union singleton result)))
    result))
	
;;to-type��to-env�ň����̏��Ԃ��Ⴄ�̂Œ����ׂ�
(defun apply-subst-to-type (type subst)
  (cond
   ((intTy-p type) type)
   ((arrowTy-p type)
    (arrowTy 
     (apply-subst-to-type (arrowTy-arg type) subst)
     (apply-subst-to-type (arrowTy-result type) subst)))
   ((polyTy-p type) 
    (polyTy 
     (polyTy-tyVarList type)
     (apply-subst-to-type 
      (polyTy-type type) 
      (foldl 'delete-map subst (polyTy-tyVarList type)))))
   ((varTy-p type)
    ;;1�����K�p���Ă��Ȃ��̂������Bsubst�ɂ���fold����΂����͂�
    (or
     (find-map subst (varTy-name type))
     type))))

(defun apply-subst-to-env (env subst)
  (if (not env)
      nil
    (cons
     (cons (caar env)  (apply-subst-to-type (cdar env) subst))
     (apply-subst-to-env (cdr env) subst))))

(defun apply-subst-to-type-pair-set (subst set)
  (map-set '(lambda (pair)
	      (cons 
	       (apply-subst-to-type (car pair) subst)
	       (apply-subst-to-type (cdr pair) subst)))
	   set))


(defun enum-all-tyVar-type (type)
    "return the set of type variables in type"
   (cond 
    ((intTy-p type) nil)
    ((varTy-p type) (list (varTy-name type)))
    ((arrowTy-p type)
     (append
      (enum-all-tyVar-type (arrowTy-arg type))
      (enum-all-tyVar-type (arrowTy-result type))))
    ((polyTy-p type) 
     (enum-all-tyVar-type (polyTy-type type)))))

(defun enum-all-tyVar-env (env)
  "return the set of type variables in env"
  (let ((result nil))
    (dolist (var-type-pair env result)
      (setq result (set-union result (enum-all-tyVar-type (cdr var-type-pair)))))
    result))

;;Value restriction will be implemented in the future.
(defun to-polyTy (env type)
  "return a polymorphic type if type contains free type variable"
  (let* ((tyVar-set-in-env (enum-all-tyVar-env env))
	 (tyVar-set-in-type (enum-all-tyVar-type type))
	 (tyVarList (let ((result (empty-set)))
		      (dolist (tyVar tyVar-set-in-type result)
			(when (not (member tyVar tyVar-set-in-env))
			  (setq result (set-union (singleton-set tyVar) result))))
		      result)))
    (if tyVarList 
	(polyTy tyVarList type)
      type)))

(defun instanciate (type)
  (if (polyTy-p type)
      (let ((subst (mapcar '(lambda (tyVar) (cons tyVar (varTy (freshTyVar)))) 
			   (polyTy-tyVarList type))))
	(apply-subst-to-type (polyTy-type type) subst))
    type))

(provide 'lambda-type-env)
