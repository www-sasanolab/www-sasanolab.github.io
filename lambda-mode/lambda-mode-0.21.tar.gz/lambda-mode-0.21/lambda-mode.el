(require 'lambda-candidates)
(require 'lambda-inference-v)
(require 'lambda-parser)
(require 'lambda-debug)

(defvar lambda-mode-map nil)
(setq lambda-mode-map (make-sparse-keymap))
(define-key lambda-mode-map "\C-xt" 'tokenize-all)
(define-key lambda-mode-map "\C-xp" 'parse-test)
(define-key lambda-mode-map "\C-xc" 'make-candidates)

(defvar lambda-mode-sources nil)
(defvar last-candidates nil)

(setq default-env (foldl '(lambda (env x)
			    (insert-env env (car x) (cdr x)))
			 (make-empty-env)
			 (list 
			  (cons "/" (arrowTy (intTy) (arrowTy (intTy) (intTy))))
			  (cons "*" (arrowTy (intTy) (arrowTy (intTy) (intTy))))
			  (cons "-" (arrowTy (intTy) (arrowTy (intTy) (intTy))))
			  (cons "+" (arrowTy (intTy) (arrowTy (intTy) (intTy)))))))

(defun show-last-candidates ()
  (interactive)
  (mapcar '(lambda (candidate)
	     (message (format "%s: %s" (car candidate) (type-to-string (cdr candidate)))))
	  last-candidates)
  (message (format "there are %s variables" (length last-candidates))))

(defun time-diff (before after)
  (- (current-time-to-microsec after)
     (current-time-to-microsec before)))

(defun current-time-to-microsec (time)
  (let ((result 0)
	(high (car time))
	(low (car (cdr time)))
	(mil (car (cdr (cdr time)))))
    (setq result (+ (* (+ (* high 2 (* 16 16)) low) 1000) (/ mil 1000)))
    
    result))


(defun make-candidates ()
  (interactive)
  (initialize-freshTyVar)
  (let 
      ((before-time (current-time))
       after-time
       (result (catch 'error 
		 (let* 
		     ((inputing-word (lambda-ac-current-word))
		      (cursor-position (- (point) (length inputing-word)))
		      (time-of-parse-start (current-time))
		      (parse-tree (save-excursion 
				    (goto-char cursor-position)
				    (lambda-parser)))
		      (time-of-tree-conversion-start (current-time))
		      (expD (lambda-tree-conversion parse-tree))
		      (time-of-inference-start (current-time))
		      (inference-result-set (lambda-type-inference-v default-env expD))
		      (time-of-enum-candidates-start (current-time))
		      (candidates (enum-candidates-from-v-result-set inference-result-set))
		      (time-of-end (current-time)))
		   (let 
		       ((time-for-parse (time-diff time-of-tree-conversion-start time-of-parse-start ))
			(time-for-tree-conversion (time-diff time-of-inference-start time-of-tree-conversion-start))
			(time-for-inference (time-diff time-of-enum-candidates-start time-of-inference-start))
			(time-for-enum-candidates (time-diff  time-of-end time-of-enum-candidates-start))
			(time-for-entire (time-diff time-of-end time-of-parse-start)))
		     (message (format "parse:%s" time-for-parse))
		     (message (format "conversion:%s" time-for-tree-conversion))
		     (message (format "inference:%s" time-for-inference))
		     (message (format "enum:%s" time-for-enum-candidates))
		     (message (format "entire:%s" time-for-entire)))
		   ;;filtering by inputing word
		   (foldl '(lambda (prev candidate)
			     (if (eq 0 (string-match (format "^%s" inputing-word) (car candidate)))
				 (cons candidate prev)
			       prev))
			  nil candidates)))))
    
    (if (listp result)
	(progn
	  (setq last-candidates result)
	  ;(show-last-candidates)
	  (message (format "%s microsec." (time-diff before-time (current-time))))
	  (mapcar 'car result))
      (message (format "error: %s" result))
      nil)))
      
    

(defvar make-candidates
  '((candidates . make-candidates))
  "Source for completion variables")


(defun lambda-mode ()
  "Lambda mode version 0.2 alpha"
  (interactive)
  (kill-all-local-variables)
  (setq mode-name "��")
  (setq major-mode 'lambda-mode)
  (use-local-map lambda-mode-map)
  (run-hooks 'lambda-mode-hook)
  (setq ac-sources '(make-candidates)))


(defun lambda-ac-current-word ();;lambda-mode.el����ړ�
  (let ((word ""))
    (save-excursion
      (forward-char -1)
      (while (and (not (or (string= (char-to-string (char-after)) " ");�K���ȋ�؂蕶��
			   (string= (char-to-string (char-after)) "\n")
			   (string= (char-to-string (char-after)) ")")
			   (string= (char-to-string (char-after))"(")
			   (string= (char-to-string (char-after))":")
			   (string= (char-to-string (char-after))"]")
			   (string= (char-to-string (char-after))"[")
			   (string= (char-to-string (char-after)) "\t")))
		  (progn 
		    ;(my-message (format "lambda-ac-current-word:\"%c\"" (char-after)))
		    (setq word (concat (char-to-string (char-after)) word ))
		    (if (= (point) 1)
			nil
		      (forward-char -1)
		      t)))))
    word))

(provide 'lambda-mode)