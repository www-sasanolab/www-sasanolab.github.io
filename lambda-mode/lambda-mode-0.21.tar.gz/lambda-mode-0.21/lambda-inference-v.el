(require 'cl)
(require 'lambda-common)
(require 'lambda-exp)
(require 'lambda-type-env)
(require 'lambda-unification)
(require 'lambda-inference-w)
(require 'lambda-struct-v-result)

(defun type-inference-v-arity (type)
  "�֐��K�p�ȉ񐔂𐔂��܂�"
  (cond
   ((arrowTy-p type)
    (+ 1 (type-inference-v-arity (arrowTy-result type))))
   ((polyTy-p type)
    (type-inference-v-arity (polyTy-type type)))
   (t 0)))

(defun type-inference-v-genArrowTy (n)
  "�^����ꂽ�����̉񐔂����֐��K�p�\�Ȍ^�����܂�"
  (if (eq n 0) 
      (varTy (freshTyVar))
    (arrowTy (varTy (freshTyVar)) (type-inference-v-genArrowTy (- n 1)))))

(defun type-inference-v-rightSpineSet (type)
  "�֐��K�p��C�Ӊ񐔓K�p���ē�����^�̏W����Ԃ�"
  (cond
   ((arrowTy-p type)
    (set-union (singleton-set type)
	       (type-inference-v-rightSpineSet (arrowTy-result type))))
   (t (singleton-set type))))

(defun lambda-type-inference-v (env expD)
  "return the set of tuples of substitution, type, and pair of env and type of cursor"
  (cond
   ;;mark expression
   ((markExp-p expD)
    (let* ((result-set-for-d (lambda-type-inference-v env (markExp-expD expD)))
	   (result-set (foldl '(lambda (prev x)
				 (set-union prev 
					    (let* ((types (type-inference-v-rightSpineSet (v-result-type x))))
					      (foldl '(lambda (p ty)	;;����set��list�ł��邱�ƂɈˑ��B���ƂŒ���
							(set-union p (singleton-set (v-result (v-result-subst x) ty (v-result-c x)))))
						     (empty-set) types))))
			      (empty-set) result-set-for-d)))
      result-set))
   ;;cursor expression
   ((cursorExp-p expD)
    (let* ((variables (enum-all-keys env));;�ϐ��ꗗ
	   ;;�^��S���擾
	   (types-in-env (mapcar '(lambda (key) (find-env env key)) variables))
	   ;;�^�̊֐��K�p�\�ȉ񐔂𐔂��ďW���ɂ���
	   (arities (let* ((temp (mapcar '(lambda (type) (type-inference-v-arity type)) types-in-env))
			   (arities (foldl '(lambda (prev x) (if (member x prev) prev (cons x prev))) nil temp)))
		      arities))
	   ;;�^�����
	   (fresh-types (mapcar '(lambda (n) (type-inference-v-genArrowTy n)) arities))
	   ;;�^���ꂼ��ɂ���C�����
	   (C (mapcar '(lambda (type) (v-cursor-result env type)) fresh-types))
	   ;;C���ꂼ��ɂ��Č��ʂ����B�����͏W��
	   (result-set (foldl '(lambda (p x) (set-union p 
							(singleton-set (v-result nil (v-cursor-result-type x) x))))
			      (empty-set) C)))
      result-set))
   ;;function application
   ((appExpD-p expD)
    (let* ((result-for-m (type-inference-w env (appExpD-fun expD)))
	   (result-set-for-d (lambda-type-inference-v 
			      (apply-subst-to-env env (w-result-subst result-for-m))
			      (appExpD-argD expD)))
	   (result-set (map-set
			'(lambda (x) 
			   ;;When unification fails, the function unify throws an error with nil, which becomes the value of this catch expression.
			   (catch 'error 
			     (let* 
				 ((new-tyVar (varTy (freshTyVar)))
				  (S3 (unify (singleton-set (cons
							     (apply-subst-to-type (w-result-type result-for-m) (v-result-subst x))
							     (arrowTy (v-result-type x) new-tyVar))))))
			       (v-result
				(union-subst S3 (union-subst (v-result-subst x) (w-result-subst result-for-m)))
				(apply-subst-to-type new-tyVar S3)
				(v-result-c x)))))
			result-set-for-d)))
      (set-compact result-set))) ;;remove nil
   ;;function abstraction
   ((absExpD-p expD)
    (let* ((new-tyVar (varTy (freshTyVar)))
	   (result-set-for-d (lambda-type-inference-v 
			      (insert-env env (absExpD-name expD) new-tyVar)
			      (absExpD-bodyD expD)))
	   (result-set (map-set
			'(lambda (x)
			   (v-result
			    (v-result-subst x)
			    (arrowTy (apply-subst-to-type new-tyVar (v-result-subst x))
				     (v-result-type x))
			    (v-result-c x)))
			result-set-for-d)))
      result-set))
   ;;let expression having bodyD
   ((letExpD-p expD)
    (let* ((result-for-decl (type-inference-w-decl env (letExpD-decl expD)))
	   (result-set-for-d (lambda-type-inference-v 
			      (w-decl-result-env result-for-decl)
			      (letExpD-bodyD expD)))
	   (result-set (map-set '(lambda (x)
				   (v-result 
				    (union-subst (v-result-subst x) (w-decl-result-subst result-for-decl))
				    (v-result-type x)
				    (v-result-c x)))
				result-set-for-d)))
      result-set))
   ;;let expression not having body
   ((letExp2D-p expD)
    (let*((new-tyVar (varTy (freshTyVar)))
	  (result-set-for-declD (type-inference-v-decl env (letExp2D-declD expD)))
	  (result-set (map-set '(lambda (x)
				  (v-result  (v-decl-result-subst x) new-tyVar (v-decl-result-c x)))
			       result-set-for-declD)))
      result-set))

   ;((letExp3D-p expD);;����Ȃ񂾂���
    ;(throw 'error 'type-inference-v-letExp3D))
   (t 
    (throw 'error 'type-inference-v))))
   
(defun type-inference-v-decl (env declD)
  "return a set of of a pair of substitution, environment and C (pair of type and environment)"
  ;;declD = (decl . decD)
  ;;decl��w�ɓ����āA�Ō��decD�������ŘM��
  (let*
      ((decl (car declD))
       (valBindD (cdr declD))
       (result-for-decl (when decl (type-inference-w-decl env decl)))
       (env (if decl (w-decl-result-env result-for-decl) env))
       (subst (if decl (w-decl-result-subst result-for-decl) (empty-subst)))
       (result-set-for-decD 
	(cond
	((valBindD-p valBindD)
	 (let* ((result-set-for-expD (lambda-type-inference-v env (valBindD-expD valBindD)))
		(result-set (map-set '(lambda (x)
					(let* ((new-env (insert-env (apply-subst-to-env env (v-result-subst x))
								    (varPat-name (valBindD-pat valBindD))
								    (to-polyTy env (v-result-type x)))))
					  (v-valBind-result (v-result-subst x) new-env (v-result-c x))))
				     result-set-for-expD)))
	   result-set))
	((recValBindD-p valBindD)
	 (let* ((new-tyVar (varTy (freshTyVar)))
		(new-env (insert-env env (varPat-name (recValBindD-pat valBindD)) new-tyVar))
		(result-set-for-expD (lambda-type-inference-v new-env (recValBindD-expD valBindD)))
		(result-set (map-set '(lambda (x)
					(catch 'error 
					  (let* 
					      ((subst (unify (singleton-set
							      (cons (apply-subst-to-type new-tyVar (v-result-subst x))
								    (v-result-type x)))))
					       (subst2 (union-subst subst (v-result-subst x)))
					       (new-env2 (insert-env env (varPat-name (recValBindD-pat valBindD)) 
								     (to-polyTy env (apply-subst-to-type new-tyVar subst2)))))
					    (v-valBind-result subst2 new-env2 (v-result-c x)))))
				     result-set-for-expD)))
	   (set-compact result-set)))
	(t (throw 'error 'type-inference-v-valBind))))
       (result-set (let ((value (empty-set)))
		     (dolist (result result-set-for-decD value)
		       (setq value (set-union value
					      (singleton-set (v-decl-result (v-valBind-result-subst result)
							     (v-valBind-result-env result)
							     (v-valBind-result-c result)))))))))
    result-set))
		     

(defun lambda-tree-conversion (expD)
  "insert mark nodes to parse tree"
  (cond
   ((cursorExp-p expD)
    (markExp expD))
   ((appExpD-p expD)
    (markExp (appExpD (appExpD-fun expD) 
		      (lambda-tree-conversion-2 (appExpD-argD expD)))))
   ((absExpD-p expD)
    (absExpD (absExpD-name expD) (markExp (lambda-tree-conversion (absExpD-bodyD expD)))))
   ((letExpD-p expD)
    (markExp (letExpD (letExpD-decl expD) 
		      (lambda-tree-conversion (letExpD-bodyD expD)))))
   ((letExp2D-p expD)
    (markExp (letExp2D 
	      (lambda-tree-conversion-decl (letExp2D-declD expD)))))
   ((parenExpD-p expD)
    (markExp (lambda-tree-conversion (parenExpD-expD expD))))))

(defun lambda-tree-conversion-decl (declD)
  (let* 
      ((decl 
	(let (value)
	  (if (eq 1 (length declD))
	      nil
	    (dotimes (i (- (length declD) 1) value)
	      (setq value (cons (car declD) value))
	      (setq declD (cdr declD)))
	    (reverse value))))
       (valBindD (car declD))
       (decD (cond
	      ((valBindD-p valBindD)
	       (valBindD (valBindD-pat valBindD)
			 (lambda-tree-conversion (valBindD-expD valBindD))))
	      ((recValBindD-p valBindD)
	       (recValBindD (recValBindD-pat valBindD)
		(lambda-tree-conversion (recValBindD-expD valBindD))))
	      (t (throw 'error 'tree-conversion-decl)))))
    (cons decl decD)))
	 

(defun lambda-tree-conversion-2 (expD)
  (cond
   ((cursorExp-p expD)
    expD)
   ((letExpD-p expD)
    (letExpD (letExpD-decl expD) 
	     (lambda-tree-conversion (letExpD-bodyD expD))))
   ((letExp2D-p expD)
    (letExp2D 
     (lambda-tree-conversion-decl (letExp2D-declD expD))))
   ((parenExpD-p expD)
    (lambda-tree-conversion (parenExpD-expD expD)))))
    
(provide 'lambda-inference-v)

