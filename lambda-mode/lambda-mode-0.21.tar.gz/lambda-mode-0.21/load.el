
(load-file "tokenizer-macro.el")
(load-file "auto-complete.el")
(load-file "lambda-common.el")
(load-file "lambda-exp.el")			   
(load-file "lambda-expD.el")
(load-file "lambda-debug.el")
(load-file "lambda-tokenizer.el")		   
(load-file "lambda-parser-data.el")		   
(load-file "lambda-parser.el")
(load-file "lambda-type.el")			   
(load-file "lambda-type-env.el")
(load-file "lambda-unification.el")
(load-file "lambda-struct-w-result.el")
(load-file "lambda-struct-v-result.el")
(load-file "lambda-inference-w.el")
(load-file "lambda-inference-v.el")		   
(load-file "lambda-candidates.el")
(load-file "lambda-mode.el")			   




