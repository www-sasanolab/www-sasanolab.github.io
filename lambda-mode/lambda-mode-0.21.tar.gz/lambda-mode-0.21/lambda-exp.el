(require 'cl)

;;variable
(defun varExp (name)
  (list
   '(class . varExp)
   (cons 'name name)))

(defun varExp-p (exp)
  (eq 'varExp  (cdr (assoc 'class exp))))

(defun varExp-name (exp)
  (cdr (assoc 'name exp)))

;;int 
(defun intExp (integer)
  (list
   '(class . intExp)
   (cons 'integer integer)))

(defun intExp-p (exp)
  (eq 'intExp  (cdr (assoc 'class exp))))

(defun intExp-integer (exp)
  (cdr (assoc 'integer exp)))

;;function application
(defun appExp (fun arg)
  (list
   '(class . appExp)
   (cons 'fun fun)
   (cons 'arg arg)))

(defun appExp-p (exp)
  (eq 'appExp  (cdr (assoc 'class exp))))

(defun appExp-fun (exp)
  (cdr (assoc 'fun exp)))

(defun appExp-arg (exp)
  (cdr (assoc 'arg exp)))

;;function abstraction
(defun absExp (name body)
  (list
   '(class . absExp)
   (cons 'name name)
   (cons 'body body)))

(defun absExp-p (exp)
  (eq 'absExp  (cdr (assoc 'class exp))))

(defun absExp-name (exp)
  (cdr (assoc 'name exp)))

(defun absExp-body (exp)
  (cdr (assoc 'body exp)))

;;let expression
(defun letExp (decl body)
  (list
   '(class . letExp)
   (cons 'decl decl)
   (cons 'body body)))

(defun letExp-p (exp)
  (eq 'letExp  (cdr (assoc 'class exp))))

(defun letExp-decl (exp)
  (cdr (assoc 'decl exp)))

(defun letExp-body (exp)
  (cdr (assoc 'body exp)))

;;match
(defstruct
  (match
   (:constructor match (mrule)))
  mrule)

(defstruct
  (mrule
   (:constructor mrule (pat exp)))
  pat exp)

;;valBind
(defun valBind (pat exp)
  (list
   '(class . valBind)
   (cons 'pat pat)
   (cons 'exp exp)))

(defun valBind-p (exp)
  (eq 'valBind  (cdr (assoc 'class exp))))

(defun valBind-pat (exp)
  (cdr (assoc 'pat exp)))

(defun valBind-exp (exp)
  (cdr (assoc 'exp exp)))

;;recValBind
(defun recValBind (pat exp)
  (list
   '(class . recValBind)
   (cons 'pat pat)
   (cons 'exp exp)))

(defun recValBind-p (exp)
  (eq 'recValBind  (cdr (assoc 'class exp))))

(defun recValBind-pat (exp)
  (cdr (assoc 'pat exp)))

(defun recValBind-exp (exp)
  (cdr (assoc 'exp exp)))

;;varPat
(defun varPat (name)
  (list
   '(class . varPat)
   (cons 'name name)))

(defun varPat-p (struct)
  (eq 'varPat  (cdr (assoc 'class struct))))

(defun varPat-name (struct)
  (cdr (assoc 'name struct)))

(provide 'lambda-exp)
