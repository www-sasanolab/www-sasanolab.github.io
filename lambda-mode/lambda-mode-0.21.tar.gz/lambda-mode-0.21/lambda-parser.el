(require 'lambda-tokenizer)
(require 'lambda-parser-data)
(require 'lambda-exp)
(require 'lambda-expD)

(defun lambda-parser ()
  (let* (action
	 (tokenizer-pos (init-lambda-tokenizer-status))
	 (token (lambda-tokenizer tokenizer-pos))
	 (loop-flg t)
	 (accept nil)
	 (reduce-seq nil)
	 (stack-symbol nil)
	 (stack (list 0)))
    (while loop-flg
      ;(message (format "ga: token:%s" token))
      (setq action (get-action (get-token-symbol token)))

      ;(print-stack-and-symbol)
      (cond 
       ((eq 'shift (car action))
	;;shift
	;(message (format "shift %s" (cdr action)))
	(stack-symbol-push token)
	(stack-push (cdr action))
	(setq token (lambda-tokenizer tokenizer-pos)))

       ((eq 'reduce (car action))
	;;reduce
	;(message (format "reduce with %s" (cdr action)))
	
	(let ((nonterminal (aref rule-to-nonterminal
				 (cdr action)))
	      (value (let 
			 ((i 0)
			  (poped nil))
		       (while (< i (aref pop-count (cdr action)))
			 (setq poped (cons (car stack-symbol) poped))
			 (setq stack-symbol (cdr stack-symbol))
			 (setq stack (cdr stack))
			 (setq i (+ 1 i)))
		       (do-action (cdr action) poped))))
	  (setq action (get-action nonterminal))
	  (stack-symbol-push (lambda-token nonterminal 0 0 value))

;; 	  (stack-symbol-push (list 
;; 			      (cons 'symbol nonterminal)
;; 			      (cons 'value value)))
	  (stack-push (cdr action))
	  ;(print-stack-and-symbol)
	  ))

       ((eq 'accept (car action))
	(message "accept.")
	(setq accept t)
	(setq loop-flg nil))

       (t
	(message "syntax error.")
	(throw 'error nil)
	(setq loop-flg nil))))
    (if accept (lambda-token-value (car stack-symbol)) nil)))

(defun get-value (args n)
  (if (eq n 1)
      (if (lambda-token-p (car args))
	    (lambda-token-value (car args))
	(car args))
    (get-value (cdr args) (- n 1))))
  

(defun print-stack-and-symbol ()
  ;(message (stack-to-text  stack stack-symbol))
  )

(defun stack-to-text (stack stack-symbol)
  (if (cdr stack)
      (format "%s [%s] %s" 
	      (stack-to-text (cdr stack) (cdr stack-symbol))
	      (if (lambda-token-p (car stack-symbol))
		  (lambda-token-symbol (car stack-symbol))
		(car stack-symbol))
	      (car stack))
    (format "%s" (car stack))))


(defun get-action (token-symbol)
  (aref (aref parser-table (car stack))
	(token-to-index token-symbol)))

(defun token-to-index (token-symbol)
  (cdr (assoc token-symbol token-to-index)))

(defun stack-push (state)
  (setq stack (cons state stack)))

(defun stack-symbol-push (symbol)
  ""
  (setq stack-symbol (cons symbol stack-symbol)))

(defun get-token-symbol (token)
  (lambda-token-symbol token))


(defun do-action (rule-number args)
  (cond 
    ((eq rule-number 0)
     ;;$start := start
    (get-value args 1))
    ((eq rule-number 1)
     ;;start := expd
     (get-value args 1))
    ((eq rule-number 2)
     ;;exp := appexp
     (get-value args 1))
    ((eq rule-number 3)
     ;;exp := FN ID RIGHTARROW exp
     (absExp (get-value args 2) (get-value args 4)))
    ((eq rule-number 4)
     ;;appexp := atexp
    (get-value args 1))
    ((eq rule-number 5)
     ;;appexp := appexp atexp
     (appExp (get-value args 1) (get-value args 2)))
    ((eq rule-number 6)
     ;;atexp := ID
    (varExp (get-value args 1)))
    ((eq rule-number 7)
     ;;atexp := INT
    (intExp (get-value args 1)))
    ((eq rule-number 8)
     ;;atexp := LP exp RP
    (get-value args 2))
    ((eq rule-number 9)
     ;;atexp := LET decseq IN exp END
     (letExp (get-value args 2) (get-value args 4)))
    ((eq rule-number 10)
     ;;decseq := dec decseq
     ;;use cons instead of decseq
     (if (eq nil (get-value args 2))
	 ;;(valDecl (get-value args 1))
	 (list (get-value args 1))
       ;;(decSeq (valDecl (get-value args 1)) (get-value args 2))))
       (cons (get-value args 1) (get-value args 2))))
    ((eq rule-number 11)
     ;;decseq := 
    nil)
    ((eq rule-number 12)
     ;;dec := VAL valbind
     (get-value args 2))
    ((eq rule-number 13)
     ;;valbind := pat EQ exp
     (valBind (varPat (get-value args 1)) (get-value args 3)))
    ((eq rule-number 14)
     ;;valbind := REC valbind
     (let ((arg2 (get-value args 2)))
       (if (and (valBind-p arg2)
		(absExp-p (valBind-exp arg2)))
	   (recValBind (valBind-pat arg2) (valBind-exp arg2))
	 (throw 'error 'let-rec))))
    ((eq rule-number 15)
     ;;pat := ID
     (get-value args 1))
    ((eq rule-number 16)
     ;;expd := appexpd
    (get-value args 1))
    ((eq rule-number 17)
     ;;expd := FN ID RIGHTARROW expd
     (absExpD (get-value args 2) (get-value args 4)))
    ((eq rule-number 18)
     ;;appexpd := atexpd
     (get-value args 1))
    ((eq rule-number 19)
     ;;appexpd := appexp atexpd
     (appExpD (get-value args 1) (get-value args 2)))
    ((eq rule-number 20)
     ;;atexpd := CURSOR
     (cursorExp))
    ((eq rule-number 21)
     ;;atexpd := LP expd
     (parenExpD (get-value args 2)))
    ((eq rule-number 22)
     ;;atexpd := LET decseqd
     (letExp2D (get-value args 2)))
    ((eq rule-number 23)
     ;;atexpd := LET decseq IN expd
     (letExpD (get-value args 2) (get-value args 4)))
    ((eq rule-number 24)
     ;;decseqd := dec decseqd
     ;;use list instead of structure decseq
     ;;(decSeqD (valDecl (get-value args 1)) (get-value args 2)))
     (cons (get-value args 1) (get-value args 2)))
    ((eq rule-number 25)
     ;;decseqd := decd
     ;;(valDeclD (get-value args 1)))
     (get-value args 1))
    ((eq rule-number 26)
     ;;this case does not occur
     ;;decseqd := 
    nil)
    ((eq rule-number 27)
     ;;decd := VAL valbindd
     (list (get-value args 2)))
    ((eq rule-number 28)
     ;;valbindd := pat EQ expd
     (valBindD (varPat (get-value args 1)) (get-value args 3)))
    ((eq rule-number 29)
     ;;valbindd := REC valbindd
     (let ((arg (get-value args 2)))
       (if (and (valBindD-p arg)
		(check-abs (valBindD-expD arg)))
	   (recValBindD (valBindD-pat arg) (valBindD-expD arg))
	 (throw 'error 'let-rec))))))

(defun check-abs (expD)
  (cond
   ((absExpD-p expD)
      t)
   ((parenExpD-p expD)
    (check-abs (parenExpD-expD expD)))
   (t nil)))

(provide 'lambda-parser)
