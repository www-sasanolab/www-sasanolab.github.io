(require 'cl)

(defun remove-duplicate (list)
  (let ((result nil))
    (while (car list)
      (if (not (member (car list) result))
	  (setq result (cons (car list) result)))
      (setq list (cdr list)))
    result))

(defun remove-duplicate-key (list)
  (let ((result nil)
	(keys nil))
    (while (car list)
      (when (not (member (caar list) keys))
	(setq result (cons (car list) result))
	(setq keys (cons (caar list) keys)))
      (setq list (cdr list)))
    result))

(defun empty-set ()
  nil)

(defun singleton-set (elm)
  (list elm))

;;original
(defun set-union (set1 set2)
  (remove-duplicate (append set1 set2)))
;;without remove-duplicate
(defun set-union- (set1 set2)
  (append set1 set2))

(defun map-set (fun set)
  (mapcar fun set))

(defun set-compact (set)
  (if (eq set nil)
      nil
    (if (eq (car set) nil)
	(set-compact (cdr set))
      (cons (car set)
	    (set-compact (cdr set))))))

;; (defun set-compact (set)
;;   (foldl '(lambda (p e)
;; 	    (if (eq e nil)
;; 		p
;; 	      (cons e p)))
;; 	 nil set))

;;���X�g�ƏW�������Ɏg���Ă��܂��Ă��镔��������̂łǂ��ɂ�����ׂ�
(defun foldl (func init lst)
  (let ((ret init))
    (dolist (a lst ret)
      (setq ret (funcall func ret a)))))

(provide 'lambda-common)
