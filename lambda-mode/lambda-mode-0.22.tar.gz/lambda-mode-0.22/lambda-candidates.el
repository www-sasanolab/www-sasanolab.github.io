(require 'lambda-common)
(require 'lambda-type-env)

(defun enum-candidates-from-v-result-set (v-result-set)
  "makes the candidates from v-result-set and return a set of the caondidates"
  (foldl '(lambda (candidates v-result)
	    (let*
		((v-cursor-result (v-result-c v-result))
		 (cursor-env (apply-subst-to-env (v-cursor-result-env v-cursor-result)
						 (v-result-subst v-result)))
		 (cursor-type (apply-subst-to-type (v-cursor-result-type v-cursor-result) 
						   (v-result-subst v-result))))
	      (message "--------------------------------")
	      (message (format  "%s" cursor-env))
	      (message "--------------------------------")
	      (print-env cursor-env)
	      (set-union candidates (enum-candidates cursor-env cursor-type))))
	 (empty-set) v-result-set))


(defun enum-candidates (env cursor-type)
  "return a set of candidates"
  (message (format "cursor type: %s " cursor-type))
  (let*
      ((all-variables (enum-all-keys env)))
    (foldl '(lambda (prev variable)
	      (let* 
		  ((variable-type (instanciate (find-env env variable))))
		(if (catch 'error (unify (singleton-set (cons cursor-type variable-type))))
		    ;;The variable becomes the candidate if the function unify succeeds. 
		    (set-union (singleton-set (cons variable variable-type)) prev)
		  prev)))
	   (empty-set) all-variables)))
(provide 'lambda-candidates)
