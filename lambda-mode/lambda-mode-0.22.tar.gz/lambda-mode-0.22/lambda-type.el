(require 'cl)

;;polymorphic type
;; (defstruct
;;   (polyTy
;;    (:constructor polyTy (tyVarList type)))
;;    tyVarList type)

(defun polyTy (tyVarList type)
  (list
   '(class . polyTy)
   (cons 'tyVarList tyVarList)
   (cons 'type type)))

(defun polyTy-p (struct)
  (eq 'polyTy  (cdr (assoc 'class struct))))

(defun polyTy-tyVarList (struct)
  (cdr (assoc 'tyVarList struct)))

(defun polyTy-type (struct)
  (cdr (assoc 'type struct)))

;;monomorphic type 
;; (defstruct
;;   (intTy
;;    (:constructor intTy)))

(defun intTy ()
  (list
   '(class . intTy)))

(defun intTy-p (struct)
  (eq 'intTy  (cdr (assoc 'class struct))))

(defun stringTy ()
  (list
   '(class . stringTy)))

(defun stringTy-p (struct)
  (eq 'stringTy  (cdr (assoc 'class struct))))

;; (defstruct 
;;   (boolTy
;;    (:constructor boolTy)))
(defun boolTy ()
  (list
   '(class . boolTy)))

(defun boolTy-p (struct)
  (eq 'boolTy  (cdr (assoc 'class struct))))


;; (defstruct
;;   (varTy
;;    (:constructor varTy (name)))
;;    (name))
(defun varTy (name)
  (list
   '(class . varTy)
   (cons 'name name)))

(defun varTy-p (struct)
  (eq 'varTy  (cdr (assoc 'class struct))))

(defun varTy-name (struct)
  (cdr (assoc 'name struct)))



;; (defstruct
;;   (arrowTy
;;    (:constructor arrowTy (arg result)))
;;   arg result)
(defun arrowTy (arg result)
  (list
   '(class . arrowTy)
   (cons 'arg arg)
   (cons 'result result)))

(defun arrowTy-p (struct)
  (eq 'arrowTy  (cdr (assoc 'class struct))))

(defun arrowTy-arg (struct)
  (cdr (assoc 'arg struct)))

(defun arrowTy-result (struct)
  (cdr (assoc 'result struct)))

(provide 'lambda-type)
