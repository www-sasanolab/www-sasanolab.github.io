(require 'cl)

;;function application
(defun appExpD (fun argD)
  (list
   '(type . appExpD)
   (cons 'fun fun)
   (cons 'argD argD)))

(defun appExpD-p (expD)
  (eq 'appExpD (cdr (assoc 'type expD))))

(defun appExpD-fun (expD)
  (cdr (assoc 'fun expD)))

(defun appExpD-argD (expD)
  (cdr (assoc 'argD expD)))

;;if 
(defun ifExpD (condition true falseD)
  (list
   '(class . ifExpD)
   (cons 'cond condition)
   (cons 'true true)
   (cons 'falseD falseD)))

(defun ifExpD-p (exp)
  (eq 'ifExpD  (cdr (assoc 'class exp))))

(defun ifExpD-cond (exp)
  (cdr (assoc 'cond exp)))

(defun ifExpD-true (exp)
  (cdr (assoc 'true exp)))

(defun ifExpD-falseD (exp)
  (cdr (assoc 'falseD exp)))

;;if 2
(defun ifExpD2 (condition trueD)
  (list
   '(class . ifExpD2)
   (cons 'cond condition)
   (cons 'trueD trueD)))


(defun ifExpD2-p (exp)
  (eq 'ifExpD2  (cdr (assoc 'class exp))))

(defun ifExpD2-cond (exp)
  (cdr (assoc 'cond exp)))

(defun ifExpD2-trueD (exp)
  (cdr (assoc 'trueD exp)))

;;if 3
(defun ifExpD3 (conditionD)
  (list
   '(class . ifExpD3)
   (cons 'condD conditionD)))

(defun ifExpD3-p (exp)
  (eq 'ifExpD3  (cdr (assoc 'class exp))))

(defun ifExpD3-condD (exp)
  (cdr (assoc 'condD exp)))

;;function abstraction
(defun absExpD (name bodyD)
  (list
   '(class . absExpD)
   (cons 'name name)
   (cons 'bodyD bodyD)))

(defun absExpD-p (expD)
  (eq 'absExpD  (cdr (assoc 'class expD))))

(defun absExpD-name (expD)
  (cdr (assoc 'name expD)))

(defun absExpD-bodyD (expD)
  (cdr (assoc 'bodyD expD)))

;;let expresiion 
(defun letExpD (decl bodyD)
  (list
   '(class . letExpD)
   (cons 'decl decl)
   (cons 'bodyD bodyD)))

(defun letExpD-p (expD)
  (eq 'letExpD  (cdr (assoc 'class expD))))

(defun letExpD-decl (expD)
  (cdr (assoc 'decl expD)))

(defun letExpD-bodyD (expD)
  (cdr (assoc 'bodyD expD)))

;;let expression that does not have body 
(defun letExp2D (declD)
  (list
   '(class . letExp2D)
   (cons 'declD declD)))

(defun letExp2D-p (expD)
  (eq 'letExp2D  (cdr (assoc 'class expD))))

(defun letExp2D-declD (expD)
  (cdr (assoc 'declD expD)))

;;parenthesis expression
(defun parenExpD (expD)
  (list
   '(class . parenExpD)
   (cons 'expD expD)))

(defun parenExpD-p (exp)
  (eq 'parenExpD  (cdr (assoc 'class exp))))

(defun parenExpD-expD (exp)
  (cdr (assoc 'expD exp)))

;;cursor expression
(defun cursorExp ()
  (list
   '(class . cursorExp)))

(defun cursorExp-p (expD)
  (eq 'cursorExp  (cdr (assoc 'class expD))))

;;mark expression 
(defun markExp (expD)
  (list
   '(class . markExp)
   (cons 'expD expD)))

(defun markExp-p (exp)
  (eq 'markExp  (cdr (assoc 'class exp))))

(defun markExp-expD (exp)
  (cdr (assoc 'expD exp)))

;;valBind
(defun valBindD (pat expD)
  (list
   '(class . valBindD)
   (cons 'pat pat)
   (cons 'expD expD)))

(defun valBindD-p (expD)
  (eq 'valBindD  (cdr (assoc 'class expD))))

(defun valBindD-pat (expD)
  (cdr (assoc 'pat expD)))

(defun valBindD-expD (expD)
  (cdr (assoc 'expD expD)))

;;recursive declaration
(defun recValBindD (pat expD)
  (list
   '(class . recValBindD)
   (cons 'pat pat)
   (cons 'expD expD)))

(defun recValBindD-p (expD)
  (eq 'recValBindD  (cdr (assoc 'class expD))))

(defun recValBindD-pat (expD)
  (cdr (assoc 'pat expD)))

(defun recValBindD-expD (expD)
  (cdr (assoc 'expD expD)))


(provide 'lambda-expD)

