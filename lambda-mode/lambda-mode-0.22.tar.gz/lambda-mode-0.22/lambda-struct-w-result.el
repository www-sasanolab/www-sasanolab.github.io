;; (defstruct
;;   (w-result 
;;    (:constructor w-result (subst type)))
;;   subst type)

;; (defstruct
;;   (w-decl-result
;;    (:constructor w-decl-result (subst env)))
;;    subst env)

;; (defstruct
;;   (w-valBind-result
;;    (:constructor w-valBind-result (subst env)))
;;    subst env)

(defun w-result (subst type)
  (list
   '(class . w-result)
   (cons 'subst subst)
   (cons 'type type)))

(defun w-result-p (struct)
  (eq 'w-result  (cdr (assoc 'class struct))))

(defun w-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun w-result-type (struct)
  (cdr (assoc 'type struct)))


;;w-decl-result
(defun w-decl-result (subst env)
  (list
   '(class . w-decl-result)
   (cons 'subst subst)
   (cons 'env env)))

(defun w-decl-result-p (struct)
  (eq 'w-decl-result  (cdr (assoc 'class struct))))

(defun w-decl-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun w-decl-result-env (struct)
  (cdr (assoc 'env struct)))

;;w-valBind-result
(defun w-valBind-result (subst env)
  (list
   '(class . w-valBind-result)
   (cons 'subst subst)
   (cons 'env env)))

(defun w-valBind-result-p (struct)
  (eq 'w-valBind-result  (cdr (assoc 'class struct))))

(defun w-valBind-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun w-valBind-result-env (struct)
  (cdr (assoc 'env struct)))

(provide 'lambda-struct-w-result)