
(defun tokenizer-error-message (text)
  (message text))


;; (defstruct
;;   (lambda-tokenizer-status
;;    (:constructor init-lambda-tokenizer-status ()))
;;   (pos (point-min))
;;   (eof (point))
;;   (tokenizer-reached-eof nil)
;;   token)

(defun init-lambda-tokenizer-status ()
  (list
   (cons 'eof (point))
   (cons 'tokenizer-reached-eof  nil)
   (cons 'pos (point-min))
   (cons 'token nil)))

(defun lambda-tokenizer-status-p (struct)
  (eq 'lambda-tokenizer-status  (cdr (assoc 'class struct))))

(defun lambda-tokenizer-status-eof (struct)
  (cdr (assoc 'eof struct)))

(defun lambda-tokenizer-status-tokenizer-reached-eof (struct)
  (cdr (assoc 'tokenizer-reached-eof struct)))

(defun lambda-tokenizer-status-token (struct)
  (cdr (assoc 'token struct)))

(defun lambda-tokenizer-status-pos (struct)
  (cdr (assoc 'pos struct)))


;; (defstruct
;;   (lambda-token
;;    (:constructor lambda-token (symbol right left &optional value)))
;;   symbol right left value)

(defun lambda-token (symbol left right &optional value)
  (list
   '(class . lambda-token)
   (cons 'symbol symbol)
   (cons 'value value)
   (cons 'left left)
   (cons 'right right)))

(defun lambda-token-p (struct)
  (eq 'lambda-token  (cdr (assoc 'class struct))))

(defun lambda-token-symbol (struct)
  (cdr (assoc 'symbol struct)))

(defun lambda-token-value (struct)
  (cdr (assoc 'value struct)))

(defun lambda-token-left (struct)
  (cdr (assoc 'left struct)))

(defun lambda-token-right (struct)
  (cdr (assoc 'right struct)))


(defmacro define-tokenizer 
  (name conditions variables &rest rules)
  (defvar lexer-condition 'INITIAL)
  (let ((--dt-variables variables))
    (while (car --dt-variables)
      (if (not (listp (car --dt-variables)))
	  (set (car --dt-variables) nil)
	(set (car (car  --dt-variables)) (car (cdr (car --dt-variables)))))
      (setq --dt-variables (cdr --dt-variables))))
  (let ((process-list '())
	(rules rules)
	rule)
    (while (car rules)
      (setq rule (car rules))
      (setq process-list (cons
			  `((and 
				  (eq lexer-status (quote ,(car rule)))
				  (looking-at ,(car (cdr rule))))
			    (setq yypos (match-beginning 0))
			    (setq yytext (match-string-no-properties 0))
			    ,@(cdr (cdr rule)))
			  process-list))
      (setq rules (cdr rules)))
    (setq process-list (list (cons 'cond (reverse process-list))))
    
    `(defun ,name (tokenizer &optional condition)
       (let ((lexer-rules ',rules)
	     yybegin yytext yypos (token nil)
	     (continue t) return 
	     (eof (lambda-tokenizer-status-eof tokenizer))
	     (lexer-status (if condition condition 'INITIAL)))
	 (goto-char (lambda-tokenizer-status-pos tokenizer))
	 (fset 'return (lambda (s l r &optional v) (setq token (lambda-token s l r v))))
	 (fset 'yybegin (lambda (status) (setq lexer-status status)))
	 (fset 'continue (lambda () (setq continue t) (goto-char (match-end 0))))
	 
	 (if (lambda-tokenizer-status-tokenizer-reached-eof tokenizer) 
	     (return '$EOF eof eof)
	   (while (and 
		   continue 
		   (< (point) eof ))
	     (setq continue nil)
	     ,@process-list)
	   (setcdr (assoc 'pos  tokenizer) (match-end 0))
	   ;;cursor expression
	   (when (>= (point) eof)
	     (setcdr (assoc 'tokenizer-reached-eof tokenizer) t)
	     (return 'CURSOR eof eof nil)))
	 token))))

(provide 'tokenizer-macro)










