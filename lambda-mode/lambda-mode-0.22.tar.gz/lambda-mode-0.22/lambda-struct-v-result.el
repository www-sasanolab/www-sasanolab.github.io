;; (defstruct
;;   (v-result
;;    (:constructor v-result (subst type c)))
;;   subst type c)

;; (defstruct
;;   (v-decl-result
;;    (:constructor v-decl-result (subst env c)))
;;    subst env c)

;; (defstruct
;;   (v-valBind-result
;;    (:constructor v-valBind-result (subst env c)))
;;    subst env c)

;; (defstruct
;;   (v-cursor-result
;;    (:constructor v-cursor-result (env type)))
;;   env type)
(defun v-result (subst type c)
  (list
   '(class . v-result)
   (cons 'subst subst)
   (cons 'type type)
   (cons 'c c)))

(defun v-result-p (struct)
  (eq 'v-result  (cdr (assoc 'class struct))))

(defun v-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun v-result-type (struct)
  (cdr (assoc 'type struct)))

(defun v-result-c (struct)
  (cdr (assoc 'c struct)))

;;v-decl-result
(defun v-decl-result (subst env c)
  (list
   '(class . v-decl-result)
   (cons 'subst subst)
   (cons 'env env)
   (cons 'c c)))

(defun v-decl-result-p (struct)
  (eq 'v-decl-result  (cdr (assoc 'class struct))))

(defun v-decl-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun v-decl-result-env (struct)
  (cdr (assoc 'env struct)))

(defun v-decl-result-c (struct)
  (cdr (assoc 'c struct)))

;;v-valBind-result
(defun v-valBind-result (subst env c)
  (list
   '(class . v-valBind-result)
   (cons 'subst subst)
   (cons 'env env)
   (cons 'c c)))

(defun v-valBind-result-p (struct)
  (eq 'v-valBind-result  (cdr (assoc 'class struct))))

(defun v-valBind-result-subst (struct)
  (cdr (assoc 'subst struct)))

(defun v-valBind-result-env (struct)
  (cdr (assoc 'env struct)))

(defun v-valBind-result-c (struct)
  (cdr (assoc 'c struct)))

;;v-cursor-result
(defun v-cursor-result (env type)
  (list
   '(class . v-cursor-result)
   (cons 'env env)
   (cons 'type type)))

(defun v-cursor-result-p (struct)
  (eq 'v-cursor-result  (cdr (assoc 'class struct))))

(defun v-cursor-result-env (struct)
  (cdr (assoc 'env struct)))

(defun v-cursor-result-type (struct)
  (cdr (assoc 'type struct)))

(provide 'lambda-struct-v-result)