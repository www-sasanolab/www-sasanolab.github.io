;;; lambda-complete.el --- Auto completion

;; Copyright (C) 2008, 2009  MATSUYAMA Tomohiro

;; Author: MATSUYAMA Tomohiro <t.matsuyama.pub@gmail.com>
;; Keywords: convenience
;; Version: 0.3.0 alpha

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; This extension provides a way to complete with popup menu like:
;;
;;     def-!-
;;     +-----------------+
;;     |defun::::::::::::|
;;     |defvar           |
;;     |defmacro         |
;;     |       ...       |
;;     +-----------------+
;;
;; You can complete by typing and selecting menu.
;; Enjoy!

;;; Qualification:
;;
;; This extension can work properly on GNU Emacs 22 or higher.

;;; Installation:
;;
;; To use this extension, locate lambda-complete.el to your load-path directory.
;;
;;     $ cp lambda-complete.el ~/.emacs.d/
;;
;; And write following code into your .emacs.
;;
;;     (require 'lambda-complete)
;;     (global-lambda-complete-mode t)

;;; Tips:
;;
;; Use C-n/C-p to select candidates
;; --------------------------------
;;
;; Add following code to your .emacs.
;; 
;;     (define-key lc-complete-mode-map "\C-n" 'lc-next)
;;     (define-key lc-complete-mode-map "\C-p" 'lc-previous)
;;
;;
;; Don't start completion automatically
;; ------------------------------------
;;
;; Add following code to your .emacs.
;;
;;     (setq lc-auto-start nil)
;;     (global-set-key "\M-/" 'lc-start)
;;
;; or
;;
;;     ;; start completion when entered 3 characters
;;     (setq lc-auto-start 3)
;;
;;
;; Stop completion
;; ---------------
;;
;; Add following code to your .emacs.
;;
;;     (define-key lc-complete-mode-map "\M-/" 'lc-stop)
;;
;; Now you can stop completion by pressing M-/.
;;
;;
;; Completion by TAB
;; -----------------
;;
;; Add following code to your .emacs.
;;
;;     (define-key lc-complete-mode-map "\t" 'lc-complete)
;;     (define-key lc-complete-mode-map "\r" nil)
;;
;;
;; Do What I Mean mode
;; -------------------
;;
;; If DWIM (Do What I Mean) mode is enabled,
;; the following features is available:
;;
;; a. TAB (lc-expand) behave as completion (lc-complete)
;;    when only one candidate is left
;; b. TAB (lc-expand) behave as completion (lc-complete)
;;    after you select candidate
;; c. Disapear automatically when you
;;    complete a candidate.
;;
;; DWIM mode is enabled by default.
;; You can enable this feature by
;; setting `lc-dwim' to t.
;;
;;     (setq lc-dwim t)
;;
;;
;; Change default sources
;; ----------------------
;;
;;     (setq-default lc-sources '(lc-source-abbrev lc-source-words-in-buffer))
;;
;;
;; Change sources for particular mode
;; ----------------------------------
;;
;;     (add-hook 'emacs-lisp-mode-hook
;;                 (lambda ()
;;                   (setq lc-sources '(lc-source-words-in-buffer lc-source-symbols))))

;;; History:
;;
;; 2009-06-21
;;      * fixed lc-source-words-in-all-buffer didn't collect all words in current buffer
;;      * added inline completion feature
;;
;; 2009-06-14
;;      * suppress wasting undo recording when expand (based on a patch from Vitaly Ostanin <vitaly.ostanin@gmail.com>)
;;      * fixed disrupted menu on long line (based on a patch from Vitaly Ostanin <vitaly.ostanin@gmail.com>)
;;
;; 2009-03-18
;;      * lambda-complete.el 0.2.0 released
;;
;; 2009-03-04
;;      * fixed menu position bug
;;
;; 2009-03-02
;;      * made a source be able to be just a function which returns candidates
;;      * added lc-source-words-in-all-buffer
;;
;; 2009-03-01
;;      * added basic cache facility
;;
;; 2009-02-20
;;      * fixed menu position bug at long line (thanks rubikitch <rubikitch@ruby-lang.org>)
;;      * made dictionary source generator (lc-define-dictionary-source)
;;      * devided into some files (lambda-complete-ruby.el, lambda-complete-yasnippet.el, etc)
;;
;; 2009-02-19
;;      * added lc-trigger-commands switch
;;
;; 2009-02-10
;;      * added lc-stop function (suggestion from Andy Stewart)
;;      * added lc-override-local-map switch (suggestion from Andy Stewart)
;;
;; 2009-02-03
;;      * omni completion redesign
;;      * lc-sources is now buffer local for every buffer
;;      * fixed a menu position bug (thanks Andy Stewart)
;;      * fixed byte-compile warnings (thanks Andy Stewart)
;;
;; 2009-01-22
;;      * added face/selection-face property for sources
;;      * supported menu scroll
;;
;; 2009-01-20
;;      * omni completion
;;
;; 2008-12-24
;;      * suppress errors on command hook
;;
;; 2008-12-03
;;      * changed lc-dwim to nil by default
;;      * made menu to be able to adjust width
;;
;; 2008-12-03
;;      * renamed lc-find-function to lc-prefix-function
;;      * renamed lc-target to lc-prefix
;;
;; 2008-11-26
;;      * lambda-complete.el 0.1.0 released
;;
;; 2008-11-19
;;      * thanks for Taiki SUGAWARA <buzz.taiki@gmail.com>
;;      *   added source lc-source-abbrev
;;      *   added source lc-source-symbols
;;      * added lc-expand-common to expand common part
;;
;; 2008-11-18
;;      * added lc-auto-start switch
;;      * added lc-dwim switch
;;      * changed menu popup behavior at end of window
;;      *   thanks rubikitch <rubikitch@ruby-lang.org>, kazu-yamamoto.
;;      * fixed canceler bug
;;      * changed to use overriding-local-map instead of minor mode map
;;      * changed default key bindings
;;
;; 2008-11-16
;;      * supported candidates by using sources
;;      * added automatically start swtich
;;      * fixed some bug
;;      * added source lc-source-files-in-current-dir
;;      * added source lc-source-words-in-buffer
;;      * added source lc-source-yasnippet
;;      * renamed lc-enum-candidates-function to lc-candidate-function
;;      * renamed lc-find-target-function to lc-find-function
;;      * lc-find-function and lc-candidate-function is not buffer local variable now
;;      * made candidates visible when you are end of line
;;
;; 2008-11-11
;;      * by reporting from rubikitch <rubikitch@ruby-lang.org>
;;      *   renamed hook name
;;      *   registered backward-delete-char as special command
;;      * fixed code for creating candidates
;;      * made lambda-complete disabled when isearch-mode enabled
;;      * added some major-mode into lc-modes
;;
;; 2008-11-09
;;      * lambda-complete.el 0.0.1 released
;;      * fixed double-width character displaying problem
;;      * fixed menu position following tab character
;;      * made candidates visible when you are end of window

;;; TODO:
;;
;; - etags, ctags
;; - emacswiki
;; - test facility
;; - support composed chars
;; - fuzzy match
;; - minibuffer completion (50%)
;; - dictionary
;; - documentation
;; - performance issue (cache issue)
;; - fix narrowing bug (reported by Yuto Hayamizu <y.hayamizu@gmail.com>)
;; - scroll bar (visual)
;; - show description
;; - semantic
;; - use cl
;; - icon
;; - refactoring (especially menu)
;; - linum.el bug (reported by Andy Stewart)
;; - flymake bug (reported by TiagoCamargo)

;;; Code:



(eval-when-compile
  (require 'cl))

(defgroup lambda-complete nil
  "Auto completion"
  :group 'convenience
  :prefix "lc-")

(defcustom lc-candidate-menu-height 10
  "Max height of candidate menu."
  :type 'number
  :group 'lambda-complete)

(defcustom lc-candidate-limit 10
  "Limit number of candidates."
  :type 'number
  :group 'lambda-complete)
(defvaralias 'lc-candidate-max 'lc-candidate-limit)

(defcustom lc-modes
  '(lambda-mode)
  "Major modes `lambda-complete-mode' can run on."
  :type '(list symbol)
  :group 'lambda-complete)

(defcustom lc-trigger-commands
  '(self-insert-command)
  "Trigger commands that specify whether `lambda-complete' should start or not."
  :type '(list symbol)
  :group 'lambda-complete)

(defcustom lc-auto-start t
  "Non-nil means completion will be started automatically.
Positive integer means if a length of a word you entered is larger than the value,
completion will be started automatically.
If you specify `nil', never be started automatically."
  :group 'lambda-complete)

(defcustom lc-dwim nil
  "Non-nil means `lambda-complete' works based on Do What I Mean."
  :type 'boolean
  :group 'lambda-complete)

(defcustom lc-override-local-map nil
  "Non-nil mean use `lc-complete-mode-map' override local map.
Please set it to non-nil only if you faced to some problem about 
minor-mode keymap conflicts."
  :type 'boolean
  :group 'lambda-complete)

(defface lc-completion-face
  '((t (:background "darkblue" :foreground "white")))
  "Face for inline completion"
  :group 'lambda-complete)

(defface lc-candidate-face
  '((t (:background "lightgray" :foreground "black")))
  "Face for candidate."
  :group 'lambda-complete)

(defface lc-selection-face
  '((t (:background "blue" :foreground "white")))
  "Face for selected candidate."
  :group 'lambda-complete)

(defvar lambda-complete-mode-hook nil
  "Hook for `lambda-complete-mode'.")

(defvar lc-completion-overlay nil
  "Overlay of showing inline completion.")

(defvar lc-menu nil
  "Menu instance.")

(defvar lc-menu-direction 1
  "Positive integer means `lc-menu' grows forward.
Or, `lc-menu' grows backward.")

(defvar lc-menu-offset 0
  "Offset to contents.")

(defvar lc-menu-scroll 0
  "Scroll top of `lc-menu'.")

(defvar lc-completing nil
  "Non-nil means `lambda-complete-mode' is now working on completion.")

(defvar lc-saved-window-start nil
  "Saved window start value for restore.")

(defvar lc-saved-window-hscroll nil
  "Saved window hscroll value for restore.")

(defvar lc-buffer nil
  "A buffer where lambda-complete is started.")

(defvar lc-point nil
  "Start point of prefix.")

(defvar lc-old-point nil
  "Previous start point of prefix.")

(defvar lc-prefix nil
  "Prefix.")
(defvaralias 'lc-target 'lc-prefix)

(defvar lc-limit 0
  "Limit number of candidates.")

(defvar lc-candidates nil
  "Current candidates.")

(defvar lc-selection nil
  "Current candidate index.")

(defvar lc-dwim-enable nil
  "Non-nil means DWIM completion will be allowed.")

(defvar lc-setup-function 'lc-sources-setup
  "This function will be called when `lambda-complete-mode' is enabled.")

(defvar lc-prefix-function 'lc-sources-prefix
  "When `lambda-complete-mode' finds it can start completion
or update candidates, it will call this function to find a
start point of the prefix.

If this function returns a point `lambda-complete-mode'
will set the substring between the point and current point to `lc-prefix'.
And also it will start completion or update candidates by using
the `lc-prefix'.

If this function returns `nil', `lambda-complete-mode'
ignore starting completion or stop completing.")
(defvaralias 'lc-find-function 'lc-prefix-function)

(defvar lc-init-function 'lc-sources-init
  "This function will be called when candidate menu is setupped.")

(defvar lc-cleanup-function 'lc-sources-cleanup
  "This function will be called when candidate menu is cleanupped")

(defvar lc-candidate-function 'lc-sources-candidate
  "This function can return candidates as list by
using the `TARGET' that is given as a first argument.")

(defvar lc-candidate-filter-function 'lc-adaptive-candidate-filter
  "This function filters candidates and returns new candidates
to be shown.")

(defvar lc-complete-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map "\t" 'lc-expand)
    (define-key map "\r" 'lc-complete)
    
    (define-key map [down] 'lc-next)
    (define-key map [up] 'lc-previous)

    map)
  "Keymap for completion.")

(defvar lc-saved-local-map nil
  "Old keymap before `lambda-complete' activated.")



;;;; Auto completion

(defun lc-setup (menu-width)
  "Setup completion UI at current position."
  ;; Setup menu completion UI
  (when lc-menu
    ;; Reposition
    (lc-menu-delete lc-menu)
    (setq lc-menu nil))
  (save-excursion
    (goto-char lc-point)
    (let ((current-visual-column (lc-current-physical-column))
          (menu-column (current-column))
          (line (line-number-at-pos))
          (height 1))
      (setq lc-saved-window-start (window-start))
      (setq lc-saved-window-hscroll (window-hscroll))
      (setq height lc-candidate-menu-height)
      (setq lc-menu-direction
            (if (and (> line height)
                     (> height
                        (-
                         (max 1 (- (window-height)
                                   (if mode-line-format 1 0)
                                   (if header-line-format 1 0)))
                         (count-lines (window-start) lc-point))))
                -1
              1))
      (let ((window-width (window-width))
            (right (- (+ current-visual-column menu-width)
                      (window-hscroll))))
        (if (and (> right window-width)
                 (>= right menu-width)
                 (>= current-visual-column menu-width))
            (setq menu-column (- menu-column menu-width))))
      ;; Make a room to show menu at the end of buffer
      (forward-line 1)
      (if (eq line (line-number-at-pos))
          (newline)
        (forward-line -1))
      (setq lc-menu (lc-menu-create line menu-column menu-width height lc-menu-direction)))))

(defun lc-cleanup ()
  "Destroy popup menu."
  (lc-deactivate-mode-map)
  (lc-completion-delete)
  (when lc-menu
    (lc-menu-delete lc-menu)
    (set-window-start (selected-window) lc-saved-window-start)
    (set-window-hscroll (selected-window) lc-saved-window-hscroll))
  (setq lc-menu nil)
  (setq lc-menu-scroll 0)
  (setq lc-completing nil)
  (setq lc-point nil)
  (setq lc-candidates nil)
  (setq lc-selection 0)
  (setq lc-selection-scroll-top 0)
  (funcall lc-cleanup-function))

(defun lc-activate-mode-map ()
  "Activate `lc-complete-mode-map'."
  (if lc-override-local-map
      (progn
        (setq lc-saved-local-map overriding-terminal-local-map)
        (if (eq lc-saved-local-map lc-complete-mode-map)
            ;; Maybe never reach here
            (setq lc-saved-local-map nil))
        (setq overriding-terminal-local-map lc-complete-mode-map))
    ;; Rearrange lc-mode-map pair first
    (assq-delete-all 'lc-completing minor-mode-map-alist)
    (push (cons 'lc-completing lc-complete-mode-map) minor-mode-map-alist)))

(defun lc-deactivate-mode-map ()
  "Deactivate `lc-complete-mode-map'."
  (when (and lc-override-local-map
             (eq overriding-terminal-local-map lc-complete-mode-map))
    (setq overriding-terminal-local-map lc-saved-local-map)
    (setq lc-saved-local-map nil)))

(defun lc-next ()
  "Select next candidate."
  (interactive)
  (if (interactive-p)
      (setq lc-dwim-enable t))
  (if lc-candidates
      (lc-select-candidate
       (let ((selection (1+ lc-selection)))
         (if (= selection (+ lc-menu-offset (min (lc-menu-height lc-menu) (length lc-candidates))))
             (if (< (+ (- lc-selection lc-menu-offset) lc-menu-scroll) (1- (length lc-candidates)))
                 (prog1 lc-selection
                   (setq lc-menu-scroll (1+ lc-menu-scroll))
                   (lc-redraw-candidates))
               (setq lc-menu-scroll 0)
               (lc-redraw-candidates)
               lc-menu-offset)
           selection)))))

(defun lc-previous ()
  "Select previous candidate."
  (interactive)
  (if (interactive-p)
      (setq lc-dwim-enable t))
  (if lc-candidates
      (lc-select-candidate
       (let ((selection (1- lc-selection)))
         (if (< selection lc-menu-offset)
             (if (= lc-menu-scroll 0)
                 (prog1 (1- (+ lc-menu-offset (min (lc-menu-height lc-menu) (length lc-candidates))))
                   (setq lc-menu-scroll (- (length lc-candidates) (min (lc-menu-height lc-menu) (length lc-candidates))))
                   (lc-redraw-candidates))
               (setq lc-menu-scroll (1- lc-menu-scroll))
               (lc-redraw-candidates)
               lc-selection)
           selection)))))

(defun lc-expand-string (string &optional remove-undo-boundary)
  "Expand `STRING' into the buffer and update `lc-prefix' to `STRING'.
This function records deletion and insertion sequences by `undo-boundary'.
If `remove-undo-boundary' is non-nil, this function also removes `undo-boundary'
that have been made before in this function."
  (undo-boundary)
  ;; We can't use primitive-undo since it undoes by
  ;; groups, divided by boundaries.
  ;; We don't want boundary between deletion and insertion.
  ;; So do it manually.
  ;; Delete region silently for undo:
  (if remove-undo-boundary
      (progn
        (let (buffer-undo-list)
          (save-excursion
            (delete-region lc-point (point))))
        (setq buffer-undo-list
              (nthcdr 2 buffer-undo-list)))
    (delete-region lc-point (point)))
  (insert string)
  ;; Sometimes, possible when omni-completion used, (insert) added
  ;; to buffer-undo-list strange record about position changes.
  ;; Delete it here:
  (when (and remove-undo-boundary
             (integerp (cadr buffer-undo-list)))
    (setcdr buffer-undo-list (nthcdr 2 buffer-undo-list)))
  (undo-boundary)
  (setq lc-prefix string))

(defun lc-expand ()
  "Try expansion but select next if expanded twice."
  (interactive)
  (if (and lc-dwim lc-dwim-enable)
      (lc-complete)
    (let ((old-prefix lc-prefix)
          (repeated (eq last-command this-command))
          string)
      (setq string (or
                    (and lc-completion-overlay
                         (prog1 (setq string
                                      (concat lc-prefix
                                              (overlay-get lc-completion-overlay 'string)))
                           (lc-completion-delete)))
                    (lc-get-selected-candidate)))
      (when (equal old-prefix string)
        (lc-next)
        (setq string (lc-get-selected-candidate)))
      (lc-expand-string string repeated)))
  ;; Do reposition if menu at long line
  (when (lc-menu-at-wrapped-line)
    (lc-setup (lc-menu-width lc-menu))
    (lc-redraw-candidates)))

(defun lc-expand-common ()
  "Try expansion common part."
  (interactive)
  (let ((common (try-completion lc-prefix lc-candidates))
        (buffer-undo-list t))
    (when (stringp common)
      (delete-region lc-point (point))
      (insert common)
      (setq lc-prefix common))))

(defun lc-complete ()
  "Try completion."
  (interactive)
  (let* ((candidate (lc-get-selected-candidate))
         (action (lc-get-candidate-action candidate)))
    (lc-expand-string candidate)
    (if action
        (funcall action))
    (lc-abort)))

(defun lc-abort ()
  "Abort completion."
  (lc-cleanup))

(defun lc-stop ()
  "Stop completiong."
  (interactive)
  (lc-abort))

(defun lc-redraw-candidates ()
  "Redraw the menu contents."
  ;; Show inline completion.
  (let ((string (try-completion lc-prefix lc-candidates)))
    (if (and (stringp string)
             (> (length string) (length lc-prefix)))
        (lc-completion-show (point) (substring string (length lc-prefix)))
      (lc-completion-delete)))
  
  ;; Show menu completion
  (let ((i lc-menu-offset))
    ;; Show line and set string to the line.
    (mapc
     (lambda (candidate)
       (when (< i (lc-menu-height lc-menu))
         (lc-menu-show-line lc-menu i)
         (lc-menu-set-line-string lc-menu i candidate
                                  (if (= i lc-selection)
                                      (or (lc-get-candidate-property 'selection-face candidate) 'lc-selection-face)
                                    (or (lc-get-candidate-property 'candidate-face candidate) 'lc-candidate-face)))
         (setq i (1+ i))))
     (nthcdr lc-menu-scroll lc-candidates))
    ;; If only one candidate is remaining,
    ;; make the candidate menu disappeared.
    ;(if (eq (- (length lc-candidates) lc-menu-scroll) 1)
    ;    (lc-menu-hide-line lc-menu lc-menu-offset))
    ;; Ensure lines visible
    (if (and (> lc-menu-direction 0)
             (> i (-
                   (max 1 (- (window-height)
                             (if mode-line-format 1 0)
                             (if header-line-format 1 0)))
                   (count-lines (window-start) (point)))))
        (recenter (- (1+ i))))
    ;; Scroll horizontally due to make sure menu is visible.
    ;(if (> i lc-menu-offset)
    ;    (let ((window-width (window-width))
    ;          (right (- (+ (lc-menu-column lc-menu) (lc-menu-width lc-menu))
    ;                    (window-hscroll))))
    ;      (if (> right window-width)
    ;          (scroll-left (- right window-width)))))

    ;; Hide remaining lines
    (if (> lc-menu-direction 0)
        (while (< i (lc-menu-height lc-menu))
          (lc-menu-hide-line lc-menu i)
          (setq i (1+ i)))
      (dotimes (i lc-menu-offset)
        (lc-menu-hide-line lc-menu i)))))

(defun lc-update-candidates (candidates)
  (setq lc-menu-offset (if (> lc-menu-direction 0)
                           0
                         (- (lc-menu-height lc-menu)
                            (min (lc-menu-height lc-menu)
                                 (length candidates)))))
  (setq lc-selection lc-menu-offset)
  (setq lc-candidates candidates)
  (setq lc-dwim-enable (= (length candidates) 1))
  (if candidates
      (progn
        (setq lc-completing t)
        (lc-activate-mode-map))
    (setq lc-completing nil)
    (lc-deactivate-mode-map))
  (lc-redraw-candidates))

(defun lc-get-selected-candidate ()
  (overlay-get (lc-menu-line-overlay lc-menu lc-selection) 'real-string))

(defun lc-get-candidate-action (candidate)
  (lc-get-candidate-property 'action candidate))

(defun lc-propertize-candidate (candidate &rest properties)
  (apply 'propertize candidate properties))

(defun lc-get-candidate-property (prop candidate)
  (get-text-property 0 prop candidate))

(defun lc-select-candidate (selection)
  "Select candidate pointed by `SELECTION'."
  (when lc-candidates
    (let ((c1 (nth (+ (- lc-selection lc-menu-offset) lc-menu-scroll) lc-candidates))
          (c2 (nth (+ (- selection lc-menu-offset) lc-menu-scroll) lc-candidates)))
      (lc-menu-set-line-string lc-menu lc-selection c1
                               (or (lc-get-candidate-property 'candidate-face c1)
                                   'lc-candidate-face))
      (lc-menu-set-line-string lc-menu selection c2
                               (or (lc-get-candidate-property 'selection-face c2)
                                   'lc-selection-face))
      (setq lc-selection selection))))

(defun lc-start ()
  "Start completion."
  (interactive)
  (let* ((point (save-excursion (funcall lc-prefix-function)))
         (reposition (or (not (equal lc-point point))
                         ;; If menu direction is positive and next visual line belongs
                         ;; to same buffer line, then need reposition
                         (and (> lc-menu-direction 0)
                              (lc-menu-at-wrapped-line)))))
    (if (null point)
        (lc-abort)
      (setq lc-buffer (current-buffer))
      (setq lc-point point)
      (when (not (equal lc-point lc-old-point))
        (setq lc-old-point point))
      (setq lc-prefix (buffer-substring-no-properties point (point)))
      (setq lc-limit lc-candidate-limit)
      (if (or reposition (null lc-menu))
          (save-excursion
            (funcall lc-init-function)))
      (let (candidates
            width
            (current-width (if lc-menu (lc-menu-width lc-menu) 0)))
        (setq candidates (if (or lc-completing
                                 (not (integerp lc-auto-start))
                                 (>= (length lc-prefix) lc-auto-start))
                             (save-excursion
                               (funcall lc-candidate-function))))
        (if lc-candidate-filter-function
            (setq candidates (funcall lc-candidate-filter-function candidates)))
        (setq width (let ((w '(0)) s)
                      (dotimes (i lc-candidate-menu-height)
                        (setq s (nth i candidates))
                        (if (stringp s) (push (string-width s) w)))
                      (apply 'max w)))
        (if (or reposition
                (null lc-menu)
                (> width current-width)
                (< width (- current-width 10)))
            (lc-setup (* (ceiling (/ width 10.0)) 10)))
        (lc-update-candidates candidates)))))

(defun lc-adaptive-candidate-filter (candidates)
  "Filter candidates according to length and history (not yet)."
  ;(if (> (length candidates) 1)
  ;    (let ((length (length lc-prefix)))
  ;      (delq nil
  ;            (mapcar (lambda (candidate)
  ;                      (if (> (- (length candidate) length) 2)
  ;                          candidate))
  ;                    candidates)))
  ;  candidates)
  candidates)

(defun lc-trigger-command-p ()
  "Return non-nil if `this-command' is a trigger command."
  (or (memq this-command lc-trigger-commands)
      (and lc-completing
           (memq this-command
                 '(delete-backward-char
                   backward-delete-char
                   backward-delete-char-untabify)))))

(defun lc-current-physical-column ()
  "Current physical column. (not logical column)"
  (- (current-column) (save-excursion (vertical-motion 0) (current-column))))

(defun lc-menu-at-wrapped-line ()
  "Return non-nil if current line is long and wrapped to next visual line."
  (eq (line-number-at-pos)
      (save-excursion
        (vertical-motion 1)
        (line-number-at-pos))))

(defun lc-handle-pre-command ()
  (condition-case var
      (if (or (lc-trigger-command-p)
              (and (symbolp this-command)
                   (string-match "^lc-" (symbol-name this-command))))
          ;; Not to cause inline completion to be disrupted.
          (lc-completion-hide)
        (lc-abort))
    (error (lc-error var))))

(defun lc-handle-post-command ()
  (condition-case var
      (if (and (or lc-auto-start
                   lc-completing)
               (not isearch-mode)
               (lc-trigger-command-p))
          (lc-start))
    (error (lc-error var))))

(defun lc-error (&optional var)
  "Report an error and disable `lambda-complete-mode'."
  (ignore-errors
    (message "lambda-complete error: %s" var)
    (lambda-complete-mode nil)))

(defun lambda-complete-mode-maybe ()
  "What buffer `lambda-complete-mode' prefers."
  (if (and (not (minibufferp (current-buffer)))
           (memq major-mode lc-modes))
      (lambda-complete-mode 1)))

(require 'easy-mmode)

(define-minor-mode lambda-complete-mode
  "AutoComplete mode"
  :lighter " AC"
  :group 'lambda-complete
  (if lambda-complete-mode
      (progn
        (funcall lc-setup-function)
        (add-hook 'post-command-hook 'lc-handle-post-command nil t)
        (add-hook 'pre-command-hook 'lc-handle-pre-command nil t)
        (run-hooks 'lambda-complete-mode-hook))
    (remove-hook 'post-command-hook 'lc-handle-post-command t)
    (remove-hook 'pre-command-hook 'lc-handle-pre-command t)
    (lc-abort)))

(define-global-minor-mode global-lambda-complete-mode
  lambda-complete-mode lambda-complete-mode-maybe
  :group 'lambda-complete)



;;;; Basic cache facility

(defvar lc-clear-variables-after-save nil)

(defun lc-clear-variable-after-save (variable)
  (push variable lc-clear-variables-after-save))

(defun lc-clear-variables-after-save ()
  (dolist (variable lc-clear-variables-after-save)
    (set variable nil)))



;;;; Sources implementation

(defvar lc-sources '(lc-source-words-in-buffer)
  "Sources for completion.

Source takes a form of just function which returns candidates or alist:

init INIT-FUNC
  INIT-FUNC will be called before creating candidate every time.

candidates CANDIDATE-FUNC
  CANDIDATE-FUNC will return a list of string as candidates.
CANDIDATE-FUNC should care about `lc-limit' that is specified at limit for performance.

action ACTION-FUNC
  ACTION-FUNC will be called when `lc-complete' is called.

limit LIMIT-NUM
  A limit of candidates.

requires REQUIRES-NUM
  This source will be included when `lc-prefix' length is larger than REQUIRES-NUM.")
(make-variable-buffer-local 'lc-sources)

(defvar lc-sources-prefix-function 'lc-sources-prefix-default
  "Default prefix function for sources.
You should override this variable instead of lc-prefix-function.")

(defvar lc-current-sources nil
  "Current working sources.")

(defvar lc-omni-completion-sources nil
  "An alist of REGEXP and SOURCES.
If matched regexp, switch to omni-completion mode and
use SOURCES as `lc-sources'.")
(make-variable-buffer-local 'lc-omni-completion-sources)

(defvar lc-sources-omni-completion nil
  "Non-nil means `lambda-complete-mode' is now working on omni-completion.")

(defun lc-sources-setup ()
  "Implementation for `lc-setup-function' by sources."
  (make-local-variable 'lc-clear-variables-after-save)
  (add-hook 'after-save-hook 'lc-clear-variables-after-save nil t))

(defun lc-sources-init ()
  "Implementation for `lc-init-function' by sources."
  (or lc-current-sources (setq lc-current-sources lc-sources))
  (dolist (source lc-current-sources)
    (let ((init-function (lc-get-source-property 'init source)))
      (if init-function
          (funcall init-function)))))

(defun lc-sources-cleanup ()
  "Implementation for `lc-cleanup-function' by sources."
  (setq lc-current-sources nil)
  (setq lc-sources-omni-completion nil))

(defun lc-sources-prefix ()
  "Implemention for `lc-prefix-function' by sources."
  (let (point)
    (dolist (pair lc-omni-completion-sources)
      (when (looking-back (car pair) nil t)
        (setq lc-current-sources (cdr pair))
        (setq lc-sources-omni-completion t)
        (setq lc-completing t)
        (setq point (match-end 0))))
    (or point
        (if (and lc-completing lc-sources-omni-completion)
            lc-point
          (setq lc-current-sources lc-sources)
          (setq lc-sources-omni-completion nil)
          (funcall lc-sources-prefix-function)))))

(defun lc-sources-prefix-default ()
  "Default implementation for `lc-sources-prefix-function'."
  (require 'thingatpt)
  (car-safe (bounds-of-thing-at-point 'symbol)))

(defun lc-sources-candidate ()
  "Implementation for `lc-cadidates-function' by sources."
  (let (candidates)
    (dolist (source lc-current-sources)
      (let* ((lc-limit (or (lc-get-source-property 'limit source) lc-limit))
             (requires (lc-get-source-property 'requires source))
             cand)
        (when (or lc-sources-omni-completion
                  (>= (length lc-prefix)
                      (if (integerp requires)
                          requires
                        1)))
          (setq cand
                (delq nil
                      (mapcar (lambda (candidate)
                                (lc-propertize-candidate candidate
                                                         'action (lc-get-source-property 'action source)
                                                         'face (lc-get-source-property 'candidate-face source)
                                                         'candidate-face (lc-get-source-property 'candidate-face source)
                                                         'selection-face (lc-get-source-property 'selection-face source)))
                              (funcall (lc-get-source-property 'candidates source))))))
        (if (and (> lc-limit 1)
                 (> (length cand) lc-limit))
            (setcdr (nthcdr (1- lc-limit) (copy-sequence cand)) nil))
        (setq candidates (append candidates cand))))
    (delete-dups candidates)))

(defun lc-get-source-property (property source)
  (if (symbolp source)
      (setq source (symbol-value source)))
  (if (and (functionp source)
           (eq property 'candidates))
      source
    (if (consp source)
        (assoc-default property source))))



;;;; Standard sources

(defun lc-candidate-words-in-buffer (&optional limit)
  "Default implemention for `lc-candidate-function'."
  (or limit (setq limit lc-limit))
  (if (> (length lc-prefix) 0)
      (let ((i 0)
            candidate
            candidates
            (regexp (concat "\\b" (regexp-quote lc-prefix) "\\(\\s_\\|\\sw\\)*\\b")))
        (save-excursion
          ;; Search backward
          (goto-char lc-point)
          (while (and (or (eq limit t)
                          (< i limit))
                      (re-search-backward regexp nil t))
            (setq candidate (match-string-no-properties 0))
            (unless (member candidate candidates)
              (push candidate candidates)
              (setq i (1+ i))))
          ;; Search backward
          (goto-char (+ lc-point (length lc-prefix)))
          (while (and (or (eq limit t)
                          (< i limit))
                      (re-search-forward regexp nil t))
            (setq candidate (match-string-no-properties 0))
            (unless (member candidate candidates)
              (push candidate candidates)
              (setq i (1+ i))))
          (nreverse candidates)))))

(defvar lc-source-words-in-buffer
  '((candidates . lc-candidate-words-in-buffer))
  "Source for completing words in current buffer.")

(defvar lc-word-index nil
  "Word index for individual buffer.")

(lc-clear-variable-after-save 'lc-word-index)

(defvar lc-source-words-in-all-buffer
  '((init
     . (lambda ()
         (dolist (buffer (buffer-list))
           (with-current-buffer buffer
             (if (not (local-variable-p 'lc-word-index))
                 (make-local-variable 'lc-word-index))
             (if (eq buffer lc-buffer)
                 (setq lc-word-index (lc-candidate-words-in-buffer t))
               (if (and (null lc-word-index)
                        (< (buffer-size) 102400))
                   (save-excursion
                     (goto-char (point-min))
                     (while (re-search-forward "\\b\\(\\s_\\|\\sw\\)+\\b" nil t)
                       (let ((candidate (match-string-no-properties 0)))
                         (if (not (member candidate lc-word-index))
                             (push candidate lc-word-index))))
                     (setq lc-word-index (nreverse lc-word-index)))))))))
    (candidates
     . (lambda ()
         (let ((candidates)
               (buffers (buffer-list)))
           (while (and (< (length candidates) lc-limit)
                       buffers)
             (setq candidates (append candidates (all-completions lc-prefix (buffer-local-value 'lc-word-index (car buffers)))))
             (setq buffers (cdr buffers)))
           candidates))))
  "Source for completing words in all buffer.")

(defvar lc-source-symbols
  '((candidates
     . (lambda ()
         (all-completions lc-prefix obarray))))
  "Source for Emacs lisp symbols.")

(defvar lc-source-abbrev
  `((candidates
     . (lambda ()
         (append
          (all-completions lc-prefix global-abbrev-table)
          (all-completions lc-prefix local-abbrev-table))))
    (action
     . expand-abbrev))
  "Source for abbrev.")

(defvar lc-source-files-in-current-dir
  '((candidates
     . (lambda ()
         (all-completions lc-prefix (directory-files default-directory)))))
  "Source for listing files in current directory.")

(defun lc-filename-candidate ()
  (let ((dir (file-name-directory lc-prefix)))
    (ignore-errors
      (delq nil
            (mapcar (lambda (file)
                      (if (not (member file '("./" "../")))
                          (concat dir file)))
                    (file-name-all-completions
                     (file-name-nondirectory lc-prefix) dir))))))

(defvar lc-source-filename
  '((candidates . lc-filename-candidate))
  "Source for completing file name.")

(defvar lc-imenu-index nil
  "Imenu index.")

(defun lc-imenu-candidate ()
  (require 'imenu)
  (let ((i 0)
        (stack lc-imenu-index)
        candidates
        node)
    (while (and stack
                (< i lc-limit))
      (setq node (pop stack))
      (when (consp node)
        (let ((car (car node))
              (cdr (cdr node)))
          (if (consp cdr)
              (mapc (lambda (child)
                      (push child stack))
                    cdr)
            (when (and (stringp car)
                       (string-match (concat "^" (regexp-quote lc-prefix)) car))
              (push car candidates)
              (setq i (1+ i)))))))
    (nreverse candidates)))

(defvar lc-source-imenu
  '((init
     . (lambda ()
         (require 'imenu)
         (setq lc-imenu-index
               (ignore-errors (imenu--make-index-alist)))))
    (candidates . lc-imenu-candidate))
  "Source for imenu.")

(defmacro lc-define-dictionary-source (name list)
  "Define dictionary source named `NAME'.
`LIST' is a list of string.
This is useful if you just want to define a dictionary/keywords source."
  `(defvar ,name
     '((candidates . (lambda () (all-completions lc-prefix ,list))))))



;;;; Inline Completion

(defvar lc-completion-dummy-char-marker (make-marker))

(defun lc-completion-show (point string)
  "Show inline completion."
  (save-excursion
    (let ((width 0)
          (string-width (string-width string)))
      ;; Cacluate string space to show completion.
      (goto-char point)
      (while (and (not (eolp))
                  (< width string-width))
        (setq width (+ width (char-width (char-after))))
        (forward-char))

      ;; Show completion.
      (goto-char point)
      (cond
       ((= width 0)
        (set-marker lc-completion-dummy-char-marker point)
        (let ((buffer-undo-list t))
          (insert " "))
        (setq width 1))
       ((<= width string-width)
        ;; No space to show
        ;; Do nothing
        )
       ((> width string-width)
        ;; Need to fill space
        (setq string (concat string (make-string (- width string-width) ? )))))
      (setq string (propertize string 'face 'lc-completion-face))
      (if lc-completion-overlay
          (progn
            (move-overlay lc-completion-overlay point (+ point width))
            (overlay-put lc-completion-overlay 'invisible nil))
        (setq lc-completion-overlay (make-overlay point (+ point width)))
        (overlay-put lc-completion-overlay 'priority 9999))
      (overlay-put lc-completion-overlay 'display (substring string 0 1))
      ;; TODO no width but char
      (overlay-put lc-completion-overlay 'after-string (substring string 1))
      (overlay-put lc-completion-overlay 'string string))))

(defun lc-completion-hide ()
  "Hide inline completion."
  (when (marker-position lc-completion-dummy-char-marker)
    (let ((buffer-undo-list t))
      (save-excursion
        (goto-char lc-completion-dummy-char-marker)
        (delete-char 1)
        (set-marker lc-completion-dummy-char-marker nil))))
  (when lc-completion-overlay
    (move-overlay lc-completion-overlay (point-min) (point-min))
    (overlay-put lc-completion-overlay 'invisible t)
    (overlay-put lc-completion-overlay 'display nil)
    (overlay-put lc-completion-overlay 'after-string nil)))

(defun lc-completion-delete ()
  "Delete inline completion."
  (lc-completion-hide)
  (when lc-completion-overlay
    (delete-overlay lc-completion-overlay)
    (setq lc-completion-overlay nil)))

;;;; Popup menu

(defun lc-menu-line (menu)
  "Line number of `MENU'."
  (nth 0 menu))

(defun lc-menu-column (menu)
  "Column of `MENU'."
  (nth 1 menu))

(defun lc-menu-width (menu)
  "Popup menu width of `MENU'."
  (nth 2 menu))

(defun lc-menu-height (menu)
  "Popup menu height of `MENU'."
  (nth 3 menu))

(defun lc-menu-overlays (menu)
  "Overlays that `MENU' contains."
  (nth 4 menu))

(defun lc-menu-line-overlay (menu line)
  "Return a overlay of `MENU' at `LINE'."
  (aref (lc-menu-overlays menu) line))

(defun lc-menu-hide-line (menu line)
  "Hide `LINE' in `MENU'."
  (let ((overlay (lc-menu-line-overlay menu line)))
    (overlay-put overlay 'invisible nil)
    (overlay-put overlay 'after-string nil)))

(defun lc-menu-show-line (menu line)
  "Show `LINE' in `MENU'."
  (let ((overlay (lc-menu-line-overlay menu line)))
    (overlay-put overlay 'invisible t)))

(defun lc-menu-set-line-string (menu line string &optional face)
  "Set contents of `LINE' in `MENU'."
  (let ((overlay (lc-menu-line-overlay menu line)))
    (overlay-put overlay 'real-string string)
    (funcall (overlay-get overlay 'set-string-function) menu overlay string face)))

(defun lc-menu-create-line-string (menu string)
  "Adjust `STRING' into `MENU'."
  (let ((length 0)
        (width 0)
        (menu-width (lc-menu-width menu))
        (chars (append string nil)))
    (while (and
            chars
            (<= (setq width (+ width (char-width (car chars)))) menu-width))
      (setq length (1+ length))
      (setq chars (cdr chars)))
    (if (< length (length string))
        (setq string (substring string 0 length)))
    (let ((string-width (string-width string)))
      (if (< string-width menu-width)
          (setq string (concat string
                               (make-string (- menu-width string-width) ? )))))
    string))

(defun lc-menu-hide (menu)
  "Hide `MENU'."
  (dotimes (i (lc-menu-height menu))
    (lc-menu-hide-line menu i)))

(defun lc-menu-last-line-of-buffer ()
  (save-excursion
    (not (eq (forward-line) 0))))

(defun lc-menu-create (line column width height direction)
  "Create popup menu."
  (save-excursion
    (let ((overlays (make-vector height nil))
          (window (selected-window))
          menu-visual-column
          current-visual-column)
      (goto-line line)
      (move-to-column column)
      (setq menu-visual-column (lc-current-physical-column))
      (dotimes (i height)
        (let (overlay begin w (prefix "") (postfix ""))
	  (vertical-motion direction)
          (move-to-column (+ (current-column) menu-visual-column))
	  (setq current-visual-column (lc-current-physical-column))

	  (cond
           ((> current-visual-column menu-visual-column)
            (backward-char)
            (setq current-visual-column (lc-current-physical-column))
            (if (< current-visual-column menu-visual-column)
                (setq prefix (make-string (- menu-visual-column current-visual-column) ? ))))
	   ;; Extend short buffer lines by menu prefix (line of spaces)
           ((< current-visual-column menu-visual-column)
            (setq prefix (make-string (- menu-visual-column current-visual-column) ? ))))

          (setq begin (point))
          (setq w (+ width (length prefix)))
          (while (and (not (eolp))
                      (> w 0))
            (setq w (- w (char-width (char-after))))
            (forward-char))
          (if (< w 0)
              (setq postfix (make-string (- w) ? )))
          (if (lc-menu-last-line-of-buffer)
              (setq postfix (concat postfix "\n")))

          (setq overlay (make-overlay begin (point)))
          (overlay-put overlay 'window window)
          (overlay-put overlay 'prefix prefix)
          (overlay-put overlay 'postfix postfix)
          (overlay-put overlay 'width width)
          (overlay-put overlay 'set-string-function
                       (lambda (menu overlay string &optional face)
                         (overlay-put overlay
                                      'after-string
                                      (concat (overlay-get overlay 'prefix)
                                              (propertize (lc-menu-create-line-string menu string) 'face face)
                                              (overlay-get overlay 'postfix)))))
          (aset overlays
		(if (> direction 0)
		    i
		  (- height i 1))
		overlay)))
      (let ((i 100))
        (mapc (lambda (overlay)
                (overlay-put overlay 'priority i)
                (setq i (1+ i)))
              (nreverse (append overlays nil))))
      (list line column width height overlays))))

(defun lc-menu-delete (menu)
  "Delete `MENU'."
  (mapcar 'delete-overlay (lc-menu-overlays menu)))

(provide 'lambda-complete)
;;; lambda-complete.el ends here
