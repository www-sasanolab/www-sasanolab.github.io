(progn
  (require 'cl)
  (require 'lambda-common)
  (require 'lambda-type)
  (require 'lambda-exp)
  (require 'lambda-expD)
  (require 'lambda-type-env)
  (require 'lambda-unification)
  (require 'lambda-inference-w)
  (require 'lambda-inference-v)
  (require 'lambda-candidates)
  (require 'lambda-tokenizer)
  (require 'lambda-debug))

;;default environment  
(setq env (foldl '(lambda (env x)
		    (insert-env env (car x) (cdr x)))
		 (make-empty-env)
		 (list 
		  (cons "+" (arrowTy (intTy) (arrowTy (intTy) (intTy)))))))

(defun lambda-test-1 ()
  (let*
      ((exp (markExp (letExpD
		      (decSeq 
		       (valDecl (valBind (varPat "x") (intExp 1)))
		       (valDecl (valBind (varPat "xx") (absExp "x" (varExp "x")))))
		      (absExpD "xy" (markExp (appExpD (varExp "+") (cursorExp)))))))
       (v-result-set (lambda-type-inference-v env exp)))
    (message "########################")
    (message "let x = 1, xx = fn x=>x in fn xy => + _")
    ;;(print-v-result-set v-result-set)
    (enum-candidates-from-v-result-set v-result-set)))

(defun lambda-test-2 ()
  (let*
      ((exp (markExp (letExpD
		      (decSeq 
		       (valDecl (valBind (varPat "x") (intExp 1)))
		       (valDecl (recValBind (valBind (varPat "xx") (appExp (varExp "xx") (intExp 1))))))
		      (absExpD "xy" (markExp (appExpD (varExp "xx") (cursorExp)))))))
       (v-result-set (lambda-type-inference-v env exp)))
    (message "########################")
    (message "let x = 1, rec xx = xx 1 in fn xy => + _")
    (print-v-result-set v-result-set)
    (enum-candidates-from-v-result-set v-result-set)))

(lambda-test-2)

(let* ((exp1 (intExp 10))
       (exp2 (absExp "xx" exp1))
       
       ;;let x = fn xx => 10 in x 
       (exp3 (letExp (valDecl (valBind (varPat "x") exp2)) (varExp "x")))
       ;;let x = fn y=>fn x=>y in x x 
       ;;x: a->b->a
       ;;x x : (c->d->c)-> b->(c->d->c)
       ;;let rec val x = fn y => if  eq y 1 then 0 else + y (x (y-1))
       (cursor (cursorExp))
       (exp5 (absExpD "x" cursor));�֐����̃e�X�g
       (exp55 (absExpD "xk" exp5))
       ;;(fn x =>x) (fn x => _)
       (exp6 (appExpD (absExp "x" (varExp "x"))
		      exp5))
       (decl (valDecl (valBind (varPat "xx") (intExp 1))))
       (declD (valDeclD (valBindD (varPat "xy") exp5)))
       
       (exp7 (letExp2D declD))
       (exp8 (letExpD decl exp55))
       (exp9 (markExp exp8))
       (exp4 (letExp (valDecl (recValBind (valBind (varPat "x") (appExp (varExp "x") (intExp 1))))) (varExp "x")))
       ;;let rec val x = fn y => x y in x 
       (exp4 (letExp (valDecl (recValBind (valBind (varPat "x") (absExp "y" (appExp (varExp "x") (varExp "y")))))) (varExp "x")))
       (env (make-empty-env)))
  ;(print-w-result (type-inference-w env exp4))
  (print-v-result-set (lambda-type-inference-v env exp8)))


(let* ((int-int-int (arrowTy (intTy) (arrowTy (intTy) (intTy))))
      (int (intTy))
      (a-int (arrowTy (varTy "a") (intTy)))
      (b-c (arrowTy (varTy "b") (varTy "c")))
      (env (make-empty-env))
      (subst (unify (singleton-set (cons int-int-int b-c)))))
  (setq env (insert-env env "xx" int-int-int))
  (setq env (insert-env env "xy" int))
  (setq env (insert-env env "xz" a-int))
  (setq env (insert-env env "xc" b-c))
  (print-env (apply-subst-to-env env subst))
  (env-to-set '(lambda (x) (type-inference-v-arity (cdr x))) env)
  )


(tokenize-all)
