(require 'cl)

;;expression
(defstruct
  (varExp
   (:constructor varExp (name)))
   name)

(defstruct
  (intExp
   (:constructor intExp (integer)))
   integer)

(defstruct
  (appExp
   (:constructor appExp (fun arg)))
   fun arg)

(defstruct
  (absExp
   (:constructor absExp (name body)))
  name body)

(defstruct
  (letExp
   (:constructor letExp (decl body)))
  decl body)

(defstruct
  (ifExp
   (:constructor ifExp (condExp thenExp elseExp)))
   condExp thenExp elseExp)
		 

(defstruct
  (markExp
   (:constructor markExp (body)))
  body)

;;match
(defstruct
  (match
   (:constructor match (mrule)))
  mrule)

(defstruct
  (mrule
   (:constructor mrule (pat exp)))
  pat exp)

;;declaration
(defstruct
  (valDecl
   (:constructor valDecl (valBind)))
  valBind)

(defstruct 
  (decSeq
   (:constructor decSeq (decl1 decl2)))
   decl1 decl2)

;;value binding
(defstruct
  (valBind
   (:constructor valBind (pat exp)))
  pat exp)

(defstruct
  (recValBind
   (:constructor recValBind (pat exp)))
  pat exp)


;;pattern
(defstruct
  (varPat
   (:constructor varPat (name)))
  name)		 

(provide 'lambda-exp)
