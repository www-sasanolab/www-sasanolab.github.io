
(defun print-w-result (w-result)
  (message "--------print-w-result---------")
  (message (format "subst:%s" (w-result-subst w-result)))
  (message (format "type: %s" (type-to-string (w-result-type w-result)))))

(defun print-v-result-set (v-result-set)
  (message "--------print-v-result-set--------")
  (map-set '(lambda (v-result)
	      (message "��v-result")
	      (message (format "subst:%s" (v-result-subst v-result)))
	      (message (format "type: %s" (type-to-string (v-result-type v-result))))
	      (message (format "type of cursor: %s" (type-to-string 
						     (apply-subst-to-type (v-cursor-result-type (v-result-c v-result))
									  (v-result-subst v-result)))))
	      (print-env (v-cursor-result-env (v-result-c v-result))))
	   v-result-set))
	   
(defun print-subst (subst)
  (when subst
    (when (caar subst)
      (message (format "%s => %s" (caar subst) (type-to-string (cdar subst)))))
    (print-subst (cdr subst))))

(defun print-env (env)
  (when env
    (message (format "%s:%s" (caar env) 
		     (type-to-string (cdar env))))
    (print-env (cdr env))))

(defun type-to-string (type)
  (cond
   ((intTy-p type) "int")
   ((varTy-p type) (format "%s" (varTy-name type)))
   ((arrowTy-p type)
    (format (if (arrowTy-p (arrowTy-arg type))
		"(%s)->%s" "%s->%s")
	    (type-to-string (arrowTy-arg type))
	    (type-to-string (arrowTy-result type))))
   ((polyTy-p type)
    (format "��(%s).%s" (polyTy-tyVarList type)
	    (type-to-string (polyTy-type type))))))

(defun token2string (token)
  (let ((sym (lambda-token-symbol token))
	(val (lambda-token-value token)))
     (when (eq sym 'ID)
      (if (eq val nil)
	  (setq val "cursor")
	(setq val (replace-regexp-in-string "%" "��" val))))
    
    (cond
     ((eq sym 'ID) (concat "ID_(" val ")"))
     ((eq sym 'INT) (concat "INT(" val ")"))
     ((eq sym 'STRING) (concat "STRING(" val ")"))
     (t (substring (format "%s" sym) 0 (length (format "%s" sym)))))))



(defun tokenize-all ()
  (interactive)
  (save-excursion
    (let ((pos (init-lambda-tokenizer-status))
	  (tokens ""))
      (while 
	  (let* ((token (lambda-tokenizer pos))
		(sym (lambda-token-symbol token))
		(val (lambda-token-value token)))
	    
	    ;(message (format "F3::%s" sym ))
	    
	    ;;(setq tokens (replace-regexp-in-string "%" "%%" tokens))
	    (setq tokens (format "%s %s," tokens (token2string token) ))
	    (if (eql '$EOF (lambda-token-symbol token))
		nil t)))
      (message tokens))))

(defun parse-test ()
  (interactive)
  (let ((result  (lambda-parser)))
    (message (format "%s" result))))

    
(provide 'lambda-debug)