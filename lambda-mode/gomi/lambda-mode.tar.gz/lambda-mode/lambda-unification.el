(require 'cl)
(require 'lambda-common)
(require 'lambda-type-env)

;;type map
(defun empty-subst ()
  nil)

(defun subst-to-subst (target with)
  (map-set '(lambda (subst)
	      (cons (car subst)
		    (apply-subst-to-type (cdr subst) with)))
	   target))

(defun union-subst (sec fst)
  ;(append fst sec))
  ;;(message (format "subst: %s" fst))
  (if (equal (cons nil nil) sec) 
      fst
    (append (subst-to-subst fst sec) sec)))

(defun occur-check (tyVar type)
  "return t when type contains tyVar and nil otherwise"
  (cond
   ((intTy-p type) nil)
   ((varTy-p type)
    (equal type tyVar))
   ((arrowTy-p type)
    (or
     (occur-check tyVar (arrowTy-arg type))
     (occur-check tyVar (arrowTy-result type))))
   ((polyTy-p type)
    (occur-check tyVar (polyTy-type type)))))

(defun find-map (map key)
  (cdr (assoc key map)))

(defun delete-map (map key)
  (let ((result nil))
    (dolist (tyVar-type-pair map result)
      (unless (equal key (car tyVar-type-pair))
	(setq result (cons tyVar-type-pair result))))
    result))


(defun unify (type-pair-set)
  "return the substitution (most general unifier) or throw an error"
  (if type-pair-set 
      (let 
	  ((type1 (caar type-pair-set))
	   (type2 (cdar type-pair-set)))
	(cond
	 ((and (arrowTy-p type1) (arrowTy-p type2))
	  (unify 
	   (set-union (set-union
		       (singleton-set (cons (arrowTy-arg type1) (arrowTy-arg type2)))
		       (singleton-set (cons (arrowTy-result type1) (arrowTy-result type2))))
		      (cdr type-pair-set))))
	 
	 ((varTy-p type1)
	  (if (and 
	       (varTy-p type2)
	       (equal (varTy-name type1) (varTy-name type2)))
	      (unify (cdr type-pair-set))
	    (if (occur-check type1 type2)
		(throw 'error nil)
	    ;;subst 	   
	    (let 
		((subst1 (singleton-set (cons (varTy-name type1) type2))))
	      (union-subst
	       (unify (apply-subst-to-type-pair-set subst1 (cdr type-pair-set)))
	       subst1)))))

	 ((varTy-p type2)
	  (let 
	      ((subst1 (singleton-set (cons (varTy-name type2) type1))))
	    (union-subst
	     (unify (apply-subst-to-type-pair-set subst1 (cdr type-pair-set)))
	     subst1)))

	 ((and (intTy-p type1) (intTy-p type2))
	  (unify (cdr type-pair-set)))

	 (t (throw 'error nil))))
    ;;type-pair-set is empty.
    ;;���}���u
    (cons nil nil)))


(provide 'lambda-unification)

