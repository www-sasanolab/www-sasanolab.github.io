(require 'cl)
(defun tokenizer-error-message (text)
  (message text))


(defstruct
  (lambda-token
   (:constructor lambda-token (symbol right left &optional value)))
  symbol right left value)

(defstruct
  (lambda-tokenizer-status
   (:constructor init-lambda-tokenizer-status ()))
  (pos (point-min))
  (eof (point))
  (tokenizer-reached-eof nil)
  token)

(defmacro define-tokenizer 
  (name conditions variables &rest rules)
  (defvar lexer-condition 'INITIAL)
  (let ((--dt-variables variables))
    (while (car --dt-variables)
      (if (not (listp (car --dt-variables)))
	  (set (car --dt-variables) nil)
	(set (car (car  --dt-variables)) (car (cdr (car --dt-variables)))))
      (setq --dt-variables (cdr --dt-variables))))
  (let ((process-list '())
	(rules rules)
	rule)
    (while (car rules)
      (setq rule (car rules))
      (setq process-list (cons
			  `((and 
				  (eq lexer-status (quote ,(car rule)))
				  (looking-at ,(car (cdr rule))))
			    (setq yypos (match-beginning 0))
			    (setq yytext (match-string-no-properties 0))
			    ,@(cdr (cdr rule)))
			  process-list))
      (setq rules (cdr rules)))
    (setq process-list (list (cons 'cond (reverse process-list))))
    
    `(defun ,name (tokenizer &optional condition)
       (let ((lexer-rules ',rules)
	     yybegin yytext yypos (token nil)
	     (continue t) return 
	     (eof (lambda-tokenizer-status-eof tokenizer))
	     (lexer-status (if condition condition 'INITIAL)))
	 (goto-char (lambda-tokenizer-status-pos tokenizer))
	 (fset 'return (lambda (s l r &optional v) (setq token (lambda-token s l r v))))
	 (fset 'yybegin (lambda (status) (setq lexer-status status)))
	 (fset 'continue (lambda () (setq continue t) (goto-char (match-end 0))))
	 
	 (if (lambda-tokenizer-status-tokenizer-reached-eof tokenizer) 
	     (return '$EOF eof eof)
	   (while (and 
		   continue 
		   (< (point) eof ))
	     (setq continue nil)
	     ,@process-list)
	   (setf (lambda-tokenizer-status-pos tokenizer) (match-end 0)) 
	   ;;cursor expression
	   (when (>= (point) eof)
	     (setf (lambda-tokenizer-status-tokenizer-reached-eof tokenizer) t)
	     (return 'CURSOR eof eof nil)))
	 token))))

(provide 'tokenizer-macro)










