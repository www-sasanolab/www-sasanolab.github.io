(require 'cl)

;;D expression
(defstruct
  (appExpD
   (:constructor appExpD (fun argD)))
   fun argD)

(defstruct
  (absExpD
   (:constructor absExpD (name bodyD)))
  name bodyD)

(defstruct
  (letExpD
   (:constructor letExpD (decl bodyD)))
  decl bodyD)
;;decl is list of valBind and recValBind

(defstruct
  (letExp2D
   (:constructor letExp2D (declD)))
  declD)

(defstruct
  (parenExpD
   (:constructor parenExpD (expD)))
  expD)

(defstruct
  (ifExpD
   (:constructor ifExp (condExp thenExp elseExpD)))
   condExp thenExp elseExpD)

(defstruct
  (ifExp2D
   (:constructor ifExp2D (condExp thenExpD)))
   condExp thenExpD)

(defstruct
  (ifExp3D
   (:constructor ifExp3D (condExpD)))
   condExpD)

;;cursor expression
(defstruct
  (cursorExp
   (:constructor cursorExp)))

;;mark expression
(defstruct
  (markExp
   (:constructor markExp (expD)))
   expD)

		

;;valDeclD and decSeqD are not used
;;D declaration
(defstruct
  (valDeclD
   (:constructor valDeclD (valBindD)))
  valBindD)

(defstruct 
  (decSeqD
   (:constructor decSeqD (decl1 decl2D)))
   decl1 decl2D)

;;D value binding
(defstruct
  (valBindD
   (:constructor valBindD (pat expD)))
  pat expD)

(defstruct
  (recValBindD
   (:constructor recValBindD (pat expD)))
  pat expD)

(provide 'lambda-expD)

