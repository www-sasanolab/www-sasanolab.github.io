(require 'cl)

;;polymorphic type
(defstruct
  (polyTy
   (:constructor polyTy (tyVarList type)))
   tyVarList type)

;;monomorphic type 
(defstruct
  (intTy
   (:constructor intTy)))

(defstruct 
  (boolTy
   (:constructor boolTy)))

(defstruct
  (varTy
   (:constructor varTy (name)))
   (name))

(defstruct
  (arrowTy
   (:constructor arrowTy (arg result)))
  arg result)

(provide 'lambda-type)
