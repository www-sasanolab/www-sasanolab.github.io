【システム概要】
マルチスレッドプログラムの実行中の動作を可視化するためにこのツールを開発しました。
Webアプリケーションで構築しております。
現在では、2つの可視化を実現しています。
- 共有変数のアクセスの可視化
- 排他制御の可視化

不具合やお困りのことがありましたら、以下メールアドレスにてご連絡をお願い致します。
ma19092@shibaura-it.ac.jp (吉塚メールアドレス)

【システム要件】
- サーバエンド
OS:Ubuntu　Python3(var3.8.5)が動く環境
* Linuxで動くことが可能と予測されますが、Ubuntuのみでしか起動を確認しておりません。

- フロントエンド
Webブラウザ:Google Chrome、FireFox
URL:{ホスト名}/ 　　     --- 共有変数のアクセスの可視化
    {ホスト名}/thread    ---排他制御の可視化
*Microsoft EdgeやInternet Exprolerでは確認しておりません。

【ツール起動までの流れ】
1.各ライブラリのインストール
    このツールでは以下の主要なライブラリをインストールする必要があります
    以下のコマンドは例であり、全てUbuntuなどのDebian系Linux OSのものです。
    *インストールするバージョンは全て10.0.X系です。

    - llvm
        llvm本体をインストール
        > sudo apt install llvm-10
    - lldb
        lldb本体と開発用ライブラリのインストール
        > sudo apt install lldb-10 liblldb-10-dev
        Python用のモジュールをパスに追加
        PYTHONPATH="/usr/lib/llvm-10/lib/python3/dist-packages"
    - clang
        clang本体のインストール
        > sudo apt install clang-10
        Python用Clnagインターフェースのインストール
        > sudo apt install python3-clang-10

2.python3でフォルダ内のserver.pyを起動
    > python3 server.py
    *相対パスの使用もあるため、起動する際はserver.pyのあるフォルダで起動することに注意してください。

*うまく動作しない場合は…
LLDB APIでは、lldb-serverを起動して動作しています。
そのため、lldb-serverが見つからずにサーバがうまく起動しない現象を確認しています。
その場合はサーバを起動する際、straceコマンドを頭につけ、lldb-serverを見つけられているか確認してください。
できてない場合は、フォルダ内にあるCsource/bin内にlldb-serverのリンクを作成してください。