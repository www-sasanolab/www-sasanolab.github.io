/*
    $.get('/csource', {
        "filename": "multithread.c"
    }, function (data) {
        // console.log(data)
        init_text();
        set_text(data);
    })
*/
let $upfile = $('input[name="upfile"]');
fd = "#include<stdio.h>\n int main(void){}";
console.log(fd)

$('button.button__file').click(function () {
    source = $('textarea[name="codeEditor"]').val()
    console.log(source)
    $.ajax({
        url: '/csource',
        type: 'post',
        data: source,
        processData: false,
        contentType: false,
        cache: false,
    }).done(function (data) {
        console.log(data)
        $('textarea#codeEditor').remove();
        var table = $('<table>').append($('<tbody>').attr({ id: "codeLine" }));
        $('div#codearea').append(table);
        init_text();
        set_text(data);
    }).fail(function () {
        // 失敗時の処理
        alert("コンパイルエラーが起きました。")
    });
});

markTab = 0
head_key = { addr: 'addr', type: 'type', name: 'name', value: 'value' }
$('button#input').click(function () {
    inputStr = $("#input").val()
    $.get('/input', {
        "inputStr": inputStr
    })
})

$('#launch,#next').click(function () {
    var com = $(this).attr('id')
    $.get(`/${com}`, function (data) {
        console.log(data)
        if (data.Output) {
            $('#Output').text($('#Output').text() + data.Output)
            if (!data.thread)
                return
        }
        init_vtable();
        init_text();
        $('#next_dummy').text(data.thread[0].ID)
        for (var idx = 0; idx < data.thread.length; idx++) {
            set_vtable(data.thread[idx], idx)
            mark_text(data.thread[idx], idx);
        }
        for (var idx = 0; idx < data.thread.length; idx++) {
            set_wp(data.thread[idx].access, idx)
        }
        initFunc();
    })
})
function Analyze_thread_data(thread_data) {

}
function output(out) {
    var txt = $('textarea').text();
    $('textarea').text(txt + out);
}

function initFunc() {
    $(".vtable").hide()
    $(`#${markTab}.vtable`).show();

    // is-clicked
    $(".thread__tab-button-li").click(function () {
        // tab-button に関する処理
        $(".thread__tab-button-li").removeClass("is-active");
        $(this).addClass("is-active");
        // tab そのものに関わる処理
        $(".vtable").hide();
        markTab = $(this).attr("name");
        $(`#${markTab}.vtable`).fadeIn("fast");
        return false;
    });

    $('.button__next').click(function () {
        var threadID = $(this).attr('id')
        $.get('/next', { threadID: threadID }, function (data) {
            console.log(data)
            if (data.Output) {
                $('#Output').text($('#Output').text() + data.Output)
                if (!data.thread)
                    return
            }
            init_vtable();
            init_text();
            for (var idx = 0; idx < data.thread.length; idx++) {
                set_vtable(data.thread[idx], idx)
                mark_text(data.thread[idx], idx);
                set_wp(data.thread[idx].access, idx)
            }
            initFunc();
        })
    })
}

function set_wp(wplist, t_idx) {
    for (var wp_idx = 0; wp_idx < wplist.length; wp_idx++) {
        $(`tr#${wplist[wp_idx]}`).attr({ bgcolor: color_set[t_idx] })
    }
}

function set_text(data) {
    contents = String(data).split('\n');
    for (var s_idx = 0; s_idx < contents.length; s_idx++) {
        var code_tr = $('<tr>').attr({ class: 'line', id: s_idx })
        code_tr.append($('<td>').text(s_idx + 1))
        code_tr.append($('<td>').addClass('mark'))
        code_tr.append($('<td>').text(contents[s_idx]))

        $('#codeLine').append(code_tr)
    }
}

function mark_text(thread, t_idx) {
    var frame;
    for (var f_idx = 0; f_idx < thread.flist.length; f_idx++) {
        if (thread.flist[f_idx].hasOwnProperty('line'))
            frame = thread.flist[f_idx].line
    }
    var mark = $('<span>').css({ 'color': color_set[t_idx] })
    $(`.line#${frame - 1} .mark`).append(mark.text('●'))
}

function init_text() {
    for (idx = 0; idx < $('.mark').length; idx++)
        $('.line .mark').text("　")
}

function init_vtable() {
    $("#vtable_area").empty()
    $(".thread__tab-button-ul").empty()
}

function set_vtable(thread, idx) {
    // decl table
    var v_div = $('<div>').attr({
        id: idx,
        class: 'vtable'
    })
    var LocalV_table = $('<table>').attr({ border: 1 })
    var StaticV_table = $('<table>').attr({ border: 1 })
    // caption setting
    var LocalV_cap = $('<caption>').append($('<strong>').text(`Thread ID : ${thread.ID}`))
    LocalV_table.append(LocalV_cap)
    var StaticV_cap = $('<caption>').append($('<strong>').text('Shared Variables'))
    StaticV_table.append(StaticV_cap)

    //set variable_list
    var frame;
    for (var f_idx = 0; f_idx < thread.flist.length; f_idx++) {
        if (thread.flist[f_idx].hasOwnProperty('line'))
            frame = thread.flist[f_idx]
    }
    var vlist = frame ? frame.vlist : []

    // header setting
    var v_thead = $('<thead>').append('<tr>')
    for (key in head_key)
        v_thead.find('tr').append($('<th>').text(key))
    LocalV_table.append(v_thead.clone())
    StaticV_table.append(v_thead.clone())

    //LocalV and StaticV body setting
    var LocalV_tbody = $('<tbody>')
    var StaticV_tbody = $('<tbody>')


    var tr_array = []
    SetBody(thread, vlist, tr_array, '')
    for (var tr_idx = 0; tr_idx < tr_array.length; tr_idx++) {
        if (tr_array[tr_idx].attr == "local")
            LocalV_tbody.append(tr_array[tr_idx].tr)
        else {
            StaticV_tbody.append(tr_array[tr_idx].tr)
        }
    }
    if (LocalV_tbody.children().length) {
        v_div.append(LocalV_table.append(LocalV_tbody))
    }
    if (StaticV_tbody.children().length) {
        v_div.append(StaticV_table.append(StaticV_tbody))
    }
    // next button setting 
    var nextBt = $('<button>').attr({
        class: 'button__next',
        id: thread.ID
    })
    //v_div.append(nextBt.text('next'))
    $('#vtable_area').append(v_div)

    // tab decl & setting 
    var tab_li = $('<li>').attr({
        class: 'thread__tab-button-li',
        name: idx
    })
    tab_li.text(thread.name ? thread.name : `Thread${idx}`)
    tab_li.css({ 'background-color': color_set[idx] })
    $(".thread__tab-button-ul").append(tab_li)
    if (markTab == idx)
        $(`li[name="${idx}"]`).addClass("is-active");


}
function SetBody(thread, vlist, tr_array, parent) {
    for (var idx = 0; idx < vlist.length; idx++) {
        if (vlist[idx] == null)
            continue;
        var v_tr = $('<tr>').attr({ id: vlist[idx].name })
        p_list = parent.split(' ')
        for (var p_idx = 0; p_idx < p_list.length; p_idx++)
            v_tr.addClass(p_list[p_idx])
        for (key in head_key) {
            if (key == 'addr')
                vlist[idx].addr = toHex(vlist[idx].addr)
            var v_td = $('<td>').text(vlist[idx][key])
            v_tr.append(v_td)
        }
        if (parent != '')
            v_tr.hide();
        v_tr.click(function () {
            var tr_id = $(this).attr('id')
            if ($(`.${tr_id}`).css('display') == 'none')
                $(`.${tr_id}`).fadeIn("fast");
            else
                $(`.${tr_id}`).hide();
        });
        tr_array.push({ tr: v_tr, attr: vlist[idx].attr })

        if (vlist[idx].child.length) {
            SetBody(thread, vlist[idx].child, tr_array, parent + ' ' + vlist[idx].name)
        }
    }
    return tr_array
}

function toHex(v) {
    //console.log(typeof (v), v)
    if (typeof (v) != 'undefined')
        return '0x' + (('0000000000000000' + v.toString(16).toUpperCase()).substr(-16));
}
/*
function SetBody(thread, vlist, local, static) {
    for (id = 0; id < vlist.length; id++) {
        if (Array.isArray()) {
            for (var idx = 0; idx < vlist.value.length; idx++)
                SetBody(thread, vlist.value[idx], local, static)
        } else {
            var v_tr = $('<tr>').addClass(vlist[id].name)
            for (key in vlist[id]) {
                var v_td = $('<td>').text(vlist[id][key])
                v_tr.append(v_td)
            }
 
            if (vlist[id].attr == "local")
                local.append(v_tr)
            else {
                if (!thread.access.indexOf(vlist[id].name))
                    $(`.${vlist[id].name}`).css({ 'background-color': color_set[idx] })
                static.append(v_tr)
            }
        }
 
    }
}
*/

$('.button__continue').on('click', function () {
    let scrollHeight = 999;
    $('.output__text').scrollTop(scrollHeight);
});

var color_set = ['#ff7f7f', '#ff7fbf', '#ff7fff', '#bf7fff', '#7f7fff', '#7fbfff', '#7fffff', '#7fff7f', '#bfff7f', '#ffff7f', '#ffbf7f']
