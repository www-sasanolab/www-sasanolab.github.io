const PTHREAD_LIBRARY = "libpthread.so.0"

$('button.button__file').click(function () {
    source = $('textarea[name="codeEditor"]').val()
    console.log(source)
    $.ajax({
        url: '/csource',
        type: 'post',
        data: source,
        processData: false,
        contentType: false,
        cache: false,
    }).done(function (data) {
        console.log(data)
        $('textarea#codeEditor').remove();
        var table = $('<table>').append($('<tbody>').attr({ id: "codeLine" }));
        $('div#codearea').append(table);
        init_text();
        set_text(data);
    }).fail(function () {
        // 失敗時の処理
        alert("コンパイルエラーが起きました。")
    });
});

markTab = 0
head_key = { addr: 'addr', type: 'type', name: 'name', value: 'value' }
$('button#input').click(function () {
    inputStr = $("#input").val()
    $.get('/input', {
        "inputStr": inputStr
    })
})

$('#launch,#continue').click(function () {
    var com = $(this).attr('id')
    $.get(`/${com}`, function (data) {
        console.log(data)
        if (data.Output) {
            $('#Output').text($('#Output').text() + data.Output)
            if (!data.thread)
                return
        }
        if (data.state == "10")
            location.reload();
        init_text();
        setMainThread(data.thread[0], data.pthread)
        for (var idx = 1; idx < data.thread.length; idx++) {
            setOtherThread(data.thread[idx], data.pthread)
        }
        for (var idx = 0; idx < data.thread.length; idx++) {
            mark_text(data.thread[idx], idx, data.module);
        }
    })
})
var previous = [0, 0, 0]
function mark_text(thread, t_idx, module) {
    var line;
    for (var f_idx = 0; f_idx < thread.flist.length; f_idx++) {
        if (thread.flist[f_idx].module == module && thread.flist[f_idx].hasOwnProperty('line'))
            line = thread.flist[f_idx].line
    }
    if (thread.StopReason == "WP")
        line = line - 1
    var mark = $('<span>').css({ 'color': color_set[t_idx] })
    $(`.line#${line - 1} .mark`).append(mark.text('●'))

}

function AnalyzeThread(thread, pthread) {
    let discr = "";
    if (thread.StopReason == 'BP') {
        var line = thread.flist[0].line;
        for (var idx = 0; idx < pthread.length; idx++) {
            if (line == pthread[idx].line) {
                discr += (pthread[idx].line + ':' + pthread[idx].name + 'が呼ばれました。')
            }
        }
    } else if (thread.StopReason == 'WP') {
        if (thread.access[0].indexOf("__lock") > 0 || thread.access[0].indexOf("__owner") > 0) {
            for (var idx = 0; idx < thread.flist.length; idx++) {
                if (thread.flist[idx].module == PTHREAD_LIBRARY) {
                    if (thread.access[0].indexOf("__lock") > 0)
                        if (thread.flist[idx].name.indexOf("_unlock") > 0) {
                            discr += (thread.access[0].split('.')[0] + 'を解放しました')
                            return discr
                        } else if (thread.flist[idx].name == "") {
                            discr += (thread.access[0].split('.')[0] + 'を確認しました')
                        }
                    if (thread.access[0].indexOf("__owner") > 0) {
                        if (thread.flist[idx].name.indexOf("_unlock") > 0) {
                            discr += (thread.access[0].split('.')[0] + 'を解放しました')
                            return discr
                        }
                        if (thread.flist[idx].name == "") {
                            discr += (thread.access[0].split('.')[0] + 'を取得しました')
                        }
                    }

                }
            }
        } else {
            discr += (thread.access[0] + 'にアクセスしました')
        }

    } else if (thread.StopReason == 'None') {
        for (var idx = 0; idx < thread.flist.length; idx++) {
            if (thread.flist[idx].module == PTHREAD_LIBRARY && thread.flist[idx].name == "__lll_lock_wait") {
                discr += "mutexが解放されるまで待っています。"
            }
        }
    }
    return discr
}

function setMainThread(thread, pthread) {

    var div = $('<div>').addClass('detail__description')
    div.text(AnalyzeThread(thread, pthread))
    $('div#main > div:last-child').prepend(div)


}
function setOtherThread(thread, pthread) {
    var div = $('<div>').addClass('detail__description')
    div.text(AnalyzeThread(thread, pthread))
    var div_disc = $(`div#${thread.IndexID} > div:last-child`)
    div_disc.prepend(div)

}
function init_text() {
    for (idx = 0; idx < $('.mark').length; idx++)
        $('.line .mark').text("　")
}
function set_text(data) {
    contents = String(data).split('\n');
    for (var s_idx = 0; s_idx < contents.length; s_idx++) {
        var code_tr = $('<tr>').attr({ class: 'line', id: s_idx })
        code_tr.append($('<td>').text(s_idx + 1))
        code_tr.append($('<td>').addClass('mark'))
        code_tr.append($('<td>').text(contents[s_idx]))

        $('#codeLine').append(code_tr)
    }
}

var color_set = ['#ff7f7f', '#ff7fbf', '#ff7fff', '#bf7fff', '#7f7fff', '#7fbfff', '#7fffff', '#7fff7f', '#bfff7f', '#ffff7f', '#ffbf7f']
