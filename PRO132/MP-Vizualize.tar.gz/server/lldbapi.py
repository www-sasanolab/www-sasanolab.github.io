
import lldb
import threading
import subprocess
import platform
import Cparse


class lldbapi:
    ValueType = ['invalid', 'global', 'static', 'arg', 'local', 0, 0, 0, 0]
    StopReason = ['invalid', 'None', 'Trace',
                  'BP', 'WP', 'Signal', 'Exception', 'Exec', 'PlanComplete', 'ThreadExiting']
    PthreadList = ['pthread_join', 'pthread_create']
    PTHREAD_LIBRARY = 'libpthread.so.0'

    def __init__(self):
        self.procState = -1
        self.proc_info = []
        self.WPlist = {}
        self.level = 0
        self.recursion = 20
        self.mode = 0
        self.exit = True
        self.thread = threading.Thread()
        self.func = []
        self.pthread = []
        lldb.SBDebugger.Initialize()
        self.arch = platform.machine()
        self.parser = Cparse.CParse()

    def compile(self, fpath="sample/sample.c", lib="", bin_path="bin/target"):

        com = (
            "gcc %s -l%s -g -o %s" % (fpath, lib, bin_path)
            if lib
            else "gcc %s -g -o %s" % (fpath, bin_path)
        )
        print("COM:" + com)

        res = subprocess.call(com, shell=True)
        if res:
            print("Compile Error")
            return False
        else:
            self.pthread = []
            self.parser.__init__()
            self.parser.SetFilePath(fpath)
            self.parser.Parse()
            self.func = self.parser.parse_data["func"]
            self.selectPthread()
            self.file = lldb.SBFileSpec(fpath)
            if not self.file.IsValid():
                print("File Error")
            self.module = lldb.SBFileSpec(bin_path)
            if not self.module.IsValid():
                print("Module Error")
            return True

    def selectPthread(self):
        for pthread in self.parser.parse_data["pthread"]:
            if pthread["name"] in self.PthreadList:
                self.pthread.append(pthread)

    def __del__(self):
        self.exit = False

    def SetCondition(self, level, limit_recursion, mode):
        self.level = level
        self.recursion = limit_recursion
        self.mode = mode

    def Create(self):
        self.debugger = lldb.SBDebugger.Create()
        self.debugger.SetAsync(False)
        modulepath = self.module.GetDirectory()+'/'+self.module.GetFilename()
        self.target = self.debugger.CreateTargetWithFileAndArch(
            modulepath, self.arch)
        if not self.target.IsValid():
            print("Target Error")
            return
        # self.CreateBPAtAllLine()
        self.CreateBPAtFunc()
        if self.mode == 1:
            for pthread in self.pthread:
                self.CreateBPAtLine(pthread['line'])

    def Launch(self):
        self.process = self.target.LaunchSimple(None, None, ".")
        self.StoreProcessInfo()

    def Continue(self):
        self.process.Continue()
        self.StoreProcessInfo()

    def AllThreadStepOver(self):
        thread = self.process.GetThreadAtIndex(0)
        thread.StepOver(lldb.eAllThreads)
        self.StoreProcessInfo()

    def OnlyThreadStepOver(self, thread_id):
        thread = self.process.GetThreadByID(thread_id)
        thread.StepOver(lldb.eOnlyThisThread)
        self.StoreProcessInfo()

    def Input(self, input):
        input += "\n"
        self.process.PutSTDIN(input)

    def Output(self):
        out = self.process.GetSTDOUT(2048)
        return out if out else ""

    def info_free(self):
        for t_idx in range(len(self.proc_info)):
            try:
                del self.proc_info[t_idx]
            except IndexError:
                pass
        self.proc_info.__init__()

    def CreateBPAtFunc(self):
        for func in self.func:
            bp = self.target.BreakpointCreateByName(func)
            if not bp.IsValid():
                print("Can not Create BP at main()")

    def CreateBPAtAllLine(self):
        filepath = self.file.GetDirectory()+'/'+self.file.GetFilename()
        lineNum = sum([1 for _ in open(filepath)])
        print("line number :" + str(lineNum))
        for line in range(1, lineNum + 1):
            bp = self.target.BreakpointCreateByLocation(filepath, line)
            if not bp.IsValid():
                print("Can not Create BP(line:%s)" % str(line))

    def CreateBPAtLine(self, line):
        filepath = self.file.GetDirectory()+'/'+self.file.GetFilename()
        bp = self.target.BreakpointCreateByLocation(filepath, line)
        if not bp.IsValid():
            print("Can not Create BP(line:%s)" % str(line))

    def StoreProcessInfo(self):
        if not self.process.IsValid():
            print("Process Error")
            return
        self.info_free()
        self.procState = self.process.GetState()
        self.thread_num = self.process.GetNumThreads()
        for idx in range(self.thread_num):
            thread = self.process.GetThreadAtIndex(idx)
            self.proc_info.append(self.StoreThreadInfo(thread))

    def StoreThreadInfo(self, thread):
        if not thread.IsValid():
            print("Thread Error")
            return
        t_dict = dict()
        t_dict["ID"] = thread.GetThreadID()
        t_dict["IndexID"] = thread.GetIndexID()
        t_dict["flist"] = []
        t_dict["access"] = []
        t_dict["StopReason"] = self.StopReason[thread.GetStopReason()]
        if thread.GetStopReason() == lldb.eStopReasonWatchpoint:
            for reason_idx in range(thread.GetStopReasonDataCount()):
                wp_key = thread.GetStopReasonDataAtIndex(reason_idx)
                t_dict["access"].append(self.WPlist[wp_key])
                # print(self.WPlist[wp_key])

        for idx in range(thread.GetNumFrames()):
            frame = thread.GetFrameAtIndex(idx)
            f_dict = self.StoreFrameInfo(frame)
            if f_dict is not None:
                t_dict['flist'].append(f_dict)
        return t_dict

    def StoreFrameInfo(self, frame):
        if not frame.IsValid():
            print("Frame Error")
            return
        f_dict = dict()
        f_dict['ID'] = frame.GetFrameID()
        f_dict['name'] = frame.GetDisplayFunctionName()
        f_dict['vlist'] = []
        if frame.GetLineEntry().IsValid():
            f_dict['line'] = frame.GetLineEntry().GetLine()
            # return f_dict

        f_dict['module'] = frame.GetModule().GetFileSpec().GetFilename()
        v_list = frame.GetVariables(True, True, True, False)
        f_dict["vnum"] = v_list.GetSize()
        if self.mode == 1 and f_dict["module"] == self.PTHREAD_LIBRARY:
            return f_dict
        if self.level == 1 or ('line' in f_dict and f_dict['module'] == self.module.GetFilename()):
            for idx in range(v_list.GetSize()):
                variable = v_list.GetValueAtIndex(idx)
                f_dict["vlist"].append(
                    self.StoreVariableInfo(variable, 0))
            return f_dict
        else:
            return

    def StoreVariableInfo(self, variable, deep):
        if(not variable.IsValid()):
            print("variable is not valid")
            return
        v_dict = dict()
        v_dict["addr"] = variable.GetLoadAddress()
        v_dict["type"] = variable.GetTypeName()
        v_dict["name"] = variable.GetName()
        v_dict["value"] = variable.GetValue()
        v_dict["attr"] = self.ValueType[variable.GetValueType()]
        v_dict['child'] = []
        if variable.MightHaveChildren():
            for v_idx in range(variable.GetNumChildren()):
                if deep > self.recursion:
                    return v_dict
                child = variable.GetChildAtIndex(v_idx)
                deep += 1
                v_dict["child"].append(self.StoreVariableInfo(child, deep))
        v_dict["value"] = variable.GetValue()
        v_dict["attr"] = self.ValueType[variable.GetValueType()]
        if deep == 0:
            if v_dict["attr"] != "local":
                self.setWP(variable, v_dict['name'])
        if self.mode == 1:
            if v_dict["type"] == "pthread_mutex_t":
                variable__data = variable.GetChildMemberWithName("__data")
                variable__lock = variable__data.GetChildMemberWithName(
                    "__lock")
                variable__owner = variable__data.GetChildMemberWithName(
                    "__owner")
                if variable__lock.IsValid():
                    self.setWP(variable__lock, v_dict['name']+'.__lock')
                if variable__owner.IsValid():
                    self.setWP(variable__owner, v_dict['name']+'.__owner')
        # v_dict["size"] = vlist.GetByteSize()
        # v_dict["decl_line"] = vlist.GetDeclaration().GetLine()
        return v_dict

    def setWP(self, variable, name):
        # print(self.WPlist)
        WP = variable.Watch(True, False, True, lldb.SBError())
        if WP.IsValid():
            if WP.GetID() not in self.WPlist.keys():
                self.WPlist[WP.GetID()] = name
