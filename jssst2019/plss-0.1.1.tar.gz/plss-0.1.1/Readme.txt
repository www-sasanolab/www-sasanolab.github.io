PLSS version 0.1.1
(Perturbation-based Learning Support System)

[0.1.0からの変更点]
画像の変更

MacOS Mojave 10.14.6及びUbuntu18.04.1で動作確認済

[Server側　共通]
・Node.jsライブラリ群(npmでインストール)
http-errors     version 1.7.3
express         version 4.16.4
cookie-parser   version 1.4.4
morgan          version 1.9.1
multer          version 1.4.2
python-shell    version 0.50.0
ejs             version 2.5.9
compile-run     version 2.3.2

・DBServerについて
MySQLを用いたDBServerを使用
testという名前のデータベースを作成
test@localhostよりtestという名前のテーブルを作成
testテーブルのカラムは、
v_id        int
s_id        int
answer      varchar(1024)
correct     boolean
time        int
filename    varchar(30)

ユーザtestにtestテーブルへのアクセス権限を付与する

[Server側　MacOS]
・Clang
MacOS : Apple LLVM version 10.0.1 (clang-1001.0.46.4)

・パッケージ(Homebrew version 2.1.1でインストール)
llvm     version 8.0.1 
pip3     version 19.1.1
nodejs   version 8.16.0
npm      version 6.4.1
python   version 3.7.4
mysql    version 8.0.17

サーバーのインストールおよび実行手順(MacOSの場合)
1. 上記のパッケージ及びライブラリをインストール
2. PYTHONPATHに/usr/local/opt/llvm/lib/python2.7/site-packagesを追加
3. LD_LIBRARY_PATHに$(llvm-config --libdir)を追加
4. mysql.serverを起動
5. パスワードが「test」であるユーザー「test」を作成し、このユーザーでテーブル「test」を作成する
    (plss-0.1.1/routes内にあるQuestion.jsの6行目から9行目においてテーブルを指定)
    (ソースコード直書きのため、セキュリティを考慮する場合はユーザ名、パスワードを変更して別の場所においてください)
6. plss-0.1.1ディレクトリにおいて上記のNode.jsライブラリ群をインストール
    (例) npm install http-errors
7. plss-0.1.1/bin/においてwwwをnodejsで実行(ポート番号3000でWebサーバーが起動。wwwの14行目においてポート番号3000を指定。)
    (例) node www

[Server側　Ubuntu]
・Clang
Ubuntu : clang version 6.0.0-1ubuntu2 (tags/RELEASE_600/final)

・パッケージ(apt version 1.6.12でインストール)
llvm     version 6.0.0
pip3	 version 9.0.1
nodejs	 version 8.10.0
npm	 version 3.5.2
python	 version 3.6.8
mysql	 version 14.14

・pip3ライブラリ群(Ubuntuで動作させる際に必要)
clang		version 6.0.0.2

サーバーのインストールおよび実行手順(Ubuntuの場合)
1. 上記のパッケージ及びライブラリのインストール
2. LD_LIBRARY_PATHに$(llvm-config --libdir)を追加
3. mysql.serverを起動
4. パスワードが「test」であるユーザー「test」を作成し、このユーザーでテーブル「test」を作成する
    (plss-0.1.1/routes内にあるQuestion.jsの6行目から9行目においてテーブルを指定)
    (ソースコード直書きのため、セキュリティを考慮する場合はユーザ名、パスワードを変更して別の場所においてください)
5. plss-0.1.1ディレクトリにおいて上記のNodejsライブラリ群をインストール
    (例) npm install http-errors
6. plss-0.1.1/bin/においてwwwをnodejsで実行(ポート番号3000でWebサーバーが起動。wwwの14行目においてポート番号3000を指定。)
    (例) node www

[Client側]
実行方法
ブラウザにおいてURLに以下を指定してアクセス
http://<IPアドレス>:3000/
あるいは
http://<ホスト名>:3000/
※Chrome、Safari、Firefoxにて動作確認済み(ただし、Chrome推奨)

[著者名] 吉塚 大浩
[リリース日] 2019年9月27日
[連絡先] ma19092@shibaura-it.ac.jp
