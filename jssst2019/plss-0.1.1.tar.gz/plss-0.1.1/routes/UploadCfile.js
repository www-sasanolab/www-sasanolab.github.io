var express = require('express')
var router = express.Router();
var multer = require('multer');
var fs = require('fs');
var Pythonshell = require('python-shell')


var upload = multer({
    dest: '../uploads/'
});

router.get('/', function (req, res) {
    res.render('UC', { title: 'Mutation' });
});

router.post('/', upload.single('importfile'), function (req, res) {
    var filename = req.file.originalname;
    var dt = new Date();
    fs.rename(req.file.path, '../cfile/' + filename, function (err) {
        console.log(filename + ' Upload Complete!');
    })

    var option = {
        args: ['../cfile/' + filename]
    };

    Pythonshell.run('../python/mutation.py', option, function (err, results) {
        if (err) console.log(err);
        console.log(results);
    })

    if (!fs.existsSync('../mutant/' + filename)) {
        fs.mkdirSync('../mutant/' + filename, function (err, folder) {
            if (err) throw err;
            console.log(folder)
        })
    }
    if (!fs.existsSync('../result/' + filename)) {
        fs.mkdirSync('../result/' + filename, function (err, folder) {
            if (err) throw err;
            console.log(folder)
        })
    }

    res.render('UC', { title: 'Mutation' });
    console.log(req.file);
});

module.exports = router;

