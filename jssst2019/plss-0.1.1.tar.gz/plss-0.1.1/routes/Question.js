var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mysql = require('mysql')
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'test',
    password: 'test'
})
connection.connect(function (err) {
    if (err) console.log(err.stack);
    else console.log('connection_id:' + connection.threadId)
})


function strComb(array, val) {
    var str = "";
    for (var i in array) {
        str += array[i] + val;
    }
    return str;
}
router.get('/', function (req, res, next) {
    var dir = req.query.filename
    var files = fs.readdirSync('../mutant/' + dir);
    var id = Math.floor(Math.random() * files.length);
    try {
        var contents = fs.readFileSync('../mutant/' + dir + '/' + files[id], 'UTF-8').replace('<', '&lt').replace('>', '&gt');
    } catch (e) {
        console.log(e)

    }
    console.log(contents)
    var studentID = req.query.studentID;
    var virtualID;
    var vID_data = fs.readFileSync("../virtualIDlist.txt", 'UTF-8').split("\n")
    for (i = 0; i < vID_data.length; i++) {
        if (vID_data[i] == '') {
            virtualID = i;
            vID_data[i] = i;
            vID_data = strComb(vID_data, '\n')
            fs.writeFileSync('../virtualIDlist.txt', vID_data)
            break;
        }
    }
    res.render('question', {
        filename: dir,
        contents: contents,
        id: id + 1,
        studentID: studentID,
        virtualID: virtualID
    })
});

function check_answer(answer, result) {
    if (answer == result) return true
    else return false
}

router.post('/check', function (req, res, next) {
    var body = JSON.parse(req.body.data)
    var answer = body.answer;
    var filename = body.filename;
    var id = body.id;
    var time = req.body.time;
    var virtualID = req.body.virtualID;
    var studentID = req.body.studentID;
    var mutantname = 'mutant-' + id.slice(-1) + '-' + filename
    var result = fs.readFileSync('../result/' + filename + '/mutant-' + id.slice(-1) + '-' + filename.split('.')[0] + '.txt', 'UTF-8')
    var correct = check_answer(answer, result);

    console.log(virtualID, studentID, filename, time, answer, correct);
    var sql = 'INSERT INTO test.test values(?,?,?,?,?,?)'
    var inserts = [virtualID, studentID, answer, correct, time, mutantname];
    sql = mysql.format(sql, inserts)
    connection.query(sql, function (err, result, fields) {
        if (err) console.log(err)
    })
    console.log(sql)
    res.send(correct)
});
router.post('/next', function (req, res, next) {
    var body = JSON.parse(req.body.data)
    var id = body.id;
    var filename = body.filename;
    var files = fs.readdirSync('../mutant/' + filename);
    var data = { contents: "" }
    var random;
    var virtualID = req.body.virtualID;
    if (id.length != files.length) {
        while (true) {
            random = Math.floor(Math.random() * files.length);
            if (id.indexOf(random + 1) > -1) continue;
            else break;
        }
        data.contents = fs.readFileSync('../mutant/' + filename + '/' + files[random], 'UTF-8');
        data.id = random + 1;
        res.send(data)
    } else {
        var vID_data = fs.readFileSync("../virtualIDlist.txt", 'UTF-8').split("\n")
        vID_data[virtualID] = '';
        vID_data = strComb(vID_data, '\n')
        fs.writeFileSync('../virtualIDlist.txt', vID_data)
        res.send("complete");
    }
})

module.exports = router;