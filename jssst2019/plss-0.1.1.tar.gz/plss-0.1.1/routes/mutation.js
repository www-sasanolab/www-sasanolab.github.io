var yellow = '\u001b[33m';
var magenta = '\u001b[35m';

var reset = '\u001b[0m';
var BO_List = [
    ['+', '-', '*', '/', '%'],
    ['==', '!='],
    ['<<', '>>'],
    ['<', '>', '<=', '>='],
    ['&&', '||'],
    ['&', '|', '^'],
    ['=']
]

function make_mutation(str) {
    mutants = [str]
    for (i = 0; i < BO_List.length; i++) {
        for (j = 0; j < BO_List[i].length; j++) {
            if (str == BO_List[i][j]) {
                for (k = 0; k < BO_List[i].length; k++) {
                    if (k != j)
                        mutants.push(BO_List[i][k])
                }
                return mutants
            }
        }
    }
}
exports.add_option_tag = function (str) {
    if (str != '=')
        var mutants = make_mutation(str);
    else return '';

    console.log(mutants)
    var tag = '';
    for (var i = 0; i < mutants.length; i++) {
        tag += '<option>' + mutants[i] + '</option>\n';
    }
    console.log(magenta + tag + reset);
    return tag;
}

exports.random_mutation = function (str) {
    if (str != '=')
        var mutants = make_mutation(str);
    else return '';
    if (mutants.length == 0) {
        return '';
    }
    var random = Math.floor(Math.random() * (mutants.length - 1));

    console.log(yellow + 'str:' + mutants + reset);
    return mutants[random];
}