var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var path = require('path');
var app = express();
app.use(express.static(path.join(__dirname, 'public')));
var file_part = fs.readFileSync('../views/part.ejs', 'UTF-8');

router.get('/', function (req, res, next) {
    var list, src, type = req.query.type;
    var filename = req.query.filename
    var url = "/contents"
    var back_url = '/TeaMenu'
    var parts = '';
    var studentID = ''

    if (type == "mutant") {
        list = fs.readdirSync('../mutant');
        console.log(list)
        src = "/images/dir_icon.jpeg"
        type = "mutant-list"
        url = "/list"
    } else if (type == "mutant-list") {
        list = fs.readdirSync('../mutant/' + filename);
        type = "mutant"
        src = "/images/file_icon.jpeg";
        back_url = '/list?type=mutant'
    } else if (type == 'question') {
        list = fs.readdirSync('../mutant');
        console.log(list)
        src = "/images/dir_icon.jpeg"
        type = "question"
        url = "/Question"
    } else {
        if (type == "mutation") url = '/make'
        list = fs.readdirSync('../cfile');
        src = "/images/file_icon.jpeg"
    }

    if (req.query.menu == 'stu') back_url = '/StuMenu'

    for (i in list) {
        if (list[i].match(/.*\.c/)) {
            var part = ejs.render(file_part, {
                url: url,
                filename: list[i],
                type: type,
                src: src,
                studentID: studentID
            });
            parts += part;
        }
    }

    res.render('list', {
        title: type + 'リスト',
        contents: parts,
        url: back_url,
        type: type
    });
});

module.exports = router;