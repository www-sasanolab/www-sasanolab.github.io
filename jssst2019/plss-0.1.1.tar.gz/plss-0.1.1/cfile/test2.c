#include<stdio.h>

int main(void){
  int a=0,i;
  for(i=0;i<4;i=i-2)
    a++;
  printf("a=%d\n",a);
  return 0;
}
