#!/usr/bin/python
import os
import webbrowser
import javadiff
import sys

def htmlize(left,right,outname,f1ln,f2ln):
	outfile = open(outname, 'w')
	outfile.write(html_head())
	outfile.write(write_html(javadiff.Text1(left, javadiff.delete, javadiff.move, javadiff.modi_line,f1ln),'l'))
	outfile.write(write_html(javadiff.Text2(right, javadiff.add, javadiff.move, javadiff.modi_line,f2ln),'r'))
	outfile.write(html_footer())
	outfile.close()



def html_head():
	out=[]

	css_file=open('review.css','r')
	css_text=css_file.read()
	css_file.close()

	out.append('<html>\n')
	out.append('<head>\n')
	out.append('<META http-equiv="Content-Type" content="text/html; charset=utf-8">\n')

	out.append('<style>\n')
	out.append(css_text)
	out.append('\n</style>\n')

	out.append('</head>\n')
	out.append('<body>\n')
	out.append('<div class="row">\n')
	return ''.join(out)

def html_footer():
	out =[]
	out.append('</div>\n')
	out.append('</body>\n')
	out.append('</html>\n')
	return ''.join(out)


def write_html(text,side):
	out=[]
	out.append('<div class="column">\n')
	out.append(text)
	out.append('<hr>')
	if side == 'l':
		out.append('<a class="d">deleted</a> ')
	else:
		out.append('<a class="i">added</a> ')
	out.append('<a class="m">moved</a> ')
	out.append('<a class="c">changed</a>')
	out.append('</div>\n')
	return ''.join(out)

def diff(file1,file2):
	f1ln,f2ln=javadiff.diff(file1,file2)
	htmlize(file1,file2,'page.html',f1ln,f2ln)
	filename = 'file:///' + os.getcwd() + '/' + 'page.html'
	webbrowser.open(filename)

def main():
	if len(sys.argv) == 3:
		file1 = sys.argv[1]
		file2 = sys.argv[2]
		diff(file1, file2)



if __name__ == '__main__':
    main()