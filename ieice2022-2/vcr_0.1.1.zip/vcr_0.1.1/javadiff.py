import javalang
import difflib

move=[]
add=[]
delete=[]
rline=[]
modi_line=[]
modi=[]
diff_line = []
words=[]
sorted_modi = []
SIMILARITY=0.5
MAX=-1
MAXI=-1
MAXJ=-1



def get_diff_line(file1,file2):
    file_1 = open(file1, 'r')
    file_2 = open(file2, 'r')
    file_1_lines = file_1.readlines()
    file_2_lines = file_2.readlines()
    f1ln=len(file_1_lines)
    f2ln=len(file_2_lines)
    d=difflib.Differ()
    diff_line=list(difflib.unified_diff(file_1_lines,file_2_lines))
    file_1.close()
    file_2.close()
    return diff_line,f1ln,f2ln

def format(line):
    return line[0].replace('\t','').lstrip().rstrip()

def lformat(line):
    return line.replace('\t','').lstrip().rstrip()

def similar(s1, s2):
    return difflib.SequenceMatcher(None, s1, s2).ratio()

def get_delete(diff_line):
    global delete
    flag=False
    lineno=0
    pline=0
    for line in diff_line:
        lineno = lineno + 1
        if line[0]=='@':
            flag=True
            lineno=0
            pline=0
            start = int(line.replace('@@ -', '').split(',')[0])
        if line[0] == '+' and line[0:2] != '++':
            pline=pline+1
        if line[0]=='-' and line[0:2]!='--':
            dline=start+lineno-1-pline
            delete.append((line[1:],dline))
    return delete

def get_add(diff_line):
    global add
    flag = False
    lineno = 0
    mline=0
    for line in diff_line:
        lineno = lineno + 1
        if line[0] == '@':
            flag = True
            lineno = 0
            mline=0
            start = int(line.split('+')[1].split(',')[0])
        if line[0]=='-' and line[0:2]!='--':
            mline=mline+1
        if line[0] == '+' and line[0:2] != '++':
            aline = start + lineno-mline-1
            add.append((line[1:], aline))
    return add


def get_move(delete, add):
    global move
    global rline
    if add == [] or delete == []:
        return move
    else:
        for delete_line in delete:
            for add_line in add:
                if format(delete_line)==format(add_line) and delete_line[1]!=add_line[1]:
                    if delete_line[0]!='\n':
                        move.append((delete_line,add_line))
                if format(delete_line)==format(add_line) and delete_line[1]==add_line[1]:
                    rline.append((delete_line,add_line))

    for delete_line in delete[:]:
        for line in move:
            if delete_line == line[0]:
                if not line[0] in delete:
                    continue
                else:
                    delete.remove(delete_line)
    for add_line in add[:]:
        for line in move:
            if add_line == line[1]:
                if not line[1] in add:
                    continue
                else:
                    add.remove(add_line)
    for delete_line in delete[:]:
        for line in rline:
            if delete_line == line[0]:
                if not line[0] in delete:
                    continue
                else:
                    delete.remove(delete_line)
    for add_line in add[:]:
        for line in rline:
            if add_line == line[1]:
                if not line[1] in add:
                    continue
                else:
                    add.remove(add_line)
    return move

def get_word(s):
    tokens = list(javalang.tokenizer.tokenize(s))
    words=[]
    for i in range(len(tokens)):
        words.append((tokens[i].value))
    return words

def get_modi_line_r(delete,add):
    size_x = len(delete)
    size_y = len(add)
    if not delete or not add:
        return modi_line
    else:
        max=MAX
        maxi=MAXI
        maxj=MAXJ
        for x in range(size_x):
            for y in range(size_y):
                similarity=similar(format(delete[x]), format(add[y]))
                if similarity > SIMILARITY and similarity > max and similarity!=1.0:
                    max = similarity
                    maxi = x
                    maxj = y
        if max!=MAX:
            modi_line.append((delete[maxi],add[maxj]))
            delete.remove(delete[maxi])
            add.remove(add[maxj])
            get_modi_line_r(delete,add)
        else:
            return modi_line


def get_modi_line(delete, add):
    global modi_line
    if add == [] or delete == []:
        return modi_line
    else:
        get_modi_line_r(delete,add)
    return modi_line

def get_change_position(p,v):
    line=p.line
    long=len(v)
    start=p.column-1
    end=start+long
    return (line, start, end)

def get_word_position_r(word1,word2,side,line):
    size_x = len(word1)
    size_y = len(word2)
    if not word1 or not word2:
        return modi
    else:
        max=MAX
        maxi=MAXI
        maxj=MAXJ
        for x in range(size_x):
            for y in range(size_y):
                similarity=similar(word1[x], word2[y])
                if similarity > max:
                    max = similarity
                    maxi = x
                    maxj = y
        if max !=MAX and maxi != MAXI and maxj != MAXJ:
            if side == 'l':
                start =line.find(word1[maxi])
                length = len(word1[maxi])
            else:
                start = line.find(word2[maxj])
                length = len(word2[maxj])
            end = start + length
            modi.append([start, end])
            word1.remove(word1[maxi])
            word2.remove(word2[maxj])
            get_word_position_r(word1,word2,side,line)
        else:
            return modi


def get_word_position(word1,word2,side,line):
    global modi
    modi=[]
    get_word_position_r(word1,word2,side,line)
    return modi

def diff(file1,file2):
    diff_line,f1ln,f2ln=get_diff_line(file1,file2)
    get_delete(diff_line)
    get_add(diff_line)
    get_move(delete, add)
    get_modi_line(delete, add)
    return f1ln,f2ln

def Text1(java, delete, move, modi_line,f1ln):
    file=open(java,'r')
    lines=file.readlines()
    start=0
    end=0
    out=[]
    linenm=0
    out.append('<pre>')
    flag=False
    n=len(str(f1ln))
    newlist=[]
    found=set()
    for x in move:
        if x[0][1] not in found:
            newlist.append(x[0][1])
        found.add(x[0][1])
    for line in lines:
        linenm=linenm+1
        linenumber=str(('{: >'+str(n)+'}').format(linenm))
        if newlist != []:
            for mline in newlist:
                if linenm==mline:
                    mtoken=list(javalang.tokenizer.tokenize(line))
                    mstart=mtoken[0].position[1]-1
                    out.append('<a >'+linenumber+' '+line[:mstart].replace('\n','')+'</a>')
                    out.append('<a class="m">'+line[mstart:].replace('\n','')+'</a>\n')
                    flag=True
                    continue
                else:
                    continue
        if modi_line !=[]:
            nword1=[]
            nword2=[]
            for mdline in modi_line:
                if linenm == mdline[0][1]:
                    word1=get_word(mdline[0][0])
                    word2=get_word(mdline[1][0])
                    for x in range(len(word1)):
                        for y in range(len(word2)):
                            if word1[x]!=word2[y] and x==y:
                                nword1.append(word1[x])
                                nword2.append(word2[y])
                    modi_word=get_word_position(nword1,nword2,'l',mdline[0][0])
                    if modi_word==[]:
                        mtoken = list(javalang.tokenizer.tokenize(line))
                        if mtoken!=[]:
                            mstart = mtoken[0].position[1] - 1
                            out.append('<a>' + linenumber +' '+ line[:mstart].replace('\n', '') + '</a>')
                            out.append('<a class="d">' + line[mstart:].replace('\n', '') + '</a>\n')
                            flag=True
                            continue
                    else:
                        modi_word.sort(key=lambda x: x[0])
                        s=modi_word[0][0]
                        out.append('<a>' + linenumber + ' ' + line[:s].replace('\n', '') + '</a>')
                        for i in range(len(modi_word)):
                            start=modi_word[i][0]
                            end=modi_word[i][1]
                            out.append('<a class="c">'+line[start:end].replace('\n','')+'</a>')
                            if i+1<len(modi_word):
                                nstart=modi_word[i][1]
                                nend=modi_word[i+1][0]
                                out.append('<a>' + line[nstart:nend].replace('\n', '') + '</a>')
                        e=modi_word[-1][1]
                        out.append('<a>'+ line[e:].replace('\n', '') + '</a>\n')
                        flag = True
                    continue
        if delete!=[]:
            for dline in delete:
                if linenm==dline[1]:
                    dtoken=list(javalang.tokenizer.tokenize(line))
                    if dtoken!=[]:
                        dstart=dtoken[0].position[1]-1
                        out.append('<a>'+linenumber+' '+line[:dstart].replace('\n','')+'</a>')
                        out.append('<a class="d">'+line[dstart:].replace('\n','')+'</a>\n')
                        flag=True
                        continue
                    else:
                        out.append('<a class="dg">'+linenumber+' '+line.replace('\n','')+'</a>')
                        flag=True
                        continue
        if rline!=[]:
            for xline in rline:
                if "\n" in xline[0][0] and not "\n" in xline[1][0] and linenm==xline[0][1]:
                    dtoken = list(javalang.tokenizer.tokenize(line))
                    if dtoken != []:
                        dstart = dtoken[0].position[1] - 1
                        out.append('<a>' + linenumber + ' ' + line.replace('\n', '') + '</a>\n')
                        linenm = linenm + 1
                        linenumber = str(('{: >' + str(n) + '}').format(linenm))
                        out.append('<a class="dg">' + linenumber + ' '+ '</a>')
                        flag = True
                        continue
        if flag==True:
            flag=False
        else:
            out.append('<a>'+linenumber+' '+line.replace('\n','')+'</a>\n')
    out.append('</pre>')
    return ''.join(out)


def Text2(java, add, move,modi_line,f2ln):
    file=open(java,'r')
    lines=file.readlines()
    out=[]
    out.append('<pre>')
    flag=False
    n=len(str(f2ln))
    linenm=0
    mn=0
    newlist = []
    found = set()
    move = sorted(move, key=lambda x: x[1][1])
    for x in move:
        if x[1][1] not in found:
            newlist.append(x[1][1])
        found.add(x[1][1])
    for line in lines:
        linenm=linenm+1
        linenumber=str(('{: >'+str(n)+'}').format(linenm))
        if newlist != []:
            for mline in newlist:
                if linenm==mline:
                    mtoken=list(javalang.tokenizer.tokenize(line))
                    mstart=mtoken[0].position[1]-1
                    out.append('<a >'+linenumber+' '+line[:mstart].replace('\n','')+'</a>')
                    out.append('<a class="m">'+line[mstart:].replace('\n','')+'</a>\n')
                    flag=True
                    continue
                else:
                    continue
        if modi_line !=[]:
            for mdline in modi_line:
                nword1=[]
                nword2=[]
                if linenm == mdline[1][1]:
                    word1=get_word(mdline[0][0])
                    word2=get_word(mdline[1][0])
                    for x in range(len(word1)):
                        for y in range(len(word2)):
                            if word1[x]!=word2[y] and x==y:
                                nword1.append(word1[x])
                                nword2.append(word2[y])
                    modi_word=get_word_position(nword1,nword2,'r',mdline[1][0])
                    if modi_word==[]:
                        mtoken = list(javalang.tokenizer.tokenize(line))
                        if mtoken!=[]:
                            mstart = mtoken[0].position[1] - 1
                            out.append('<a>' + linenumber +' '+ line[:mstart].replace('\n', '') + '</a>')
                            out.append('<a class="d">' + line[mstart:].replace('\n', '') + '</a>\n')
                            flag=True
                            continue
                    else:
                        modi_word.sort(key=lambda x: x[0])
                        s=modi_word[0][0]
                        out.append('<a>' + linenumber + ' ' + line[:s].replace('\n', '') + '</a>')
                        for i in range(len(modi_word)):
                            start=modi_word[i][0]
                            end=modi_word[i][1]
                            out.append('<a class="c">'+line[start:end].replace('\n','')+'</a>')
                            if i+1<len(modi_word):
                                nstart=modi_word[i][1]
                                nend=modi_word[i+1][0]
                                out.append('<a>' + line[nstart:nend].replace('\n', '') + '</a>')
                        e=modi_word[-1][1]
                        out.append('<a>'+ line[e:].replace('\n', '') + '</a>\n')
                        flag = True
                    continue
        if add!= []:
            for aline in add:
                if linenm==aline[1]:
                    atoken=list(javalang.tokenizer.tokenize(line))
                    if atoken!=[]:
                        astart=atoken[0].position[1]-1
                        out.append('<a>'+linenumber+' '+line[:astart].replace('\n','')+'</a>')
                        out.append('<a class="i">'+line[astart:].replace('\n','')+'</a>\n')
                        flag=True
                        continue
                    else:
                        out.append('<a class="ig">'+linenumber+' '+line.replace('\n','')+'</a>')
                        flag=True
                        continue
        if rline!=[]:
            for xline in rline:
                if not "\n" in xline[0][0] and "\n" in xline[1][0] and linenm==xline[1][1]:
                    dtoken = list(javalang.tokenizer.tokenize(line))
                    if dtoken != []:
                        dstart = dtoken[0].position[1] - 1
                        out.append('<a>' + linenumber + ' ' + line.replace('\n', '') + '</a>\n')
                        linenm = linenm + 1
                        linenumber = str(('{: >' + str(n) + '}').format(linenm))
                        out.append('<a class="ig">' + linenumber + ' '+ '</a>')
                        flag = True
                        continue
        if flag==True:
            flag=False
        else:
            out.append('<a>'+linenumber+' '+line.replace('\n','')+'</a>\n')
    out.append('</pre>')
    return ''.join(out)





