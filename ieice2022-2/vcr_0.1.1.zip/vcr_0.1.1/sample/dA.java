import java.util.Scanner;
class A {
    int lineNumber =2;
    public void move(){
    }
}
class B {
    int b=2;
}
