import java.util.Scanner;
class A {
    int lineNumber =2;
    public void move(){
        int b=2;
        int c=3;
    }
}
class B {
    int a_c=2;
    int c_ahu=2;
    int d_c=1;
}
