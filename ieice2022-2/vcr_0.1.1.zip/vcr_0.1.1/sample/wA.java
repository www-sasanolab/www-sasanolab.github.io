import java.util.Scanner;
class A {
    int lineNumber =2;
    public void move(){
    }
}
class B {
    double b_c=2;
    int b=2;
    int c=3;
    int c_a=3;
    int d=2;
}
