import java.util.Scanner; // import the Scanner class
import java.time.LocalDate;// import the LocalDate class
import java.unil.ArrayList;
import java.io.File;
import java.io.IOException;
/* The code is Main Class
*/

abstract class Animal{
    //Abstract method
    public abstract void animalSound();
    //Regular method
    public void sleep() {
        System.out.println("Zzz");
    }
}

class Pig extends Animal {
    public void animalSound(){
        System.out.println("The pig says: woo woo");
    }
}

interface Modify {
    public void add();
    public void delete();
    public void move();
}

class Answer implements Modify {
    public void add(){
        System.out.println("The answer is that: ");
    }
    public void delete(){
        System.out.println("The answer is: ");
    }
    public void move(){
        System.out.println("The answer is: ");
    }
}


class People{
    public void speak_language(){
        system.out.println("The people speak a language");
    }
}

class American extends People{
    public void speak_language(){
        system.out.println("The American speak English");
    }
}

class Chinese extends People{
    public void speak_language(){
        system.out.println("The Chinese speak Chinese");
    }
}



public class Fruit{
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }
}

public class Main{
    int modelYears;
    String modelName;


    public Main(int year, String name) {
        modelYears=year; //Set the initial value for the class attribute x
        modelName=name;
    }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public void print_medium(){
        Level myVar = Level.MEDIUM;
        switch(myVar){
        case LOW:
            System.out.println("Low Level")
            break;
        case MEDIUM:
            System.out.println("Medium Level")
            break;
        case HIGH:
            System.out.println("HIGH Level")
            break;
        }
    }

    public void scan_info(){
        Scanner myObj=new Scanner(System.in); //Create a Scanner object

        System.out.println("Enter name, age and salary:");

        //String input

        String name = myObj.nextline();

        //Numberical input
        int age =myObj.nextInt();
        double salary = myObj.nextDouble();

        //Output input by user
        System.out.println("Name: "+ name);
        System.out.println("Age: "+ age);
        System.out.println("Salary: "+ salary);

    }

    public void display_formatted_date_time(){
        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before formatting: "+myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate=myDateObj.format(myFormatObj);
        System.out.println("After formatting: " + formattedDate);
    }


    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }

    public static void main(String[] args) {

        int result=sum(10);
        System.out.print(result);

        scan_info();
        display_formatted_date_time();
        print_medium();

        Fruit orange=new Fruit();
        orange.setName("Orange");
        System.out.println(apple.getName());

        Main myMain=new Main(1970, "Sun");
        System.out.println(myMain.modelYear+" "+myMain.modelName);

        Pig myPig_r=new Pig();
        myPig_r.animalSound();
        myPig_r.sleep();

        Answer myModi=new Answer();
        myModi.add();
        myModi.delete();
        myModi.move();

        People people=new People();
        People american=new American();
        People chinese=new Chinese();
        people.speak_language();
        american.speak_language();
        chinese.speak_language();

        ArrayList<String> cars=new ArrayList<String>();
        cars.add("BMW");
        cars.add("Volvo");
        cars.add("Mazda");
        cars.add("Ford");
        cars.add("Toyota")
        System.out.println(cars);

        try{
            File myFile=new File("filename.txt");
            if (myFile.createNewFile()){
                system.out.println("File created: " + myFile.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try{
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter,close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
import java.util.Scanner; // import the Scanner class
import java.time.LocalDate;// import the LocalDate class
import java.unil.ArrayList;
import java.io.File;
import java.io.IOException;
/* The code is Main Class
*/

abstract class Animal{
    //Abstract method
    public abstract void animalSound();
    //Regular method
    public void sleep() {
        System.out.println("Zzz");
    }
}

class Pig extends Animal {
    public void animalSound(){
        System.out.println("The pig says: woo woo");
    }
}

interface Modify {
    public void add();
    public void delete();
    public void move();
}

class Answer implements Modify {
    public void add(){
        System.out.println("The answer is that: ");
    }
    public void delete(){
        System.out.println("The answer is: ");
    }
    public void move(){
        System.out.println("The answer is: ");
    }
}


class People{
    public void speak_language(){
        system.out.println("The people speak a language");
    }
}

class American extends People{
    public void speak_language(){
        system.out.println("The American speak English");
    }
}

class Chinese extends People{
    public void speak_language(){
        system.out.println("The Chinese speak Chinese");
    }
}



public class Fruit{
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }
}

public class Main{
    int modelYears;
    String modelName;


    public Main(int year, String name) {
        modelYears=year; //Set the initial value for the class attribute x
        modelName=name;
    }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public void print_medium(){
        Level myVar = Level.MEDIUM;
        switch(myVar){
        case LOW:
            System.out.println("Low Level")
            break;
        case MEDIUM:
            System.out.println("Medium Level")
            break;
        case HIGH:
            System.out.println("HIGH Level")
            break;
        }
    }

    public void scan_info(){
        Scanner myObj=new Scanner(System.in); //Create a Scanner object

        System.out.println("Enter name, age and salary:");

        //String input

        String name = myObj.nextline();

        //Numberical input
        int age =myObj.nextInt();
        double salary = myObj.nextDouble();

        //Output input by user
        System.out.println("Name: "+ name);
        System.out.println("Age: "+ age);
        System.out.println("Salary: "+ salary);

    }

    public void display_formatted_date_time(){
        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before formatting: "+myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate=myDateObj.format(myFormatObj);
        System.out.println("After formatting: " + formattedDate);
    }


    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }

    public static void main(String[] args) {

        int result=sum(10);
        System.out.print(result);

        scan_info();
        display_formatted_date_time();
        print_medium();

        Fruit orange=new Fruit();
        orange.setName("Orange");
        System.out.println(apple.getName());

        Main myMain=new Main(1970, "Sun");
        System.out.println(myMain.modelYear+" "+myMain.modelName);

        Pig myPig_r=new Pig();
        myPig_r.animalSound();
        myPig_r.sleep();

        Answer myModi=new Answer();
        myModi.add();
        myModi.delete();
        myModi.move();

        People people=new People();
        People american=new American();
        People chinese=new Chinese();
        people.speak_language();
        american.speak_language();
        chinese.speak_language();

        ArrayList<String> cars=new ArrayList<String>();
        cars.add("BMW");
        cars.add("Volvo");
        cars.add("Mazda");
        cars.add("Ford");
        cars.add("Toyota")
        System.out.println(cars);

        try{
            File myFile=new File("filename.txt");
            if (myFile.createNewFile()){
                system.out.println("File created: " + myFile.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try{
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter,close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
import java.util.Scanner; // import the Scanner class
import java.time.LocalDate;// import the LocalDate class
import java.unil.ArrayList;
import java.io.File;
import java.io.IOException;
/* The code is Main Class
*/

abstract class Animal{
    //Abstract method
    public abstract void animalSound();
    //Regular method
    public void sleep() {
        System.out.println("Zzz");
    }
}

class Pig extends Animal {
    public void animalSound(){
        System.out.println("The pig says: woo woo");
    }
}

interface Modify {
    public void add();
    public void delete();
    public void move();
}

class Answer implements Modify {
    public void add(){
        System.out.println("The answer is that: ");
    }
    public void delete(){
        System.out.println("The answer is: ");
    }
    public void move(){
        System.out.println("The answer is: ");
    }
}


class People{
    public void speak_language(){
        system.out.println("The people speak a language");
    }
}

class American extends People{
    public void speak_language(){
        system.out.println("The American speak English");
    }
}

class Chinese extends People{
    public void speak_language(){
        system.out.println("The Chinese speak Chinese");
    }
}



public class Fruit{
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }
}

public class Main{
    int modelYears;
    String modelName;


    public Main(int year, String name) {
        modelYears=year; //Set the initial value for the class attribute x
        modelName=name;
    }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public void print_medium(){
        Level myVar = Level.MEDIUM;
        switch(myVar){
        case LOW:
            System.out.println("Low Level")
            break;
        case MEDIUM:
            System.out.println("Medium Level")
            break;
        case HIGH:
            System.out.println("HIGH Level")
            break;
        }
    }

    public void scan_info(){
        Scanner myObj=new Scanner(System.in); //Create a Scanner object

        System.out.println("Enter name, age and salary:");

        //String input

        String name = myObj.nextline();

        //Numberical input
        int age =myObj.nextInt();
        double salary = myObj.nextDouble();

        //Output input by user
        System.out.println("Name: "+ name);
        System.out.println("Age: "+ age);
        System.out.println("Salary: "+ salary);

    }

    public void display_formatted_date_time(){
        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before formatting: "+myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate=myDateObj.format(myFormatObj);
        System.out.println("After formatting: " + formattedDate);
    }


    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }

    public static void main(String[] args) {

        int result=sum(10);
        System.out.print(result);

        scan_info();
        display_formatted_date_time();
        print_medium();

        Fruit orange=new Fruit();
        orange.setName("Orange");
        System.out.println(apple.getName());

        Main myMain=new Main(1970, "Sun");
        System.out.println(myMain.modelYear+" "+myMain.modelName);

        Pig myPig_r=new Pig();
        myPig_r.animalSound();
        myPig_r.sleep();

        Answer myModi=new Answer();
        myModi.add();
        myModi.delete();
        myModi.move();

        People people=new People();
        People american=new American();
        People chinese=new Chinese();
        people.speak_language();
        american.speak_language();
        chinese.speak_language();

        ArrayList<String> cars=new ArrayList<String>();
        cars.add("BMW");
        cars.add("Volvo");
        cars.add("Mazda");
        cars.add("Ford");
        cars.add("Toyota")
        System.out.println(cars);

        try{
            File myFile=new File("filename.txt");
            if (myFile.createNewFile()){
                system.out.println("File created: " + myFile.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try{
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter,close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
import java.util.Scanner; // import the Scanner class
import java.time.LocalDate;// import the LocalDate class
import java.unil.ArrayList;
import java.io.File;
import java.io.IOException;
/* The code is Main Class
*/

abstract class Animal{
    //Abstract method
    public abstract void animalSound();
    //Regular method
    public void sleep() {
        System.out.println("Zzz");
    }
}

class Pig extends Animal {
    public void animalSound(){
        System.out.println("The pig says: woo woo");
    }
}

interface Modify {
    public void add();
    public void delete();
    public void move();
}

class Answer implements Modify {
    public void add(){
        System.out.println("The answer is that: ");
    }
    public void delete(){
        System.out.println("The answer is: ");
    }
    public void move(){
        System.out.println("The answer is: ");
    }
}


class People{
    public void speak_language(){
        system.out.println("The people speak a language");
    }
}

class American extends People{
    public void speak_language(){
        system.out.println("The American speak English");
    }
}

class Chinese extends People{
    public void speak_language(){
        system.out.println("The Chinese speak Chinese");
    }
}



public class Fruit{
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }
}

public class Main{
    int modelYears;
    String modelName;


    public Main(int year, String name) {
        modelYears=year; //Set the initial value for the class attribute x
        modelName=name;
    }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public void print_medium(){
        Level myVar = Level.MEDIUM;
        switch(myVar){
        case LOW:
            System.out.println("Low Level")
            break;
        case MEDIUM:
            System.out.println("Medium Level")
            break;
        case HIGH:
            System.out.println("HIGH Level")
            break;
        }
    }

    public void scan_info(){
        Scanner myObj=new Scanner(System.in); //Create a Scanner object

        System.out.println("Enter name, age and salary:");

        //String input

        String name = myObj.nextline();

        //Numberical input
        int age =myObj.nextInt();
        double salary = myObj.nextDouble();

        //Output input by user
        System.out.println("Name: "+ name);
        System.out.println("Age: "+ age);
        System.out.println("Salary: "+ salary);

    }

    public void display_formatted_date_time(){
        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before formatting: "+myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate=myDateObj.format(myFormatObj);
        System.out.println("After formatting: " + formattedDate);
    }


    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }

    public static void main(String[] args) {

        int result=sum(10);
        System.out.print(result);

        scan_info();
        display_formatted_date_time();
        print_medium();

        Fruit orange=new Fruit();
        orange.setName("Orange");
        System.out.println(apple.getName());

        Main myMain=new Main(1970, "Sun");
        System.out.println(myMain.modelYear+" "+myMain.modelName);

        Pig myPig_r=new Pig();
        myPig_r.animalSound();
        myPig_r.sleep();

        Answer myModi=new Answer();
        myModi.add();
        myModi.delete();
        myModi.move();

        People people=new People();
        People american=new American();
        People chinese=new Chinese();
        people.speak_language();
        american.speak_language();
        chinese.speak_language();

        ArrayList<String> cars=new ArrayList<String>();
        cars.add("BMW");
        cars.add("Volvo");
        cars.add("Mazda");
        cars.add("Ford");
        cars.add("Toyota")
        System.out.println(cars);

        try{
            File myFile=new File("filename.txt");
            if (myFile.createNewFile()){
                system.out.println("File created: " + myFile.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try{
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter,close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
import java.util.Scanner; // import the Scanner class
import java.time.LocalDate;// import the LocalDate class
import java.unil.ArrayList;
import java.io.File;
import java.io.IOException;
/* The code is Main Class
*/

abstract class Animal{
    //Abstract method
    public abstract void animalSound();
    //Regular method
    public void sleep() {
        System.out.println("Zzz");
    }
}

class Pig extends Animal {
    public void animalSound(){
        System.out.println("The pig says: woo woo");
    }
}

interface Modify {
    public void add();
    public void delete();
    public void move();
}

class Answer implements Modify {
    public void add(){
        System.out.println("The answer is that: ");
    }
    public void delete(){
        System.out.println("The answer is: ");
    }
    public void move(){
        System.out.println("The answer is: ");
    }
}


class People{
    public void speak_language(){
        system.out.println("The people speak a language");
    }
}

class American extends People{
    public void speak_language(){
        system.out.println("The American speak English");
    }
}

class Chinese extends People{
    public void speak_language(){
        system.out.println("The Chinese speak Chinese");
    }
}



public class Fruit{
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String newName){
        this.name=newName;
    }
}

public class Main{
    int modelYears;
    String modelName;


    public Main(int year, String name) {
        modelYears=year; //Set the initial value for the class attribute x
        modelName=name;
    }


    enum Level {
        LOW,
        MEDIUM,
        HIGH
    }

    public void print_medium(){
        Level myVar = Level.MEDIUM;
        switch(myVar){
        case LOW:
            System.out.println("Low Level")
            break;
        case MEDIUM:
            System.out.println("Medium Level")
            break;
        case HIGH:
            System.out.println("HIGH Level")
            break;
        }
    }

    public void scan_info(){
        Scanner myObj=new Scanner(System.in); //Create a Scanner object

        System.out.println("Enter name, age and salary:");

        //String input

        String name = myObj.nextline();

        //Numberical input
        int age =myObj.nextInt();
        double salary = myObj.nextDouble();

        //Output input by user
        System.out.println("Name: "+ name);
        System.out.println("Age: "+ age);
        System.out.println("Salary: "+ salary);

    }

    public void display_formatted_date_time(){
        LocalDateTime myDateObj = LocalDateTime.now();
        System.out.println("Before formatting: "+myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate=myDateObj.format(myFormatObj);
        System.out.println("After formatting: " + formattedDate);
    }


    public static int sum(int k){
        if(k>0){
            return k+sum(k-1);
        }else{
            return 0;
        }
    }

    public static void main(String[] args) {

        int result=sum(10);
        System.out.print(result);

        scan_info();
        display_formatted_date_time();
        print_medium();

        Fruit orange=new Fruit();
        orange.setName("Orange");
        System.out.println(apple.getName());

        Main myMain=new Main(1970, "Sun");
        System.out.println(myMain.modelYear+" "+myMain.modelName);

        Pig myPig_r=new Pig();
        myPig_r.animalSound();
        myPig_r.sleep();

        Answer myModi=new Answer();
        myModi.add();
        myModi.delete();
        myModi.move();

        People people=new People();
        People american=new American();
        People chinese=new Chinese();
        people.speak_language();
        american.speak_language();
        chinese.speak_language();

        ArrayList<String> cars=new ArrayList<String>();
        cars.add("BMW");
        cars.add("Volvo");
        cars.add("Mazda");
        cars.add("Ford");
        cars.add("Toyota")
        System.out.println(cars);

        try{
            File myFile=new File("filename.txt");
            if (myFile.createNewFile()){
                system.out.println("File created: " + myFile.getName());
            }else{
                System.out.println("File already exists.");
            }
        }catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try{
            FileWriter myWriter = new FileWriter("filename.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter,close();
            System.out.println("Successfully wrote to the file.");
        }catch(IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}