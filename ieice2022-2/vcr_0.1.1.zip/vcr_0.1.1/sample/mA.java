import java.util.Scanner;
class A {
    int lineNumber =2;
    public void move(){
        int b=2;
    }
}
class B {
    int a=2;
}
