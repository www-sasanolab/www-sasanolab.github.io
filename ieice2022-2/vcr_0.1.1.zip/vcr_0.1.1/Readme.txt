# Name
VCR version 0.1.1
(Visual Code Review Tool)

# Features

ソースコード変更(追加、削除、変更、移動)を色付けて表示

# Version 

Version 0.1.1

[0.1.0からの変更点]
バグの修正
どんな色がどんなソースコード変更を表すか説明の追加

# Requirement

"VCR"を動かすのに必要なライブラリ

javalang
webbrowser

# Installation

事前にPythonとモジュールのjavalangをインストールしてください。

python バージョン 3.10.2

例
pip install javalang

※Windowsの場合、Pathを自動で設定する場合はインストールする時に「Add Python to PATH」にチェックを入れてください。
オプション機能を選択する時、pipにチェックを入れてください。


Windows 10 Proで動作確認済


# 実行手順(Windowsの場合)
1. 上記のパッケージ及びライブラリをインストール
2. コマンドラインで実行

cd vcrのフォルダー

python htmlize.py file1 file2

実際の例
python htmlize.py sample\sample.java sample\nsample.java


[開発者] 吉　祥
[連絡先] ma19501@shibaura-it.ac.jp
[リリース日] 2021年12月18日

