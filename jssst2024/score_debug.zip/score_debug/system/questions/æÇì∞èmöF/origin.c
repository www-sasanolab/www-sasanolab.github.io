#include <stdio.h>
int main(void){
    int x, y, sum, product;

    printf("1つ目の整数を入力: ");
    scanf("%d", &x);

    printf("2つ目の整数を入力: ");
    scanf("%d", &y);

    sum = x - y;
    product = x * y;

    printf("和は%d、積は%dです。\n", sum, product);

    return 0;
}
