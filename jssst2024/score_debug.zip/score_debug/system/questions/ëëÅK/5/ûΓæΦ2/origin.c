#include <stdio.h>
int main(void){
    int apple, orange, sum;

    printf("りんごの購入数を入力: ");
    scanf("%d", &apple);

    printf("みかんの購入数を入力: ");
    scanf("%d", &orange);

    sum = 130 * apple + 30 * orange;

    if(sum < 1000){
        printf("購入できます。\n");
    }else{
        printf("購入できません。\n");
    }

    return 0;
}
