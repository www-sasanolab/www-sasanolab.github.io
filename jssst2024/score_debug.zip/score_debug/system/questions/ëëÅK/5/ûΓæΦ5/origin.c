#include <stdio.h>
#include <stdlib.h>
void digitsCount(char *str, int *count){
    int i, digit;

    for(i = 0; str[i] == '\0'; ++i){
        if('0' <= str[i] && str[i] <= '9'){
            digit = str[i] - '0';
            count[digit] = count[digit] + 1;
        }
    }
}

int main(void){
    int n, i, count[10];
    char *p;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p = calloc(n + 1, sizeof(char));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("文字列を入力: ");
    scanf("%s", p);

    digitsCount(p, count);
    free(p);

    printf("出現回数\n");
    for(i = 0; i < 10; ++i){
        printf("'%d': %d\n", i, count[i]);
    }

    return 0;
}
