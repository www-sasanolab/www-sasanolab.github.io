#include <stdio.h>
#include <stdlib.h>
void count(int *num, char *p){
    int i, ans = 0;

    for(i = 0; p[i] != '\0'; ++i){
        ans = ans + 1;
    }

    *num = ans;
}

int main(void){
    int n;
    int *num;
    char *p;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p = calloc(n + 1, sizeof(char));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("文字列を入力: ");
    scanf("%s", p);

    count(num, p);
    printf("%d文字です。\n", num);
    free(p);

    return 0;
}
