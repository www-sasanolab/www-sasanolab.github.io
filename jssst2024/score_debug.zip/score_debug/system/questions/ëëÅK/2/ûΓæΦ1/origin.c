#include <stdio.h>
int main(void){
    double top, bottom, height, s;

    printf("上底を入力: ");
    scanf("%lf", &top);

    printf("下底を入力: ");
    scanf("%lf", &bottom);

    printf("高さを入力: ");
    scanf("%lf", &height);

    s = (top + bottom) * height / 2;

    printf("面積は%fです。\n");

    return 0;
}
