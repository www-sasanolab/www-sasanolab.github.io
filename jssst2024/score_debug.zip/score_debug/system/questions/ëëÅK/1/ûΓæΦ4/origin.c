#include <stdio.h>
int calcSquare(int height, int width){
    int s = -1;

    if(height > 10){
        s = width * height;
    }

    return s;
}

int main(void){
    int i, a[3][2], count = 0;

    for(i = 0; i < 3; ++i){
        printf("%dつ目の長方形の幅を入力: ", i + 1);
        scanf("%d", &a[i][0]);

        printf("%dつ目の長方形の高さを入力: ", i + 1);
        scanf("%d", &a[i][1]);

        printf("\n");
    }

    for(i = 0; i < 3; ++i){
        if(calcSquare(a[i][0], a[i][1]) != -1){
            printf("%dつ目の長方形の面積は%dです。\n", i + 1, calcSquare(a[i][0], a[i][1]));
            count = count + 1;
        }
    }

    if(count == 0){
        printf("該当する長方形はありません。\n");
    }

    return 0;
}
