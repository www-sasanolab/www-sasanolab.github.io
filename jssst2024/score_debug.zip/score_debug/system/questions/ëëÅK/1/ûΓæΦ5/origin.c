#include <stdio.h>
#include <stdlib.h>
int search(int *target, int *index, int size, int key){
    int i, count = 0;
    target[size] = key;

    for(i = 0; i <= size; ++i){
        if(target[i] == key){
            index[count] = i + 1;
            count = count + 1;
        }
    }

    return count;
}

int main(void){
    int n, i, key, count;
    int *p1, *p2;

    printf("nを入力: ");
    scanf("%d", &n);

    p1 = calloc(n + 1, sizeof(int));
    p2 = calloc(n + 1, sizeof(int));
    if(p1 == NULL || p2 == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    for(i = 0; i < n; ++i){
        printf("%d番目の整数を入力: ", i + 1);
        scanf("%d", &p1[i]);
    }

    printf("探す値: ");
    scanf("%d", &key);

    count = search(p1, p2, n, key);

    if(count){
        printf("%dは", key);
        for(i = 0; i < count - 1; ++i){
            printf("%d番目と", p2[i] + 1);
        }
        printf("%d番目に入力されました。\n", p2[i] + 1);
    }else{
        printf("%dは入力されていません。\n", key);
    }

    free(p1);
    free(p2);

    return 0;
}
