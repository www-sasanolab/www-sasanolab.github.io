#include <stdio.h>
int main(void){
    int x, flag = 0;
    double average, diff;

    printf("平均点を入力: ");
    scanf("%lf", &average);

    printf("学生のテスト点を入力: ");
    scanf("%d", &x);
    diff = x - average;

    if(-5 <= diff && diff <= 5){
        flag = 1;
    }

    if(flag){
        printf("平均点との差は5点より大きいです。\n");
    }else{
        printf("平均点との差は5点以内です。\n");
    }

    return 0;
}
