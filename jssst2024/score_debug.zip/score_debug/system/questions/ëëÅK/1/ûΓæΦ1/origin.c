#include <stdio.h>
int main(void){
    int x, y, quotient, remainder;

    printf("割られる数を入力: ");
    scanf("%d", &x);

    printf("割る数を入力: ");
    scanf("%d", &x);

    quotient = x / y;
    remainder = x % y;

    printf("商は%d、余りは%dです。\n", quotient, remainder);

    return 0;
}
