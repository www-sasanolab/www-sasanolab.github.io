#include <stdio.h>
#include <stdlib.h>
void check(char *p){
    int i, judge = 0;
    char *temp = p;

    while(*temp != '\0'){
        if(*temp == 'c'){
            judge = 1;
            break;
        }

        temp = temp + 1;
    }

    printf("%s に c は", temp);
    if(judge){
        printf("含まれています。\n");
    }else{
        printf("含まれていません。\n");
    }
}

int main(void){
    int n;
    char *p;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p = calloc(n + 1, sizeof(char));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("文字列を入力: ");
    scanf("%s", p);

    check(p);
    free(p);

    return 0;
}
