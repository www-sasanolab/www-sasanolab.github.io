#include <stdio.h>
int main(void){
    double w1, h1, w2, h2, square, triangle, sum;

    printf("長方形の幅を入力: ");
    scanf("%lf", &w1);
    printf("長方形の高さを入力: ");
    scanf("%lf", &h1);
    square = w1 * h1;

    printf("三角形の幅を入力: ");
    scanf("%lf", &w2);
    printf("三角形の高さを入力: ");
    scanf("%lf", &h2);
    triangle = w2 * h2 / 2;

    sum = square + triangle;

    printf("和は%dです。\n", sum);

    return 0;
}
