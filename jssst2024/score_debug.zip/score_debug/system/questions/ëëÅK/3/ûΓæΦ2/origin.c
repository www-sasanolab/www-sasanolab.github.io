#include <stdio.h>
int main(void){
    int x;

    printf("整数を入力: ");
    scanf("%d", &x);

    if(x > 0){
        printf("正の数です。\n");
    }else if(x = 0){
        printf("0です。\n");
    }else{
        printf("負の数です。\n");
    }

    return 0;
}
