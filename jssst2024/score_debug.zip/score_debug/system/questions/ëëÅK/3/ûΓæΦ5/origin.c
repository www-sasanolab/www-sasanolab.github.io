#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
void toCamel(char *str){
    int i, j;

    for(i = 0; str[i] != '\0'; ++i){
        if(str[i] == '_'){
            str[i] = toupper(str[i]);

            for(j = 1; str[i + j] != '\0'; ++i){
                str[i + j] = str[i + j + 1];
            }
        }
    }
}

int main(void){
    int n;
    char *p;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p = calloc(n + 1, sizeof(char));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("文字列を入力: ");
    scanf("%s", p);

    toCamel(p);

    printf("変換後: %s\n", p);
    free(p);

    return 0;
}
