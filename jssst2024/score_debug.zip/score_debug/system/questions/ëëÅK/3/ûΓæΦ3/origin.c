#include <stdio.h>
int main(void){
    int x, y, i = 0, answer = 1;

    printf("xを入力: ");
    scanf("%d", &x);

    printf("yを入力: ");
    scanf("%d", &y);

    while(i < y){
        answer = answer * x;
    }

    printf("答えは%dです。\n", answer);

    return 0;
}
