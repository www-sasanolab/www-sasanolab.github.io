#include <stdio.h>
int main(void){
    int x, y, z, sum;
    double average;

    printf("1つ目の整数を入力: ");
    scanf("%d", &x);

    printf("2つ目の整数を入力: ");
    scanf("%d", &y);

    printf("3つ目の整数を入力: ");
    scanf("%d", &z);
    sum = x + y + z;
    average = sum / 3;

    printf("平均は%fです。\n", average);

    return 0;
}
