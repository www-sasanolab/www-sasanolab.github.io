#include <stdio.h>
int main(void){
    int apple, orange, sum;

    printf("りんごの購入数を入力: ");
    scanf("%d", &apple);

    printf("みかんの購入数を入力: ");
    scanf("%d", &orange);

    sum = 130 * apple + 30 * orange;

    if((apple < 10 && orange < 10) && sum <= 2000){
        sum = sum + 200;
    }

    printf("最終金額は%d円です。\n", sum);

    return 0;
}
