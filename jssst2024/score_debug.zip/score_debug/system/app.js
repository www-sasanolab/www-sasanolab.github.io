var express = require('express');
var path = require('path');
var session = require('express-session');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'node_modules')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

var session_opt = {
  secret: 'Keyboard cat',
  resave: false,
  saveUninitialized: false
}
app.use(session(session_opt));

// app.use(サイトのリンク, require(リンクアクセス時に実行されるjs));
app.use('/login', require('./routes/login'));
app.use((req, res, next) => {
  if(req.session.user){
    next();
  }else{
    res.redirect('/login');
  }
});

app.use('/score', require('./routes/score'));
app.use('/history', require('./routes/history'));
app.use('/test', require('./routes/test'));
app.use('/home', require('./routes/home'));
app.use((req, res, next) => {
  if(req.session.endTime){
    next();
  }else{
    res.redirect('/home');
  }
});

app.use('/list', require('./routes/list'));
app.use((req, res, next) => {
  if(req.session.Qname){
    next();
  }else{
    res.redirect('/list');
  }
});

app.use('/debug', require('./routes/debug'));



// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
