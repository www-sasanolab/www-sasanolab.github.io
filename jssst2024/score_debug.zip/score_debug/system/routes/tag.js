exports.runResult = function (result) {
  console.log(result);
  var outputText = result.stdout;
  var errorText = result.stderr;
  var exitCode = result.exitCode;
  var errorType = result.errorType;
  var signal = result.signal;

  errorText = errorText.replace(/.*\.c/g, "program");

  if(process.platform === "win32"){
    if(exitCode != 0 && (errorType == null || errorType.match("run-time"))){
      if(errorType == "run-timeout"){
        errorText = "１秒以上経過したため実行を中止しました．";
      }else if(signal == null && exitCode == 3221225620){
        errorText = "演算例外";
      }else if(signal == null && (exitCode == 3221225477 || exitCode == 3221225725)){
        errorText = "セグメントエラー";
      }else{
        errorText = "エラーが発生しました．";
      }
    }
  }else if(process.platform === "linux"){
    if(exitCode != 0 && (errorType == null || errorType.match("run-time"))){
      if(errorType == "run-timeout"){
        errorText = "１秒以上経過したため実行を中止しました．";
      }else if(signal == "SIGFPE"){
        errorText = "演算例外";
      }else if(signal == "SIGSEGV"){
        errorText = "セグメントエラー";
      }else{
        errorText = "エラーが発生しました．";
      }
    }
  }else{
    // 未検証
    if(exitCode != 0 && (errorType == null || errorType.match("run-time"))){
      if(errorType == "run-timeout"){
        errorText = "１秒以上経過したため実行を中止しました．";
      }else if(signal == "SIGFPE"){
        errorText = "演算例外";
      }else if(signal == "SIGSEGV"){
        errorText = "セグメントエラー";
      }else{
        errorText = "エラーが発生しました．";
      }
    }
  }

  if(outputText == ""){
    return '<span class="error">' + errorText + '</span>\n';
  }else{
    return outputText + '\n<span class="error">' + errorText + '</span>\n';
  }
}
