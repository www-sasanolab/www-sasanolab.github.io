var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var multer = require("multer");
var tag = require('./tag');
const {c, cpp, node, python, java} = require('compile-run');
var exMenu = fs.readFileSync('./views/parts/exMenu.ejs', 'UTF-8');
require('date-utils');

function isExistFile(file) {
  try {
    fs.statSync(file);
    return true
  } catch(err) {
    if(err.code === 'ENOENT') return false
  }
}

function saveDebug(path, program) {
  fs.writeFileSync(path + "debugging.c", program);
}

function compareFormat(str) {
  str = str.replace(/\s+/g, "");
  return str;
}

function compare(program, input, answer){
  return c.runSource(program, { stdin: input}, { timeout: 1000 })
    .then(result => {
      var outputText = result.stdout;

      console.log(input);
      console.log("--- exec ---");
      console.log(outputText);
      console.log("-- answer --");
      console.log(answer);

      outputText = compareFormat(outputText);
      answer = compareFormat(answer);

      // 比較
      if(outputText.match(answer)){
        console.log("\nreturn: true");
        return true;
      }else{
        console.log("\nreturn: false");
        return false;
      }
    })
    .catch(err => {
      console.log(err);
    })
}

router.get('/', function (req, res, next) {
  var path = "./questions/演習/" + req.session.set + "/" + req.session.Qname + "/";
  var questionText = fs.readFileSync(path + "text.txt", 'UTF-8');
  var basisProgram = fs.readFileSync(path + "origin.c", 'UTF-8');
  basisProgram = basisProgram.replace(/</g, "&lt").replace(/>/g, "&gt");
  var debugging = "./users/" + req.session.user + "/" + req.session.set + "/" + req.session.Qname + "/debugging.c";
  if(isExistFile(debugging) == false){
    fs.writeFileSync(debugging, basisProgram);
  }
  var program = fs.readFileSync(debugging, 'UTF-8');

  var exampleList = [];
  var parts = "";
  var testList = fs.readdirSync(path + "test_cases/");
  for (i in testList) {
    var exampleText = fs.readFileSync(path + "test_cases/" + testList[i] + "/example.txt", 'UTF-8');
    exampleText = exampleText.replace(/\r\n|\r|\n/g, "<br>");
    exampleList.push(exampleText);

    var part = ejs.render(exMenu, {
      value: i,
      menuText: "実行例" + (Number(i)+1)
    });
    parts += part;
  }

  res.render('debug', {
    user: req.session.user,
    endTime: req.session.endTime,
    Qname: req.session.Qname,
    program: program,
    questionText: questionText,
    basisProgram: basisProgram,
    exampleMenu: parts,
    exampleList: exampleList
  });
});

router.get('/download', function (req, res) {
  var path = "./questions/演習/" + req.session.set + "/" + req.session.Qname + "/origin.c";
  var filename = "s" + req.session.set + "-q" + req.session.Qname.replace("問題", "") + ".c";

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ----------------- set" + req.session.set + " " + req.session.Qname + " (download)\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  res.download(path, filename);
});

router.post('/upload', multer({dest: './uploads/'}).single('file'), function (req, res) {
  var program = fs.readFileSync("./"+ req.file.path, 'UTF-8');
  saveDebug("./users/" + req.session.user + "/" + req.session.set + "/" + req.session.Qname + "/", program);

  try {
    fs.unlinkSync("./"+ req.file.path);
  } catch (err) {
    throw err;
  }

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ----------------- set" + req.session.set + " " + req.session.Qname + " (upload)\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  res.redirect('/debug');
});

router.post('/judge', function (req, res) {
  var judgement;
  var program = req.body.program;
  var path = "./questions/演習/" + req.session.set + "/" + req.session.Qname + "/test_cases/";

  saveDebug("./users/" + req.session.user + "/" + req.session.set + "/" + req.session.Qname + "/", program);

  var files = fs.readdirSync("./users/" + req.session.user + "/" + req.session.set + "/" + req.session.Qname + "/debug_record");
  var fileCount = files.length + 1;

  fs.writeFileSync("./users/" + req.session.user + "/" + req.session.set + "/" + req.session.Qname + "/debug_record/program__" + fileCount + ".txt", program);

  var testList = fs.readdirSync(path);
  var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", 'utf8'));
  var calc = details;

  (async () => {
    for await (testname of testList) {
      var input = fs.readFileSync(path + testname + "/input.txt", 'UTF-8');
      var answer = fs.readFileSync(path + testname + "/output.txt", 'UTF-8');

      console.log("\n----- " + testname + " -----");
      judgement = await compare(program, input, answer);

      if(judgement == false){
        break;
      }
    }

    if(calc.question[(Number(req.session.Qname.replace("問題", ""))-1)].isCorrect == false){
      if(judgement == true){
        calc.question[(Number(req.session.Qname.replace("問題", ""))-1)].isCorrect = true;
        var nowTime = new Date();
        var status = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/status.json", 'utf8'));
        var endTime = status.end;
        var time_ms = endTime - nowTime;
        calc.lastCorrect = time_ms;
      }else if(judgement == false){
        calc.question[(Number(req.session.Qname.replace("問題", ""))-1)].wrongAns += 1;
      }
    }
    fs.writeFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", JSON.stringify(calc));

    var date = new Date();
    var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
    var writeData = formattedDate + " ----------------- set" + req.session.set + " " + req.session.Qname + " ---------- " + judgement + "\n";
    fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

    res.send(judgement);
  })();
});

router.post('/finish', function (req, res) { // 'list/finish'と同じ処理
  var nowTime = new Date();
  var status = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/status.json", 'utf8'));
  var endTime = status.end;
  var time_ms = endTime - nowTime;
  var time_s = Math.floor(time_ms / 1000); // 1s = 1000ms

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ---------- finish set" + req.session.set + "\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  var updated = {
    set: Number(req.session.set) + 1,
    end: null
  };
  fs.writeFileSync("./users/" + req.session.user + "/status.json", JSON.stringify(updated));
  req.session.endTime = undefined;

  var score = 0;
  var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", 'utf8'));
  var quesDetList = details.question;
  for (i in quesDetList) {
    if(quesDetList[i].isCorrect == true){
      // 基礎点
      switch(i){
        case "0":
          score += 1000;
          break;
        case "1":
          score += 2000;
          break;
        case "2":
          score += 3000;
          break;
        case "3":
          score += 4000;
          break;
        case "4":
          score += 5000;
          break;
      }

      // 誤答減点
      if(quesDetList[i].wrongAns > 5){
        score -= 500;
      }else{
        score -= quesDetList[i].wrongAns * 100;
      }
    }
  }

  // 時間加点
  var timeScore = Math.floor(details.lastCorrect / 1000); // 1s = 1000ms
  if(time_s > 0){
    score += Math.floor(timeScore * 1);
  }else{
    if(timeScore > 0){
      score += Math.floor(timeScore * 0.5);
    }
  }

  var calc = details;
  calc.time = time_s;
  calc.score = score;
  fs.writeFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", JSON.stringify(calc));

  res.send('/score');
});

module.exports = router;
