var express = require('express');
var router = express.Router();
var mkdir = require('./mkdir');
var fs = require('fs');

function isExistFile(file) {
  try {
    fs.statSync(file);
    return true
  } catch(err) {
    if(err.code === 'ENOENT') return false
  }
}

router.get('/', function (req, res, next) {
  res.render('login');
});

router.post('/', function (req, res) {
  req.session.regenerate((err) => {
    req.session.user = req.body.user;
    mkdir.user(req.session.user);

    var status = {
      set: 1,
      end: null
    };
    var path = "./users/" + req.session.user + "/";
    if(isExistFile(path + "status.json") == false){
      fs.writeFileSync(path + "status.json", JSON.stringify(status));
    }
    if(isExistFile(path + "operation_log.txt") == false){
      fs.writeFileSync(path + "operation_log.txt", "");
    }

    res.redirect('/home');
  });
});

module.exports = router;
