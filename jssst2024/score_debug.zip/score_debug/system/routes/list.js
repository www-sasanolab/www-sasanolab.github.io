var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mkdir = require('./mkdir');
var QPart = fs.readFileSync('./views/parts/QPart.ejs', 'UTF-8');
require('date-utils');

router.get('/', function (req, res, next) {
  req.session.Qname = undefined;

  var incorrectNum = 0;
  var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", 'utf8'));
  var quesDetList = details.question;

  var fileImg;
  var QList = fs.readdirSync("./questions/演習/" + req.session.set);
  var parts = '';

  for (i in QList) {
    fileImg = "/images/file_icon.png";

    if(quesDetList[i].isCorrect == true){
      fileImg = "/images/check_file_icon.png";
    }else{
      incorrectNum += 1;
    }

    var part = ejs.render(QPart, {
      icon: fileImg,
      name: QList[i]
    });
    parts += part;
  }

  res.render('list', {
    user: req.session.user,
    endTime: req.session.endTime,
    contents: parts,
    incorrectNum: incorrectNum
  });
});

router.post('/', function (req, res) {
  req.session.Qname = req.body.Qname;
  mkdir.question(req.session.user, req.session.set, req.session.Qname);
  mkdir.debugRecord(req.session.user, req.session.set, req.session.Qname);

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ----------- enter set" + req.session.set + " " + req.session.Qname + "\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  res.redirect('/debug');
});

router.post('/finish', function (req, res) { // 'debug/finish'と同じ処理
  var nowTime = new Date();
  var status = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/status.json", 'utf8'));
  var endTime = status.end;
  var time_ms = endTime - nowTime;
  var time_s = Math.floor(time_ms / 1000); // 1s = 1000ms

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ---------- finish set" + req.session.set + "\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  var updated = {
    set: Number(req.session.set) + 1,
    end: null
  };
  fs.writeFileSync("./users/" + req.session.user + "/status.json", JSON.stringify(updated));
  req.session.endTime = undefined;

  var score = 0;
  var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", 'utf8'));
  var quesDetList = details.question;
  for (i in quesDetList) {
    if(quesDetList[i].isCorrect == true){
      // 基礎点
      switch(i){
        case "0":
          score += 1000;
          break;
        case "1":
          score += 2000;
          break;
        case "2":
          score += 3000;
          break;
        case "3":
          score += 4000;
          break;
        case "4":
          score += 5000;
          break;
      }

      // 誤答減点
      if(quesDetList[i].wrongAns > 5){
        score -= 500;
      }else{
        score -= quesDetList[i].wrongAns * 100;
      }
    }
  }

  // 時間加点
  var timeScore = Math.floor(details.lastCorrect / 1000); // 1s = 1000ms
  if(time_s > 0){
    score += Math.floor(timeScore * 1);
  }else{
    if(timeScore > 0){
      score += Math.floor(timeScore * 0.5);
    }
  }

  var calc = details;
  calc.time = time_s;
  calc.score = score;
  fs.writeFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", JSON.stringify(calc));

  res.send('/score');
});

module.exports = router;
