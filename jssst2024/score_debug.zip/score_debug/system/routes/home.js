var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mkdir = require('./mkdir');
var start = fs.readFileSync('./views/parts/startButton.ejs', 'UTF-8');
var end = fs.readFileSync('./views/parts/endMessage.ejs', 'UTF-8');
require('date-utils');

function isExistFile(file) {
  try {
    fs.statSync(file);
    return true
  } catch(err) {
    if(err.code === 'ENOENT') return false
  }
}

router.get('/', function (req, res, next) {
  var content;
  var status = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/status.json", 'utf8'));
  var setLimit = fs.readdirSync("./questions/演習").length;
  if(Number(status["set"]) > setLimit){
    content = ejs.render(end);
  }else{
    content = ejs.render(start);
  }

  res.render('home', {
    user: req.session.user,
    content: content
  });
});

router.post('/', function (req, res) {
  var nowTime = new Date();
  var endTime = nowTime.setMinutes(nowTime.getMinutes() + 15);

  var status = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/status.json", 'utf8'));
  if(status["end"] == null){
    req.session.endTime = endTime;
  }else{
    req.session.endTime = status["end"];
  }
  req.session.set = status["set"];

  var updated = {
    set: req.session.set,
    end: req.session.endTime
  };
  mkdir.set(req.session.user, req.session.set);

  fs.writeFileSync("./users/" + req.session.user + "/status.json", JSON.stringify(updated));

  var details = {
    score: null,
    time: 0,
    lastCorrect: 0,
    question: [
      {isCorrect: false, wrongAns: 0},
      {isCorrect: false, wrongAns: 0},
      {isCorrect: false, wrongAns: 0},
      {isCorrect: false, wrongAns: 0},
      {isCorrect: false, wrongAns: 0}
    ]
  };

  var path = "./users/" + req.session.user + "/" + req.session.set + "/";
  if(isExistFile(path + "details.json") == false){
    fs.writeFileSync(path + "details.json", JSON.stringify(details));
  }

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " ----------- start set" + req.session.set + "\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  res.redirect('/list');
});

router.get('/download', function (req, res) {
  var path = "./instructions/";
  var filename = "manual.pdf";

  res.download(path + filename, filename);
});

module.exports = router;
