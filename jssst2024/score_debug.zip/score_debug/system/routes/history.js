var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var historyPart = fs.readFileSync('./views/parts/historyPart.ejs', 'UTF-8');
require('date-utils');

router.get('/', function (req, res, next) {
  var parts = '';
  var setList = fs.readdirSync("./questions/演習");
  for (i in setList){
    var score = "-";
    if(fs.existsSync("./users/" + req.session.user + "/" + setList[i]) == true){
      var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + setList[i] + "/details.json", 'utf8'));

      if(details.score != null){
        score = details.score + "点";
      }
    }
    var part = ejs.render(historyPart, {
      set: setList[i] + "回目",
      score: score
    });
    parts += part;
  }

  var date = new Date();
  var formattedDate = date.toFormat("YYYY/MM/DD HH24:MI:SS");
  var writeData = formattedDate + " スコア履歴\n";
  fs.appendFileSync("./users/" + req.session.user + "/operation_log.txt", writeData);

  res.render('history', {
    user: req.session.user,
    contents: parts
  });
});

module.exports = router;
