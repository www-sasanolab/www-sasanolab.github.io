var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var scoreDetail = fs.readFileSync('./views/parts/scoreDetail.ejs', 'UTF-8');
var timeDetail = fs.readFileSync('./views/parts/timeDetail.ejs', 'UTF-8');

router.get('/', function (req, res, next) {
  var details = JSON.parse(fs.readFileSync("./users/" + req.session.user + "/" + req.session.set + "/details.json", 'utf8'));
  var quesDetList = details.question;

  var parts = '';
  for (i in quesDetList) {
    if(quesDetList[i].isCorrect == true){
      var sum, base, wrong;
      switch(i){
        case "0":
          base = 1000;
          break;
        case "1":
          base = 2000;
          break;
        case "2":
          base = 3000;
          break;
        case "3":
          base = 4000;
          break;
        case "4":
          base = 5000;
          break;
      }

      if(quesDetList[i].wrongAns > 5){
        wrong = 500;
      }else{
        wrong = quesDetList[i].wrongAns * 100;
      }

      sum = base - wrong;
      var formula = base + " - " + wrong + "(誤答" + quesDetList[i].wrongAns + ")";

      var part = ejs.render(scoreDetail, {
        num: Number(i) + 1,
        partScore: sum,
        formula: formula
      });
      parts += part;
    }
  }

  var time_s = details.time;
  var timeScore = Math.floor(details.lastCorrect / 1000); // 1s = 1000ms
  var timeAdd;
  var formula;

  if(time_s > 0){
    timeAdd = Math.floor(timeScore * 1);
    formula = timeScore + "秒 * 1.0";
  }else{
    if(timeScore < 0){
      timeScore = 0;
    }

    timeAdd = Math.floor(timeScore * 0.5);
    formula = timeScore + "秒 * 0.5";
  }

  var part = ejs.render(timeDetail, {
    timeAdd: timeAdd,
    formula: formula
  });
  parts += part;

  res.render('score', {
    user: req.session.user,
    scoreDetail: parts,
    result: details.score
  });
});

module.exports = router;
