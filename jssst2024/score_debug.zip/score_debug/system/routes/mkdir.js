var fs = require('fs');

makePath = function (path) {
  if(fs.existsSync(path) == false){
    fs.mkdirSync(path);
  }
}

exports.user = function (user) {
  var path = "./users/" + user + "/";
  makePath(path);
}

exports.set = function (user, set) {
  var path = "./users/" + user + "/" + set + "/";
  makePath(path);
}

exports.question = function (user, set, Qname) {
  var path = "./users/" + user + "/" + set + "/" + Qname + "/";
  makePath(path);
}

exports.debugRecord = function (user, set, Qname) {
  var path = "./users/" + user + "/" + set + "/" + Qname + "/debug_record/";
  makePath(path);
}
