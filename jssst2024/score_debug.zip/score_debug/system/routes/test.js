var express = require('express');
var router = express.Router();
var ejs = require('ejs');
var fs = require('fs');
var mkdir = require('./mkdir');
var multer = require("multer");
var tag = require('./tag');
const {c, cpp, node, python, java} = require('compile-run');
var exMenu = fs.readFileSync('./views/parts/exMenu.ejs', 'UTF-8');
require('date-utils');

function isExistFile(file) {
  try {
    fs.statSync(file);
    return true
  } catch(err) {
    if(err.code === 'ENOENT') return false
  }
}

function saveDebug(path, program) {
  fs.writeFileSync(path + "debugging.c", program);
}

function compareFormat(str) {
  str = str.replace(/\s+/g, "");
  return str;
}

function compare(program, input, answer){
  return c.runSource(program, { stdin: input}, { timeout: 1000 })
    .then(result => {
      var outputText = result.stdout;

      console.log(input);
      console.log("--- exec ---");
      console.log(outputText);
      console.log("-- answer --");
      console.log(answer);

      outputText = compareFormat(outputText);
      answer = compareFormat(answer);

      // 比較
      if(outputText.match(answer)){
        console.log("\nreturn: true");
        return true;
      }else{
        console.log("\nreturn: false");
        return false;
      }
    })
    .catch(err => {
      console.log(err);
    })
}

router.get('/', function (req, res, next) {
  mkdir.set(req.session.user, "操作確認");

  var path = "./questions/操作確認/";
  var questionText = fs.readFileSync(path + "text.txt", 'UTF-8');
  var basisProgram = fs.readFileSync(path + "origin.c", 'UTF-8');
  basisProgram = basisProgram.replace(/</g, "&lt").replace(/>/g, "&gt");
  var debugging = "./users/" + req.session.user + "/操作確認/debugging.c";
  if(isExistFile(debugging) == false){
    fs.writeFileSync(debugging, basisProgram);
  }
  var program = fs.readFileSync(debugging, 'UTF-8');

  var exampleList = [];
  var parts = "";
  var testList = fs.readdirSync(path + "test_cases/");
  for (i in testList) {
    var exampleText = fs.readFileSync(path + "test_cases/" + testList[i] + "/example.txt", 'UTF-8');
    exampleText = exampleText.replace(/\r\n|\r|\n/g, "<br>");
    exampleList.push(exampleText);

    var part = ejs.render(exMenu, {
      value: i,
      menuText: "実行例" + (Number(i)+1)
    });
    parts += part;
  }

  res.render('test', {
    user: req.session.user,
    program: program,
    questionText: questionText,
    basisProgram: basisProgram,
    exampleMenu: parts,
    exampleList: exampleList
  });
});

router.get('/download', function (req, res) {
  var path = "./questions/操作確認/origin.c";
  var filename = "sample.c";

  res.download(path, filename);
});

router.post('/upload', multer({dest: './uploads/'}).single('file'), function (req, res) {
  var program = fs.readFileSync("./"+ req.file.path, 'UTF-8');
  saveDebug("./users/" + req.session.user + "/操作確認/", program);

  try {
    fs.unlinkSync("./"+ req.file.path);
  } catch (err) {
    throw err;
  }

  res.redirect('/test');
});

router.post('/judge', function (req, res) {
  var judgement;
  var program = req.body.program;
  var path = "./questions/操作確認/test_cases/";

  saveDebug("./users/" + req.session.user + "/操作確認/", program);

  var testList = fs.readdirSync(path);

  (async () => {
    for await (testname of testList) {
      var input = fs.readFileSync(path + testname + "/input.txt", 'UTF-8');
      var answer = fs.readFileSync(path + testname + "/output.txt", 'UTF-8');

      console.log("\n----- " + testname + " -----");
      judgement = await compare(program, input, answer);

      if(judgement == false){
        break;
      }
    }

    res.send(judgement);
  })();
});

module.exports = router;
