#include <stdio.h>
int main(void){
    int n = 0, i = 2, num, max, min;

    while(n <= 0){
        printf("nを入力: ");
        scanf("%d", &n);
    }

    printf("1つ目の整数を入力: ");
    scanf("%d", &num);
    max = num;
    min = num;

    while(1){
        printf("%dつ目の整数を入力: ", i);
        scanf("%d", &num);

        if(max < num){
            max = num;
        }
        if(num < min){
            min = num;
        }

        i = i + 1;
        if(n < i){
            break;
        }
    }

    printf("最大値は%d、最小値は%dです。\n", max, min);

    return 0;
}
