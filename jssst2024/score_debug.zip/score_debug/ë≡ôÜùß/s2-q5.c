#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int search(char *str, char *part){
    int i, j;

    for(i = 0; i <= strlen(str) - strlen(part); ++i){
        if(str[i] == part[0]){
            for(j = 1; part[j] != '\0'; ++j){
                if(str[i + j] != part[j]){
                    break;
                }
            }

            if(j == strlen(part)){
                return 1;
            }
        }
    }

    return 0;
}

int main(void){
    int n;
    char *p1, *p2;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p1 = calloc(n + 1, sizeof(char));
    p2 = calloc(n + 1, sizeof(char));

    if(p1 == NULL || p2 == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("1つ目の文字列を入力: ");
    scanf("%s", p1);
    printf("2つ目の文字列を入力: ");
    scanf("%s", p2);

    if(search(p1, p2)){
        printf("%s に %s は含まれています。\n", p1, p2);
    }else{
        printf("%s に %s は含まれていません。\n", p1, p2);
    }

    free(p1);
    free(p2);

    return 0;
}
