#include <stdio.h>
int main(void){
    int i, num, sum = 0;

    for(i = 0; i < 5; ++i){
        printf("%dつ目の整数を入力: ", i + 1);
        scanf("%d", &num);
        sum = sum + num;
    }

    printf("合計は%dです。\n", sum);

    return 0;
}
