#include <stdio.h>
int main(void){
    int num[5], i, j, temp;

    for(i = 0; i < 5; ++i){
        printf("%dつ目の整数を入力: ", i + 1);
        scanf("%d", &num[i]);
    }

    for(i = 0; i < 4 ; ++i){
        for(j = i + 1; j < 5; ++j){
            if(num[i] > num[j]){
                temp = num[i];
                num[i] = num[j];
                num[j] = temp;
            }
        }
    }

    printf("昇順: ");
    for(i = 0; i < 5; ++i){
        printf("%d ", num[i]);
    }
    printf("\n");

    printf("降順: ");
    for(i = 0; i < 5; ++i){
        printf("%d ", num[4 - i]);
    }
    printf("\n");

    return 0;
}
