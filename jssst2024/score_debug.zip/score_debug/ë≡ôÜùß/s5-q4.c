#include <stdio.h>
#include <stdlib.h>
double calcAverage(int *p, int size){
    int i;
    double sum = 0;

    for(i = 0; i < size; ++i){
        sum = sum + p[i];
    }

    return sum / size;
}

int main(void){
    int n, i;
    int *p;

    printf("nを入力: ");
    scanf("%d", &n);

    p = calloc(n, sizeof(int));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    for(i = 0; i < n; ++i){
        printf("%dつ目の整数を入力: ", i + 1);
        scanf("%d", &p[i]);
    }

    printf("平均は%fです。\n", calcAverage(p, n));
    free(p);

    return 0;
}
