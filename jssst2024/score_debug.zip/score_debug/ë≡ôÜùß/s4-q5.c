#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int sumOfNumbers(char *str){
    int digit, sum = 0, num = 0, isNum = 0;

    while(*str != '\0'){
        if(isdigit(*str)){
            digit = *str - '0';
            num = num * 10 + digit;
            isNum = 1;
        }else{
            if(isNum){
                sum = sum + num;
                num = 0;
                isNum = 0;
            }
        }

        str = str + 1;
    }

    if(isNum){
        sum = sum + num;
    }

    return sum;
}

int main(void){
    int n;
    char *p;

    printf("文字数上限を入力: ");
    scanf("%d", &n);

    p = calloc(n + 1, sizeof(char));
    if(p == NULL){
        printf("記憶域の確保に失敗しました。\n");
        return 0;
    }

    printf("文字列を入力: ");
    scanf("%s", p);

    printf("文字列内の数値の合計は%dです。\n", sumOfNumbers(p));
    free(p);

    return 0;
}
