#include <stdio.h>
int main(void){
    double x, y, average;

    printf("1つ目の整数を入力: ");
    scanf("%lf", &x);

    printf("2つ目の整数を入力: ");
    scanf("%lf", &y);

    average = (x + y) / 2;

    printf("平均は%fです。\n", average);

    return 0;
}
