#include <stdio.h>
int main(void){
    int x;

    printf("整数を入力: ");
    scanf("%d", &x);

    if(x % 2 == 0){
        printf("偶数です。\n");
    }else{
        printf("奇数です。\n");
    }

    return 0;
}
