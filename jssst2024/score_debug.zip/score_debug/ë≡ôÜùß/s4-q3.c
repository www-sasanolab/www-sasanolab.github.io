#include <stdio.h>
int main(void){
    int x, i, answer = 1;

    printf("xを入力: ");
    scanf("%d", &x);

    for(i = 1; i <= x; ++i){
        answer = answer * i;
    }

    printf("答えは%dです。\n", answer);

    return 0;
}
