得点提示式演習システム version 0.0.1

[Server側]
1. Node.jsをインストール
2. MinGWをインストール
3. npmパッケージをインストール
    systemディレクトリで [npm install]
4. Webサーバー起動
    systemディレクトリで [npm start]

[Client側]
1. 以下のURLにアクセス
    [http://<IPアドレス>:3000/login] あるいは [http://<ホスト名>:3000/login]
