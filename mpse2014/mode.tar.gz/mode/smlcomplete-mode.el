(defvar smlcomplete-mode-map nil)
(setq smlcomplete-mode-map (make-sparse-keymap))

(define-key smlcomplete-mode-map [(tab)] 'complete)

(defun toList (str)
  (split-string str "\n"))

;; (defun run-server ()
;;   (start-process-shell-command "completionServer" "foo" "./a.out")
;; )

(defun complete ()
  (interactive)
;  (run-server)

  (connect-server)
  (send-cursorPosition (point))

  (set-process-filter 
   (get-process "smla") 
   (lambda (process output) 
;     (message "output: %s" output)
     ))
  (disconnect-server)

  (connect-server)
  (send-buffer)
  (disconnect-server)

  (connect-server)
  (set-process-filter
   (get-process "smla") 
   (lambda (process output) 
;     (message (format "output: %s" output))
     (let* ((outputList (toList output))
	    (cursorlen (string-to-number (car outputList)))
	    (cands (cdr outputList)))
       (if (/= cursorlen -1)
	   (let ((name (popup-menu* cands)))
;	     (message (format "popup: %s" name)) 
;	     (message (format "cursorlen: %s" cursorlen))
	     (delete-backward-char cursorlen)
	     (insert name))))))
;  (disconnect-server)
  )

(defun connect-server ()
  (setq buf (get-buffer-create "sml1"))
  (setq server (open-network-stream "smla" buf "localhost" 50000))
;  (message "connect-server")
)

(defun disconnect-server ()
  (delete-process server)
;  (message "disconnect-server")
)

;; (defun send-string ()
;;   (interactive)
;;   (process-send-string server (read-from-minibuffer ">")))

(defun send-cursorPosition (point) 
  (process-send-string 
   server 
   (number-to-string point)
   )
  )

(defun send-buffer ()
  (interactive)
  (process-send-string 
   server 
    (buffer-string)
   )
  )

(defun smlcomplete-mode ()
  "SML complete Mode"
  (interactive)
  (kill-all-local-variables)
  (setq mode-name "SML complete")
  (setq major-mode 'smlcomplete-mode)
  
  (use-local-map smlcomplete-mode-map)
  (run-hooks 'smlcomplete-mode-hook))
 
(provide 'smlcomplete-mode)
