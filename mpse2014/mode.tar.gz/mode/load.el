(load-file "popup.el")
(load-file "smlcomplete-mode.el")
