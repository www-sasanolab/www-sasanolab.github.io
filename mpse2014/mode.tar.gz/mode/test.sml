let val xx = 1
in let val xy => 2
   in x end

