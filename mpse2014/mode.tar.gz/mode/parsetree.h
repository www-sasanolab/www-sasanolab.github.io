enum tag {EXP1, EXP2, APPEXP1, APPEXP2, ATEXP1, ATEXP1_2, ATEXP2, ATEXP3, ATEXP4};

  struct exp {
    enum tag tag;
    struct appexp *appexp;
    char *id;
    struct exp *exp;
  };

  struct appexp {
    enum tag tag;
    struct appexp *appexp;
    struct atexp *atexp;
  };

  struct atexp {
    enum tag tag;
    char *id;
    int num;
    struct exp *exp;
    struct dec *dec;
  };

  struct dec {
    char *id;
    struct exp *exp;
  };
