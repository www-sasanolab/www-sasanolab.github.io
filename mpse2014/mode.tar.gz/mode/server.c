#include "parsetree.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define BUFSIZE 65535
#define SERVER_PORT 50000

int position;
extern int num_chars;
extern char cursorlen;

struct cell {
  char *car;
  struct cell *cdr;
}; 

typedef struct cell *list;

list cons (char* str, list list) {
  struct cell *c;
  c = malloc (sizeof (struct cell));
  c->car = str;
  c->cdr = list;
  return c;
}  

list concat (list x, list y) {
  struct cell *c;
  if(x==NULL)
    return y;
  c = malloc (sizeof(struct cell));
  c->car = x->car;
  c->cdr = concat (x->cdr, y);
  return c;
}

list allIDatexp (struct atexp *atexp, list result);
list allIDappexp (struct appexp *appexp, list result);
list allIDexp (struct exp *exp, list result);
list allIDdec (struct dec *dec, list result);

list hasPrefix (char *id, list result) {
  struct cell *c;
  int length;
  char *str;
  if (result==NULL)
    return NULL;
  str = result->car;
  length = strlen (id);
  if (strncmp (id, str, length)==0) {
    c = malloc (sizeof(struct cell));
    c->car = str;
    c->cdr = hasPrefix (id, result->cdr);
    return c;
  } else 
    return hasPrefix (id, result->cdr);
}

list allIDatexp (struct atexp *atexp, list result) {
  list temp;
  switch (atexp->tag) {
  case ATEXP1:
    return NULL;
  case ATEXP1_2:    
    return hasPrefix (atexp->id, result);
  case ATEXP2:
    return NULL;
  case ATEXP3:
    return allIDexp (atexp->exp, result);
  case ATEXP4:
    temp = allIDdec (atexp->dec, result);
    if (temp==NULL) {
      if (atexp->dec==NULL)
	return allIDexp (atexp->exp, result);
      else
	return allIDexp (atexp->exp, cons (atexp->dec->id, result));
    } else
      return temp;
  }
}

list allIDappexp (struct appexp *appexp, list result) {
  list temp;
  switch (appexp->tag) {
  case APPEXP1:
    return allIDatexp (appexp->atexp, result);
  case APPEXP2:
    temp = allIDappexp (appexp->appexp, result);
    if (temp==NULL)
      return allIDatexp (appexp->atexp, result);
    else
      return temp;
  }
}

list allIDexp (struct exp *exp, list result){
  switch (exp->tag) {
  case EXP1:
    return allIDappexp(exp->appexp, result);
  case EXP2:
    return allIDexp (exp->exp, cons (exp->id, result));
  }
}

list allIDdec (struct dec *dec, list result) {
  if (dec==NULL) 
    return NULL;
  else
    return allIDexp (dec->exp, result);
}

list allID (struct exp *exp) {
  return allIDexp (exp, NULL);
}

list computeCandidates (struct exp *parseResult) {
  return allID (parseResult);
}

void clearbuf(char *buf) {
  int i;
  for(i=0; i<BUFSIZE; i++)
    buf[i]=0;
}

int main(void) {
  char stringarray[256];
  extern struct exp *parseResult;
  extern int yyparse(void);
  //  extern FILE *yyin;
  struct cell *idList=NULL;
  int fd[2];
  FILE *pipeFile;
  int sockfd; /* file descriptor returned by socket() */
  int ns; /* file descriptor returned by accept() */
  struct sockaddr_in server;
  struct  sockaddr_in client;
  socklen_t fromlen;
  char buf[BUFSIZE];
  char *candidates;
  char *empty="";
  int msglen;
  const int one = 1;
  if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
    perror("server: socket");
    exit(1);
  }
  bzero((char *)&server, sizeof(server));
  server.sin_family = PF_INET;
  server.sin_port = htons(SERVER_PORT);
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, 
	     &one, sizeof(int));
  if(bind(sockfd, (struct sockaddr *)&server, sizeof(server))
     == -1) {
    perror("server: bind");
    //    exit(1);
  }
  if(listen(sockfd, 5) == -1){
    perror("server: listen");
    exit(1);
  }
  fromlen = sizeof(client);

  while (1) {
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    //    printf("\nconnect request from: %s   port: %d\n",
    //	   inet_ntoa(client.sin_addr), ntohs(client.sin_port));

    clearbuf(buf);
    if(read(ns, buf, BUFSIZE) == -1){
      perror("server: read1");
      exit(1);
    }
    //    printf("\n<SERVER> message from client  :  %s\n", buf);

    close (ns);

    sscanf (buf, "%d", &position);
    //    printf("position=%d\n", position);
    
    
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    //    printf("\nconnect request from: %s   port: %d\n",
    //	   inet_ntoa(client.sin_addr), ntohs(client.sin_port));
    
    if(pipe(fd)==-1) {
      perror("pipe");
      exit(1);
    }

    while(1){
      msglen=read(ns, buf, BUFSIZE);
      if(msglen == -1){
	perror("server: read2");
	exit(1);
      }
      //      printf("msglen=%d\n", msglen);
      //      fflush(stdout);
      if(msglen==0)break;
      if(write(fd[1], buf, msglen)==-1){
	perror("write");
	exit(1);
      }
    }
    close(ns);
    close(fd[1]);
    pipeFile=fdopen(fd[0], "r");

    //  yyin = pipeFile;
    yyrestart(pipeFile);
    if (yyparse()) {
      candidates=empty;
      fprintf (stderr, "syntax error in yyparse\n"); 
    } else {
      idList = computeCandidates (parseResult);
    }

    fclose(pipeFile);
    close(fd[0]); // is this necessary?

    if (idList==NULL)
      cursorlen=-1;
    sprintf (stringarray, "%d", cursorlen);

    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }

    if(write(ns, &stringarray, strlen(stringarray)) == -1){ 
      perror("server: write");
      exit(1);
    }
    if(write(ns, "\n", 1) == -1){ 
      perror("server: write");
      exit(1);
    }
    while (idList!=NULL) {
      msglen = strlen (idList->car);
      //      printf("id:%s\n", idList->car);
      if(write(ns, idList->car, msglen) == -1){ 
          perror("server: write");
          exit(1);
        }
      if (idList->cdr!=NULL) {
	if(write(ns, "\n", 1) == -1){ 
          perror("server: write");
          exit(1);
        }
      }
      idList=idList->cdr;
    }

    close(ns);
    num_chars=0;
    cursorlen=-1;
    idList=NULL;
  }
  close(sockfd);
  return 0;
}
