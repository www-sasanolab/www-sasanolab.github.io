%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parsetree.h"

  char cursorlen=-1;

  struct exp *parseResult;

  struct exp *make_exp1 (struct appexp *appexp);
  struct exp *make_exp2 (char *id, struct exp *exp);
  struct appexp *make_appexp1 (struct atexp *atexp);
  struct appexp *make_appexp2 (struct appexp *appexp, struct atexp *atexp);
  struct atexp *make_atexp1 (char *id);
  struct atexp *make_atexp1_2 (char *id);
  struct atexp *make_atexp2 (int num);
  struct atexp *make_atexp3 (struct exp *exp);
  struct atexp *make_atexp4 (struct dec *dec, struct exp *exp);
  struct dec *make_dec (char *id, struct exp *exp);

  %}

%union{
  int int_value;
  char *id_value;
  struct exp *exp;
  struct appexp *appexp;
  struct atexp *atexp;
  struct dec *dec;
 }

%token <id_value> ID IDCURSOR
%token <int_value> NUM
%token LET VAL IN END FN RA

%type<exp> exp
%type<appexp> appexp
%type<atexp> atexp
%type<dec> dec

%%

start
: exp
{
  printf ("succeeded.\n");
  parseResult = $1;
}

exp
: appexp
{
  $$ = make_exp1 ($1);
}
| FN ID RA exp
{
  $$ = make_exp2 ($2, $4);
}

appexp
: atexp
{
  $$ = make_appexp1($1);
}
| appexp atexp
{
  $$ = make_appexp2 ($1, $2);
}

atexp
: ID
{
  $$ = make_atexp1 ($1);
}
| IDCURSOR
{
  $$ = make_atexp1_2 ($1);
}
| NUM
{
  $$ = make_atexp2 ($1);
}
| '(' exp ')'
{
  $$ = make_atexp3 ($2);
}
| LET dec IN exp END
{
  $$ = make_atexp4 ($2, $4);
}
| LET dec IN exp error
{
  $$ = make_atexp4 ($2, $4);
}


dec
: VAL ID '=' exp
{
  $$ = make_dec($2, $4);
}
| error
{
  $$ = NULL;
}
%%

struct exp *make_exp1 (struct appexp *appexp) {
  struct exp *exp1;
  exp1 = malloc (sizeof (struct exp));
  exp1->tag=EXP1;
  exp1->appexp=appexp;
  return exp1;
}

struct exp *make_exp2 (char *id, struct exp *exp) {
  struct exp *exp2;
  exp2 = malloc (sizeof (struct exp));
  exp2->tag=EXP2;
  exp2->exp=exp;
  exp2->id=id;
  return exp2;
}

struct appexp *make_appexp1 (struct atexp *atexp) {
  struct appexp *appexp1;
  appexp1 = malloc (sizeof (struct appexp));
  appexp1->tag=APPEXP1;
  appexp1->atexp=atexp;
  return appexp1;
}

struct appexp *make_appexp2 (struct appexp *appexp, struct atexp *atexp) {
  struct appexp *appexp2;
  appexp2 = malloc (sizeof (struct appexp));
  appexp2->tag=APPEXP2;
  appexp2->appexp=appexp;
  appexp2->atexp=atexp;
  return appexp2;
}

struct atexp *make_atexp1 (char *id) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP1;
  atexp->id=id;
  return atexp;
}

struct atexp *make_atexp1_2 (char *id) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP1_2;
  atexp->id=id;
  return atexp;
}

struct atexp *make_atexp2 (int num) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP2;
  atexp->num=num;
  return atexp;
}

struct atexp *make_atexp3 (struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP3;
  atexp->exp=exp;
  return atexp;
}

struct atexp *make_atexp4 (struct dec *dec, struct exp *exp) {
  struct atexp *atexp;
  atexp = malloc (sizeof (struct atexp));
  atexp->tag=ATEXP4;
  atexp->dec=dec;
  atexp->exp=exp;
  return atexp;
}

struct dec *make_dec (char *id, struct exp *exp) {
  struct dec *dec;
  dec = malloc (sizeof (struct dec));
  dec->id=id;
  dec->exp=exp;
  return dec;
}

