int main ( void){
 if (xx) xx = 1;
 else xx;}