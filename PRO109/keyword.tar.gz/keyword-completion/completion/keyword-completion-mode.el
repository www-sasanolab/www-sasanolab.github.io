(defvar complete-mode-map nil)
(setq complete-mode-map (make-sparse-keymap))

(define-key complete-mode-map [(tab)] 'complete)

(defun toList (str)
  (split-string str "\n"))

;; (defun run-server ()
;;   (start-process-shell-command "completionServer" "foo" "./a.out")
;; )
(defun current-time-to-microsec (time)
  (let ((result 0)
	(high (car time))
	(low (car (cdr time)))
	(mil (car (cdr (cdr time)))))
    (setq result (+ (* (+ (* high 2 (* 16 16)) low) 1000) (/ mil 1000)))
    
    result))

(defun time-diff (before after)
  (- (current-time-to-microsec after)
     (current-time-to-microsec before)))

(defun complete ()
  (interactive)
;  (run-server)

  (setq start_time (current-time))
  
  (connect-server)
  (send-cursorPosition (point))

  (set-process-filter 
   (get-process "a") 
   (lambda (process output) 
;     (message "output: %s" output)
     ))
  (disconnect-server)

  (connect-server)
  (send-buffer)
  (disconnect-server)

  (connect-server)
  (set-process-filter
   (get-process "a") 
   (lambda (process output) 
     (message (format "output: %s" output))
     (let* ((outputList (toList output))
	    (cursorlen (string-to-number (car outputList)))
	    (cands (cdr outputList)))
       (message (format "outputList: %s" outputList))
       (message (format "cands: %s" cands))
;      (if (/= cursorlen -1)
       (if cands
	   (let ((name (popup-menu* cands)))
	     (message (format "popup: %s" name)) 
	     (message (format "cursorlen: %s" cursorlen))
	     (delete-backward-char cursorlen)
	     (insert name))))))
					;  (disconnect-server)
  (setq end_time (current-time))
  (message (format "time: %s microsec" (time-diff start_time end_time)))
  )

(defun connect-server ()
  (setq buf (get-buffer-create "1"))
  (setq server (open-network-stream "a" buf "localhost" 50000))
;  (message "connect-server")
)

(defun disconnect-server ()
  (delete-process server)
;  (message "disconnect-server")
)

;; (defun send-string ()
;;   (interactive)
;;   (process-send-string server (read-from-minibuffer ">")))

(defun send-cursorPosition (point) 
  (process-send-string 
   server 
   (number-to-string point)
   )
  )

(defun send-buffer ()
  (interactive)
  (process-send-string 
   server 
    (buffer-string)
   )
  )

(defun keyword-completion-mode ()
  "Keyword-completion mode"
  (interactive)
  (kill-all-local-variables)
  (setq mode-name "keyword-completion-mode")
  (setq major-mode 'keyword-completion-mode)
  
  (use-local-map complete-mode-map)
  (run-hooks 'complete-mode-hook))
 
(provide 'keyword-completion-mode)
