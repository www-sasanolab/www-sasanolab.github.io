#include "completion.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#define BUFSIZE 65535
#define SERVER_PORT 50000

char * ppprefix = NULL;

struct cell{
  char *car;
  struct cell *cdr;
};

typedef struct cell *list;
int position;
extern int num_chars;
extern char cursorlen;

void printKeyword (list keyword) {
  puts("keywords: ");
  for(;keyword; keyword=keyword->cdr)
    printf("%s, ", keyword->car);
  puts("\n");
}

list keyword (struct translation_unit *translation_unit) {
  return keyword_translation_unit (translation_unit, NULL);
}

list computeKeyword (struct translation_unit *parseResult) {
  return keyword (parseResult);
}

void clearbuf(char *buf) {
  int i;
  for(i=0; i<BUFSIZE; i++)
    buf[i]=0;
}

list hasPrefix (char *id, list result) {
  struct cell *c;
  int length;
  char *str;
  if (result==NULL)
    return NULL;
  str = result->car;
  if (id==NULL) {
    return result;
  }
  length = strlen (id);
  if (strncasecmp (id, str, length)==0) {
    c = malloc (sizeof(struct cell));
    c->car = str;
    c->cdr = hasPrefix (id, result->cdr);
    return c;
  } else 
    return hasPrefix (id, result->cdr);
}


int main(void) {
  char stringarray[256];
  extern struct translation_unit *parseResult;
  extern int yyparse(void);
  list keyword=NULL;
  FILE *filePointer;
  int sockfd; /* file descriptor returned by socket() */
  int ns; /* file descriptor returned by accept() */
  struct sockaddr_in server;
  struct sockaddr_in client;
  socklen_t fromlen;
  char buf[BUFSIZE];
  char *empty="";
  int msglen;
  const int one = 1;
  if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) == -1) {
    perror("server: socket");
    exit(1);
  }
  bzero((char *)&server, sizeof(server));
  server.sin_family = PF_INET;
  server.sin_port = htons(SERVER_PORT);
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, 
	     &one, sizeof(int));
  if(bind(sockfd, (struct sockaddr *)&server, sizeof(server))
     == -1) {
    perror("server: bind");
    exit(1);
  }
  if(listen(sockfd, 5) == -1){
    perror("server: listen");
    exit(1);
  }
  fromlen = sizeof(client);

  while (1) {
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    clearbuf(buf);
    if(read(ns, buf, BUFSIZE) == -1){
      perror("server: read1");
      exit(1);
    }

    sscanf (buf, "%d", &position);

    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }
    
    clearbuf(buf);

    filePointer=fdopen(ns, "r");
    
    yyrestart (filePointer);
    printf ("---start\n");
    if (yyparse()) {
      fprintf (stderr, "syntax error in yyparse\n"); 
    } 
    else {
      keyword = computeKeyword (parseResult);
    }
    printf ("---end\n");
    fclose(filePointer);

    sprintf (stringarray, "%d", cursorlen);
    printf ("cursorlen = %d\n", cursorlen);
    
    if((ns = accept(sockfd, (struct sockaddr *)&client, 
		    &fromlen)) == -1){
      perror("server: accept");
      exit(1);
    }

    if(write(ns, &stringarray, strlen(stringarray)) == -1){ 
      perror("server: write");
      exit(1);
    }
    printKeyword(keyword);
    keyword=hasPrefix (ppprefix, keyword);
    printf("ppprefix: %s\n", ppprefix);
    printKeyword(keyword);
    for(;keyword!=NULL; keyword=keyword->cdr){
      if(write(ns, "\n", 1) == -1){ 
	perror("server: write");
	exit(1);
      }
      msglen = strlen (keyword->car);
      if(write(ns, keyword->car, msglen) == -1){ 
	perror("server: write");
	exit(1);
      }
    }
    close(ns);
    num_chars=0;
    //    cursorlen=-1;
    keyword=NULL;
  }
  close(sockfd);
  return 0;
}
