/* config.h.  Generated automatically by configure.  */
/* config_h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to noreturn-attribute for gcc */
/* #undef GCC_NORETURN */

/* Define to 1 if the compiler supports gcc-like printf attribute. */
/* #undef GCC_PRINTF */

/* Define to printf-attribute for gcc */
/* #undef GCC_PRINTFLIKE */

/* Define to 1 if the compiler supports gcc-like scanf attribute. */
/* #undef GCC_SCANF */

/* Define to sscanf-attribute for gcc */
/* #undef GCC_SCANFLIKE */

/* Define to unused-attribute for gcc */
/* #undef GCC_UNUSED */

/* Define if you have the <fcntl.h> header file. */
#define HAVE_FCNTL_H 1

/* Define if you have the `dbmalloc' library (-ldbmalloc). */
/* #undef HAVE_LIBDBMALLOC */

/* Define if you have the `dmalloc' library (-ldmalloc). */
/* #undef HAVE_LIBDMALLOC */

/* Define to 1 if mkstemp() is available and working. */
#define HAVE_MKSTEMP 1

/* Define to 1 if vsnprintf() is available and working. */
#define HAVE_VSNPRINTF 1

/* Define to maximum table size (default: 32500) */
/* #undef MAXTABLE */

/* Define to 1 if filesystem supports mixed-case filenames. */
/* #undef MIXEDCASE_FILENAMES */

/* Define to 1 if you want to perform memory-leak testing. */
/* #undef NO_LEAKS */

/* Define to the system name. */
#define SYSTEM_NAME "darwin14.5.0"

/* "Define to 1 if you want to use dbmalloc for testing." */
/* #undef USE_DBMALLOC */

/* "Define to 1 if you want to use dmalloc for testing." */
/* #undef USE_DMALLOC */

/* "Define to 1 if you want to use valgrind for testing." */
/* #undef USE_VALGRIND */

/* Define to 1 to enable backtracking extension */
/* #undef YYBTYACC */

/* Define to 1 if you want to perform memory-leak testing. */
/* #undef YY_NO_LEAKS */
