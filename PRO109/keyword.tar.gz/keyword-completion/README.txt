[ディレクトリ構成]
README --- このファイル
completion/
  test.c --- 論文の2節で提示した入力中の例
  Makefile --- キーワード補完プログラムa.outを生成するためのMakefile
  server.c --- Emacs Lispプログラムcomplete-mode.elからTCP/IPにより現在のバッファの内容を受け取り、
               補完候補計算を行い、結果をEmacs Lispプログラムへ送り返すC言語のプログラム
  c.l --- Flex用のC言語の字句定義で、入力中のキーワードに対
  応する字句定義が一部追加されている。（c.lファイルは
  https://www.lysator.liu.se/c/ANSI-C-grammar-l.htmlからダウ
  ンロードできる。）
  c.y --- BYacc用のC言語の構文定義で、入力中のキーワードに対
  応する字句が一部追加されている。（c.yファイルは
  https://www.lysator.liu.se/c/ANSI-C-grammar-y.htmlからダウ
  ンロードできる。）
  complete-mode.el --- TABキーが押されたときに現在のバッファの内容を補完候補計算プログラム（server.c）へTCP/IPで送り、
                       受け取った結果をpopup表示するEmacs Lispプログラム
  popup.el --- ポップアップ表示を行うEmacs Lispプログラム
               https://github.com/auto-complete/popup-el
	       からダウンロード可能だが利便性のためにここへ置いてある。
  load.el --- "popup.el"と"complete-mode.el"をロードするプログラム
reader/ --- BYaccのソースコードを修正したディレクトリ。修正したファイルは以下の通り。
  reader.c --- ユーザが記述する.yファイル（ファイル名はreader/Makefileにおいて指定、defaultではc.y）を読み取り、
               BYaccの仕様記述(completion.y)、補完候補計算プログラム(completion.c)、構文木のデータ構造定義(completion.h)を
	       生成するC言語プログラム
  defs.h --- reader.cで使う大域変数の宣言を追加してある

[環境]
・Flex
・Yacc
・C言語コンパイラ
・Emacs version 24.3以上（popup.elを使うため）

以下の環境で動作確認を行っている。
・プロセッサ: 3.7 GHz Quad-Core Intel Xeon E5
・OS: MacOS X Yosemite 10.10.5
・Flex: version 2.5.37
・Yacc: bison (GNU Bison) 2.3
・C言語コンパイラ: Apple LLVM version 7.0.2 (clang-700.1.81)
・Emacs: version 24.4 (9.0)
	 
[使い方]
1. readerディレクトリに移動する。
     $ cd reader
2. 以下の2つのコマンドを実行する。
     $ ./configure
     $ make
3. completionディレクトリへ移動する。
     $ cd ../completion
4. 以下のコマンドを実行する。
     $ make
   c.yがテスト用のBYacc仕様記述ファイルであり、makeの実行により
     $ ../reader/yacc c.y
   が実行され、completion.y, completion.c, completion.hが生成される。
   completion.yはYaccの仕様記述ファイルである。
   completion.cは補完候補計算関数の定義が入ったファイルである。
   completion.hは構文木のデータ構造の定義が入ったファイルである。
   これらを用いてキーワード補完プログラムa.outが生成される。
5. a.outを実行する。
  $ ./a.out
6. Emacsを開く。（Emacsはterminal内ではなく、windowが生成されるEmacsを実行する。）
7. Emacs上でcompletion/test.cを開く。例えば以下のようにして開く。
  C-x C-f completion/test.c <RET>
8. 以下ようにEmacs Lispのプログラムload.elををロードする。
  M-x load-file <RET> load.el <RET>
9. keyword-completion-modeを起動する。
  M-x keyword-completion-mode
